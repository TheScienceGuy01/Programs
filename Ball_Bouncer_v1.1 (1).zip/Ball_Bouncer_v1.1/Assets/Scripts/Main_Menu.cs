using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Main_Menu : MonoBehaviour
{

    // Update is called once per frame
    void Update()
    {
        //Quits the game.
        if (Input.GetKeyUp(KeyCode.Escape))
        {
            Application.Quit();
        }

        //Starts the game.
        if (Input.GetKeyUp("e"))
        {
            SceneManager.LoadScene("SampleScene");
        }
    }
}
