using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlatformManager : MonoBehaviour
{
    //Floating-Point Variables
    public float speed;

    //Gameobject Variables.
    public GameObject ball;
    public GameObject platform;
    public GameObject leftWall;
    public GameObject rightWall;
    public GameObject pointingSprite;
    public GameObject gameOverScreen;
    
    //Boolean Variables
    public bool gameStart;
    public bool gameOver;

    // Start is called before the first frame update
    void Start()
    {
        //Allows for the game to proceed.
        gameStart = false;
    }

    // Update is called once per frame
    void Update()
    {
        //Moves the ball pointer in the direction of the mouse.
        Vector2 mousePos = Input.mousePosition;
        mousePos = Camera.main.ScreenToWorldPoint(mousePos);
        Vector2 LookAtPoint = new Vector2(mousePos.x-transform.position.x, mousePos.y-transform.position.y);
        transform.up = LookAtPoint;

        //Checks if the game is not over and launches the ball off the platform when left-clicked.
        if (Input.GetMouseButtonDown(0))
        {
            if (gameOver == false)
            {
                if (gameStart == false)
                {
                    ball.gameObject.GetComponent<Rigidbody2D>().AddForce(transform.up * speed);
                }
                gameStart = true;
            }
        }

        //Sets the restrictions for the ball platform.
        if (mousePos.x >= leftWall.transform.position.x+1 && mousePos.x <= rightWall.transform.position.x-1 && gameStart)
        {
            platform.transform.position = new Vector2(mousePos.x, platform.transform.position.y);
        }

        //Resets the game whenever the ball touches the bottom floor.
        if (gameStart == false)
        {
            platform.transform.position = new Vector2(1.46F, platform.transform.position.y);
            pointingSprite.gameObject.SetActive(true);
            ball.transform.position = new Vector2(1.46f, platform.transform.position.y+.5f);
            ball.transform.gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(0,0);
        }
        else
        {
            pointingSprite.gameObject.SetActive(false);
        }

        //Stops the game whenever a block touches the floor.
        if (gameOver)
        {
            //Sets the game over screen to active.
            gameOverScreen.gameObject.SetActive(true);

            //Resets the game.
            if (Input.GetKeyUp("r"))
            {
                SceneManager.LoadScene("SampleScene");
            }

            //Takes the player to the main Menu
            if (Input.GetKeyUp("m"))
            {
                SceneManager.LoadScene("MainMenu");
            }
        }

        //Quits the game.
        if (Input.GetKeyUp(KeyCode.Escape))
        {
            Application.Quit();
        }
    }
}
