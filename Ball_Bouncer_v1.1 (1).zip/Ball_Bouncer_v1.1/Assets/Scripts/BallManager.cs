using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class BallManager : MonoBehaviour
{
    //Variables
    private Vector2 vel;
    public float speed;
    public GameObject arena;
    public GameObject platform;
    public GameObject shifter;
    public int lives = 3;

    private void Update()
    {
        //Sets the velocity for whenever the ball respawns.
        vel = transform.gameObject.GetComponent<Rigidbody2D>().velocity;
    }
    private void OnCollisionEnter2D(Collision2D other)
    {
        //If the ball touches a block, it destroys it.
        if (other.gameObject.CompareTag("Block"))
        {
            Destroy(other.gameObject);
        }

        //Calculates the reflections of the ball and set it as the velocity.
        transform.gameObject.GetComponent<Rigidbody2D>().velocity = Vector2.Reflect(vel.normalized, other.contacts[0].normal) * speed;
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        //If the ball touches the orange floor, then the ball resets and a new layer of blocks is dropped into the arena.
        if (other.gameObject.CompareTag("Floor"))
        {
            StartCoroutine(Shifter());
            arena.gameObject.GetComponent<Block_Manager>().Next_Level();
            platform.gameObject.GetComponent<PlatformManager>().gameStart = false;
            lives -= 1;
            if (lives == 0)
            {
                SceneManager.LoadScene("MainMenu");
            }
        }
    }
    public IEnumerator Shifter()
    {
        //Tells all the blocks to move down by one unit to make room for a new block set.
        shifter.gameObject.SetActive(true);
        yield return new WaitForSeconds(0.1f);
        shifter.gameObject.SetActive(false);
    }
}
