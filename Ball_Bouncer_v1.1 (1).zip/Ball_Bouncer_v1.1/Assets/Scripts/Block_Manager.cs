using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Block_Manager : MonoBehaviour
{
    //Gameobject variables.
    public GameObject[] blockSpawners;
    public GameObject block;
    private GameObject newBlock;

    //Boolean variables.
    public bool isBlock;

    // Start is called before the first frame update
    private void Start()
    {
        //Randomly creates the loaded level at the game's start.
        for (int i = 0; i < 5; i++)
        {
            for (int k = 0; k < blockSpawners.Length; k++)
            {
                if (Random.Range(0, 2) == 1)
                {
                    newBlock = Instantiate(block, new Vector2(blockSpawners[k].transform.position.x, blockSpawners[k].transform.position.y - i), blockSpawners[k].transform.rotation);
                    newBlock.gameObject.GetComponent<SpriteRenderer>().color = new Color(Random.value, Random.value, Random.value, 1f);
                }
            }
        }
    }
    //Created the next level of the game with new blocks.
    public void Next_Level()
    {
        //For all the block spawners on the very top of the arena, each one randomly chooses to either spawn a block or not.
        //This also randomly assigns a color to each new block.
        Debug.Log("Called Next Level");
        for (int i = 0; i < blockSpawners.Length; i++)
        {
            if (Random.Range(0,2) == 1)
            {
                newBlock = Instantiate(block, blockSpawners[i].transform.position, blockSpawners[i].transform.rotation);
                newBlock.gameObject.GetComponent<SpriteRenderer>().color = new Color(Random.value, Random.value, Random.value, 1f);
            }
        }
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        //If the level is over, then the current blocks shift downto make way for new blocks to instantiate.
        if (isBlock && other.gameObject.CompareTag("Shifter"))
        {
            transform.position = new Vector2(transform.position.x, transform.position.y-1);
        }

        //If any block touches the floor of the arena, then the game is over.
        if (isBlock && other.gameObject.CompareTag("Respawn"))
        {
            Debug.Log("GameOver");
            GameObject.Find("platform").gameObject.GetComponent<PlatformManager>().gameStart = false;
            GameObject.Find("platform").gameObject.GetComponent<PlatformManager>().gameOver = true;
        }
    }
}
