using System.Collections;
using UnityEngine;

public class Enemy_Spawns : MonoBehaviour
{
    public GameObject[] spawnLocations;
    public GameObject enemy;
    public float spawnRate;
    private GameObject spawned;

    void Start()
    {
        foreach (GameObject location in spawnLocations)
        {
            if (Random.value < spawnRate)
            {
                spawned = Instantiate(enemy, location.transform.position, location.transform.rotation);
                spawned.SetActive(true);
            }
        }
    }

}
