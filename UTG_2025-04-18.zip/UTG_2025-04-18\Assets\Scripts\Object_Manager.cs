using System.Collections.Generic;
using UnityEngine;

public class Object_Manager : MonoBehaviour
{
    public Sprite frostSprite;
    public Sprite presentedSprite;
    public Sprite outlineSprite;
    public Sprite invalidSprite;
    public bool isGhost;
    public GameObject player;
    private Rigidbody2D rb;

    // List to track objects in the trigger
    private List<Collider2D> objectsInTrigger = new List<Collider2D>();

    private void Start()
    {
        /* 
         * =====================================================================
         * Manages Initializing Sprite.
         * =====================================================================
        */

        if (GetComponent<SpriteRenderer>().sprite != outlineSprite && GetComponent<SpriteRenderer>().sprite != invalidSprite)
        {
            presentedSprite = GetComponent<SpriteRenderer>().sprite;
        }
        GetComponent<SpriteRenderer>().sprite = outlineSprite;
        rb = GetComponent<Rigidbody2D>(); 
    }

    // Called when another collider enters the trigger
    private void OnTriggerEnter2D(Collider2D other)
    {
        /* 
         * =====================================================================
         * Runs when the object is in collision with another object or when
         * it is supposed to get deleted.
         * =====================================================================
        */

        //Runs to check for valid object placement.
        if (!objectsInTrigger.Contains(other) && isGhost == true)
        {
            objectsInTrigger.Add(other);
            GetComponent<SpriteRenderer>().sprite = invalidSprite;
        }

        //Runs to check if the object fell into the abyss/lava.
        if (other.CompareTag("Lava") && isGhost == false)
        {
            player.GetComponent<Object_Spawner>().MeterChange(false);
            Destroy(gameObject);
        }
    }

    // Called when another collider exits the trigger
    private void OnTriggerExit2D(Collider2D other)
    {
        /* 
         * =====================================================================
         * Is called when the item is not in any trigger for valid placement.
         * =====================================================================
        */

        if (objectsInTrigger.Contains(other) && isGhost == true)
        {
            objectsInTrigger.Remove(other);
            if (IsTriggerEmpty() == true)
            {
                GetComponent<SpriteRenderer>().sprite = outlineSprite;
            }
        }
    }

    // To check if the trigger is empty
    public bool IsTriggerEmpty()
    {
        /* 
         * =====================================================================
         * Returns true if the object is not in any triggers.
         * =====================================================================
        */
        return objectsInTrigger.Count == 0;
    }

}
