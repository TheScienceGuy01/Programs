using System.Collections;
using UnityEngine;

public class PowerUps : MonoBehaviour
{
    public bool isFrost;
    public bool isBomb;
    public bool isNuke;
    public bool isUFOLights;
    public bool isUFO;
    public bool isVending;
    public bool isBouncy;
    public bool isInitial;

    public float nukeThreshold;
    public float bombForce;
    public float bombRadius;

    public GameObject vendingLocation;
    public GameObject[] vendingObjects;
    public int vendingAmount;

    public Sprite[] ufoLights;
    public float lightsTime;
    public float beamTime;
    public bool startUFO = true;
    public float ufoUpwardForce;
    public float ufoUpwardAmount;
    public float ufoStartDelay;
    public GameObject player;

    public float bounceForce;

    public GameObject objectHolder;

    private Rigidbody2D rb;
    public GameObject powerUpParticle;
    private GameObject particle;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        /* 
         * =====================================================================
         * Runs coroutines based on what powerup the object has.
         * =====================================================================
        */

        rb = gameObject.GetComponent<Rigidbody2D>();

        if (isFrost)
        {
            StartCoroutine(Frost());
        }
        if (isBomb)
        {
            StartCoroutine(Bomb());
        }
        if (isVending)
        {
            StartCoroutine(Vending());
        }
        if (isUFOLights)
        {
            StartCoroutine(UFO());
        }
    }

    IEnumerator Frost()
    {
        /* 
         * =====================================================================
         * Controls Frost behavior.
         * =====================================================================
        */

        yield return new WaitForSeconds(2);

        //For each object that is not already frozen, is active and not a ghost, it freezes them. It also pops balloons and destroys the frost object.
        foreach (Transform x in objectHolder.transform)
        {
            if (x.GetComponent<Object_Manager>() != null && x.GetComponent<Object_Manager>().isGhost == false)
            {
                if (x.GetComponent<PowerUps_Update>() != null)
                {
                    x.GetComponent<PowerUps_Update>().player.GetComponent<Object_Spawner>().MeterChange(true);
                    x.GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f, 1);
                    Destroy(x.GetComponent<PowerUps_Update>());
                }
                if (x.GetComponent<Rigidbody2D>() != null)
                {
                    x.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Kinematic;
                    x.GetComponent<Rigidbody2D>().linearVelocity = new Vector2(0,0);
                    x.GetComponent<Rigidbody2D>().angularVelocity = 0;

                }
                if (x.GetComponent<SpriteRenderer>().sprite != x.GetComponent<Object_Manager>().frostSprite)
                {
                    x.GetComponent<SpriteRenderer>().sprite = x.GetComponent<Object_Manager>().frostSprite;
                    Spawn_Particles(x.gameObject);
                }
                if (x.gameObject.name.Contains("UFO"))
                {
                    foreach (Transform beam in x.transform)
                    {
                        beam.gameObject.SetActive(false);
                    }
                }
            }
            if (x.GetComponent<Rigidbody2D>() == null && x.gameObject.name.Contains("Balloon"))
            {
                Destroy(x.gameObject);
            }
        }
        Destroy(gameObject);
    }

    IEnumerator Bomb()
    {
        /* 
         * =====================================================================
         * This controls bomb behavior.
         * =====================================================================
        */
        yield return new WaitForSeconds(2);

        if (!GetComponent<SpriteRenderer>().sprite.name.Contains("Frost"))
        {
            Debug.Log("BOOOOOMMMM");
            Spawn_Particles(gameObject);
            //Calculates the closest objects to either push away or destroy.
            Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, bombRadius);
            Collider2D[] collidersDestroy = Physics2D.OverlapCircleAll(transform.position, bombRadius / 2);

            foreach (Collider2D collider in colliders)
            {
                // Apply force to objects with Rigidbody2D
                Rigidbody2D rb = collider.GetComponent<Rigidbody2D>();
                if (rb != null && !rb.gameObject.name.Contains("Surface"))
                {
                    if (rb.gameObject.GetComponent<SpriteRenderer>() != null)
                    {
                        if (!rb.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("outline") && !rb.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("Invalid"))
                        {
                            Vector2 direction = rb.position - (Vector2)transform.position;
                            rb.AddForce(direction.normalized * bombForce);
                        }
                    }
                    else
                    {
                        Vector2 direction = rb.position - (Vector2)transform.position;
                        rb.AddForce(direction.normalized * bombForce);
                    }
                }
            }
            foreach (Collider2D collider in collidersDestroy)
            {
                if (collider.gameObject.GetComponent<Object_Manager>() != null && (collider.gameObject.name != "Player_Universal") && !collider.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("Outline") && !collider.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("Invalid"))
                {
                    if (!collider.gameObject.name.Contains("Nuke"))
                    {
                        Spawn_Particles(collider.gameObject);
                        Destroy(collider.gameObject);
                    }
                    else
                    {
                        foreach (Transform x in objectHolder.transform)
                        {
                            if (x.gameObject != transform.gameObject)
                            {
                                Spawn_Particles(x.gameObject);

                                Destroy(x.gameObject);

                            }
                        }
                        Destroy(collider.gameObject);
                    }
                }
            }
            Destroy(gameObject);
        }
    }

    IEnumerator Vending()
    {
        /* 
         * =====================================================================
         * Controls vending behavior for vending objects.
         * =====================================================================
        */

        //TODO: Add behavior for toasters.

        GameObject vendedItem = null;
        int randNum = Random.Range(0,vendingObjects.Length);

        //Spawns the items.
        for (int i = 0; i < vendingAmount; i++)
        {
            yield return new WaitForSeconds(2);

            vendedItem = Instantiate(vendingObjects[randNum], vendingLocation.transform.position, vendingLocation.transform.rotation);
            vendedItem.GetComponent<Rigidbody2D>().gravityScale = 1;
            vendedItem.GetComponent<Object_Manager>().isGhost = false;
            vendedItem.GetComponent<Collider2D>().isTrigger = false;
            vendedItem.GetComponent<PowerUps_Update>().enabled = true;
            yield return new WaitForEndOfFrame();
            vendedItem.GetComponent<SpriteRenderer>().sprite = vendedItem.GetComponent<Object_Manager>().presentedSprite;
            vendedItem.transform.parent = objectHolder.transform;

            randNum = Random.Range(0, vendingObjects.Length);
        }
    }

    public IEnumerator UFO()
    {
        /* 
         * =====================================================================
         * UFO Behavior
         * =====================================================================
        */

        //This deletes the PowerUp_Update script and adds it immediately to the stability meter.
        if (transform.parent.GetComponent<PowerUps>() != null && transform.parent != null)
        {
            if (transform.parent.GetComponent<PowerUps>().isUFO == true && transform.parent.GetComponent<PowerUps>().isInitial == true)
            {
                transform.parent.GetComponent<PowerUps>().isInitial = false;
                transform.parent.GetComponent<PowerUps>().player.GetComponent<Object_Spawner>().MeterChange(true);
                Destroy(transform.parent.GetComponent<PowerUps_Update>());
            }
        }

        //Controls the lights for the UFOs.
        if (isUFOLights)
        {
            while (startUFO == true)
            {
                if (transform.parent.name == "Lights")
                {
                    transform.GetComponent<SpriteRenderer>().enabled = true;
                    transform.GetComponent<SpriteRenderer>().sprite = ufoLights[Random.Range(0, ufoLights.Length)];
                    yield return new WaitForSeconds(Random.Range(.1f, lightsTime));
                    transform.GetComponent<SpriteRenderer>().enabled = false;
                    yield return new WaitForSeconds(Random.Range(.1f, lightsTime));
                }
                else
                {
                    foreach (Transform beam in transform)
                    {
                        if (!beam.name.Contains("Booster"))
                        {
                            beam.transform.GetComponent<SpriteRenderer>().enabled = true;
                            yield return new WaitForSeconds(beamTime);
                            beam.transform.GetComponent<SpriteRenderer>().enabled = false;
                        }
                    }
                }
            }
        }
        else
        {
            //Controls the upward force of the UFO.
            
            yield return new WaitForSeconds(ufoStartDelay);
            float elapsedTime = 0f;

            while (elapsedTime < ufoUpwardAmount)
            {
                // Apply the force
                if (rb != null)
                {
                    rb.AddForce(transform.up.normalized * ufoUpwardForce, ForceMode2D.Force);
                }

                // Increment elapsed time
                elapsedTime += Time.deltaTime;

                // Wait for the next frame
                yield return null;
            }
            if (rb != null)
            {
                Destroy(transform.GetComponent<Rigidbody2D>());
            }
        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        /* 
         * =====================================================================
         * This is for nuke behavior.
         * =====================================================================
        */

        //When the nuke is not frozen and the speed something hits it at is high enough, it destroys all objects.
        if (isNuke && !GetComponent<SpriteRenderer>().sprite.name.Contains("Frost"))
        {
            Vector3 velocity = collision.relativeVelocity;
            //Vector3 normal = collision.GetContact(0).normal;
            if (velocity.magnitude > nukeThreshold)//impact faster than 2
            {
                foreach (Transform x in objectHolder.transform)
                {
                    if (x.gameObject != transform.gameObject)
                    {
                        Spawn_Particles(x.gameObject);
                        Destroy(x.gameObject);

                    }
                }
                Spawn_Particles(gameObject);

                Destroy(gameObject);

            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        /* 
         * =====================================================================
         * This is for trampoline behavior.
         * =====================================================================
        */

        //If it is bouncey, then an upward force is added.
        if (isBouncy)
        {
            rb = collision.gameObject.GetComponent<Rigidbody2D>();
            if (rb != null && !rb.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("outline") && !rb.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("Invalid"))
            {
                // Calculate the normal direction based on the trampoline's orientation
                Vector2 trampolineNormal = -transform.right.normalized;

                if (collision.gameObject.CompareTag("Player"))
                {
                    collision.gameObject.GetComponent<Rigidbody2D>().AddForce(trampolineNormal * bounceForce*2, ForceMode2D.Impulse);
                }
                else
                {
                    collision.gameObject.GetComponent<Rigidbody2D>().AddForce(trampolineNormal * bounceForce, ForceMode2D.Impulse);
                }
            }
        }
    }

    void Spawn_Particles(GameObject x)
    {
        particle = Instantiate(powerUpParticle, x.transform.position, x.transform.rotation);
        particle.GetComponent<ParticleSystem>().Play();
        particle.GetComponent<Call_Destroy>().enabled = true;
    }
}
