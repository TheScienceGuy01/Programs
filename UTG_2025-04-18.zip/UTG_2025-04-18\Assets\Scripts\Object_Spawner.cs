using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;

[System.Serializable]
public class SpawnableObject
{
    /* 
     * =====================================================================
     * This class is for objects.
     * =====================================================================
    */
    public GameObject solidObject;  // The GameObject to spawn
    public int spawnRate;        // The spawn rate for this GameObject
}
public class Object_Spawner : MonoBehaviour
{
    public List<SpawnableObject> objects;
    public int randObjectNumber;
    public int weightCount;
    public GameObject chosenObject;
    public GameObject mainCamera;
    public float rotRate;
    public GameObject ghostSpawner;
    public float wobbleForce;
    public GameObject objectHolder;
    public float secondsDelay;
    public bool isClicked;
    public bool nullSlots;
    public GameObject canvas;
    public GameObject nullSlotGameobject;
    public GameObject savedObject;
    public bool saveNext;
    public bool changeToSaved;
    public float objectMaxSpeed;

    public List<SpawnableObject> trashPool;
    public List<SpawnableObject> bronzePool;
    public List<SpawnableObject> silverPool;
    public List<SpawnableObject> goldPool;
    public float[] goldSpawnChances; 
    public List<SpawnableObject> guaranteedPool;

    public GameObject[] meterLevels;
    public int meterCounter = 0;
    public int meterGoal = 28;
    public int meterLevel = 0;
    public TextMeshProUGUI counterText;
    public TextMeshProUGUI counterGoal;
    public TextMeshProUGUI levelText;
    public TextMeshProUGUI cloudCounter;
    public TextMeshProUGUI goldCloudCounter;
    public TextMeshProUGUI cloudConverter;
    public GameObject cloudConverterUI;
    public bool runningConverter;
    public GameObject redButtonConverter;
    public bool suckToolOut;
    public GameObject suckTool;
    public float suckToolLimit;
    public bool clickableSprite;
    private Vector2 lastPos;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        /* 
         * =====================================================================
         * This function initializes mouse position, initial cards to get, spawn
         * rates and meter goals.
         * =====================================================================
        */

        Vector3 mouseScreenPosition = Input.mousePosition;

        // Convert the screen position to world position
        Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(mouseScreenPosition);

        // Adjust for the z-axis to match your 2D plane
        mouseWorldPosition.z = 0;

        int initCountTrash = 1;
        int initCountBronze = 3;
        int initCountGold = 0;

        while (objects.Count < initCountTrash) // Ensure unique additions
        {
            int rand = Random.Range(0, trashPool.Count);
            var selectedObject = trashPool[rand];

            if (!objects.Contains(selectedObject))
            {
                objects.Add(selectedObject);
            }
        }

        while (objects.Count < initCountBronze) // Ensure unique additions
        {
            int rand = Random.Range(0, bronzePool.Count);
            var selectedObject = bronzePool[rand];

            if (!objects.Contains(selectedObject))
            {
                objects.Add(selectedObject);
            }
        }

        while (objects.Count < initCountGold) // Ensure unique additions
        {
            int rand = Random.Range(0, goldPool.Count);
            var selectedObject = goldPool[rand];

            if (!objects.Contains(selectedObject))
            {
                objects.Add(selectedObject);
            }
        }

        foreach (SpawnableObject obj in guaranteedPool) // For guaranteed items
        {
            objects.Add(obj);
        }

        //Initial ghost object.
        ghostSpawner.transform.position = mouseWorldPosition;
        chosenObject = objects[0].solidObject;
        ghostSpawner = Instantiate(chosenObject, mouseWorldPosition, ghostSpawner.transform.rotation);

        //Adds rates
        foreach (SpawnableObject x in objects)
        {
            weightCount += x.spawnRate;
        }

        //Initializes meter goal.
        counterGoal.text = "Items Needed: " + meterGoal;
        meterLevel = meterGoal / 28;
        lastPos = ghostSpawner.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        /* 
         * =====================================================================
         * This function updates mouse position, keyboard inputs for cloud tool,
         * card spawning, and cloud converter. This is also where objects are
         * initialized, spawned, and intialized before their own script
         * initializations.
         * =====================================================================
        */

        Vector3 mouseScreenPosition = Input.mousePosition;

        // Convert the screen position to world position
        Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(mouseScreenPosition);

        // Adjust for the z-axis to match your 2D plane
        mouseWorldPosition.z = 0;

        Vector2 direction = (mouseWorldPosition - ghostSpawner.transform.position);
        float distance = direction.magnitude;
        direction = direction.normalized;
        Vector2 curPos = ghostSpawner.transform.position;
        if (Vector2.Distance(mouseWorldPosition, curPos) > Vector2.Distance(mouseWorldPosition, lastPos))
        {
            ghostSpawner.GetComponent<Rigidbody2D>().linearVelocity *= .83f;
        }

        ghostSpawner.GetComponent<Rigidbody2D>().AddForce(direction * distance * wobbleForce * (ghostSpawner.GetComponent<Rigidbody2D>().mass/2), ForceMode2D.Force);

        nullSlotGameobject.transform.position = mouseWorldPosition;
        lastPos = curPos;
        //For Cloud sucking tool
        if (Input.GetKeyDown(KeyCode.T) && cloudConverterUI.activeInHierarchy == false)
        {
            suckToolOut = !suckToolOut;
            ghostSpawner.gameObject.SetActive(!suckToolOut);
            suckTool.gameObject.SetActive(suckToolOut);
            if (suckToolOut == false)
            {
                canvas.GetComponent<Inventory_Manager>().toolBack = true;
            }
        }
        else if (Input.GetKeyDown(KeyCode.T) && cloudConverterUI.activeInHierarchy == true && runningConverter == false && canvas.GetComponent<Inventory_Manager>().animRunning == false)
        {
            runningConverter = true;
        }

        //For Gold Converter
        if (cloudConverter.gameObject.activeInHierarchy == true && Input.GetKeyDown(KeyCode.Q) && cloudConverterUI.activeInHierarchy == true)
        {
            cloudConverterUI.SetActive(false);
            cloudConverterUI.GetComponent<Animator>().enabled = false;
            StopCoroutine(Converter_Anim());
        }
        else if (cloudConverter.gameObject.activeInHierarchy == true && Input.GetKeyDown(KeyCode.Q) && cloudConverterUI.activeInHierarchy == false)
        {
            cloudConverterUI.gameObject.SetActive(true);
            runningConverter = false;
            StartCoroutine(Converter_Anim());
        }

        //Main card spawning statement. If the left m ouse button is pressed and nothing else is active, and the player is not in the inventory, and the player is not on an empty slot, then it spawns the object.
        if (((Input.GetMouseButtonDown(0) && ghostSpawner.GetComponent<Object_Manager>().IsTriggerEmpty() == true) || isClicked == true) && nullSlots == false && suckToolOut == false && clickableSprite == false)
        {

            if (isClicked == false)
            {
                //Used for the storage slot in the hotbar.
                if (canvas.gameObject.GetComponent<Inventory_Manager>().slotSelected == false)
                {
                    canvas.GetComponent<Inventory_Manager>().storageSlot2Item.GetComponent<Image>().sprite = null;
                    foreach (GameObject x in canvas.GetComponent<Inventory_Manager>().inventoryObjects)
                    {
                        x.SetActive(false);
                    }
                    nullSlotGameobject.gameObject.SetActive(true);
                    nullSlots = true;
                    changeToSaved = true;
                }
                else
                {
                    saveNext = true;

                }

                //If the rb is not null, then the PowerUps_Update script is active so that the object can be ready for stability checking.
                if (ghostSpawner.GetComponent<Rigidbody2D>() != null)
                {
                    if (ghostSpawner.GetComponent<PowerUps_Update>() != null)
                    {
                        ghostSpawner.GetComponent<PowerUps_Update>().enabled = true;
                    }
                    ghostSpawner.GetComponent<Rigidbody2D>().gravityScale = 1;
                }

                //If the object is a bool or a UFO then the animation is set to true and the PowerUp script is set active.
                ghostSpawner.GetComponent<Object_Manager>().isGhost = false;
                ghostSpawner.GetComponent<SpriteRenderer>().sprite = ghostSpawner.GetComponent<Object_Manager>().presentedSprite;
                if (ghostSpawner.GetComponent<Animator>() != null)
                {
                    ghostSpawner.GetComponent<Animator>().enabled = true;
                    if (ghostSpawner.gameObject.name.Contains("Balloon"))
                    {
                        Destroy(ghostSpawner.GetComponent<Rigidbody2D>());
                    }
                }
                ghostSpawner.transform.parent = objectHolder.transform;
                if (ghostSpawner.gameObject.name.Contains("UFO"))
                {
                    StartCoroutine(ghostSpawner.GetComponent<PowerUps>().UFO());
                    foreach (Transform beam in ghostSpawner.transform)
                    {
                        beam.gameObject.SetActive(true);
                    }
                }

                //Sets the bounce part of the trampoline on.
                if (ghostSpawner.gameObject.name.Contains("Trampoline"))
                {
                    ghostSpawner.transform.GetChild(0).gameObject.SetActive(true);
                }

            }
            else
            {

                isClicked = false;
                Destroy(ghostSpawner.gameObject);
            }

            //For each collider in the object is sets the trigger off so that the object will be solid. It also actives the PowerUp script if needed.
            Collider2D[] colliders = ghostSpawner.GetComponents<Collider2D>();

            foreach (Collider2D col in colliders)
            {
                col.isTrigger = false;
            }

            if (colliders.Length > 0)
            {
                colliders[0].isTrigger = false;
            }

            if (ghostSpawner.GetComponent<PowerUps>() != null)
            {
                ghostSpawner.GetComponent<PowerUps>().enabled = true;
            }


            randObjectNumber = Random.Range(0, weightCount);
            int runningTotal = 0;
            bool canCont = true;

            //Chooses next card to spawn.
            if (canvas.gameObject.GetComponent<Inventory_Manager>().slotSelected == true || nullSlots == true)
            {
                while (canCont == true)
                {
                    foreach (SpawnableObject x in objects)
                    {
                        runningTotal += x.spawnRate;
                        if (randObjectNumber <= runningTotal)
                        {
                            chosenObject = x.solidObject;
                            canCont = false;
                            break;
                        }
                    }
                }
            }
            else
            {
                chosenObject = canvas.GetComponent<Inventory_Manager>().selectedObject;
            }

            //Saves the next item for if the user switches to the other hotbar slot.
            if (saveNext == true)
            {
                saveNext = false;
                savedObject = chosenObject;
            }

            if (changeToSaved == true)
            {
                changeToSaved = false;
                chosenObject = savedObject;
            }

            //Instanitates the object chosen and initializes it.
            ghostSpawner = Instantiate(chosenObject, mouseWorldPosition, ghostSpawner.transform.rotation);
            if (ghostSpawner.GetComponent<Rigidbody2D>() != null)
            {
                ghostSpawner.GetComponent<Rigidbody2D>().gravityScale = 0;
            }
            ghostSpawner.GetComponent<Object_Manager>().isGhost = true;

            if (ghostSpawner.gameObject.name.Contains("Trampoline"))
            {
                ghostSpawner.transform.rotation = Quaternion.Euler(0, 0, -90);
            }
            else
            {
                ghostSpawner.transform.rotation = Quaternion.Euler(0, 0, 0);
            }

            //Turns off the ghost item if the 2nd hotbart slot is full.
            if (canvas.gameObject.GetComponent<Inventory_Manager>().slotSelected == false && canvas.GetComponent<Inventory_Manager>().storageSlot2Item.GetComponent<Image>().sprite == null)
            {
                ghostSpawner.gameObject.SetActive(false);
            }
        }
        else if (suckToolOut == true)
        {
            if (nullSlotGameobject.activeInHierarchy == true)
            {
                nullSlotGameobject.SetActive(false);
            }

            // Calculate the direction from the sprite to the mouse
            Vector2 directionToMouse = (mouseWorldPosition - transform.position).normalized;

            // Check if the desired position is outside the radius
            if (Vector2.Distance(transform.position, mouseWorldPosition) > suckToolLimit)
            {
                // Clamp the desired position to the edge of the radius
                mouseWorldPosition = (Vector2)transform.position + directionToMouse * suckToolLimit;
            }

            // Move the sprite towards the desired position
            suckTool.transform.position = mouseWorldPosition;
            if (Input.GetMouseButton(0))
            {
                suckTool.GetComponent<Cloud_Suck_Tool>().isOn = true;
            }
            else if (suckTool.GetComponent<Cloud_Suck_Tool>().isOn == true)
            {
                suckTool.GetComponent<Cloud_Suck_Tool>().isOn = false;
            }
        }
    }

    private void FixedUpdate()
    {
        /* 
         * =====================================================================
         * This function handles object rotation and speed control.
         * =====================================================================
        */

        if (Input.GetMouseButton(1))
        {
            ghostSpawner.transform.Rotate(0, 0, rotRate);
        }

        //Controls the speed for objects.
        foreach (Transform obj in objectHolder.transform)
        {
            if (obj.GetComponent<Rigidbody2D>() != null)
            {
                Rigidbody2D rb = obj.GetComponent<Rigidbody2D>();

                if (rb.linearVelocity.magnitude > objectMaxSpeed)
                {
                    rb.linearVelocity = rb.linearVelocity.normalized * objectMaxSpeed;
                }
            }
        }

        //Speed limits the player.
        if (GetComponent<Rigidbody2D>() != null)
        {
            Rigidbody2D rb = GetComponent<Rigidbody2D>();

            if (rb.linearVelocity.magnitude > objectMaxSpeed)
            {
                rb.linearVelocity = rb.linearVelocity.normalized * objectMaxSpeed;
            }
        }
    }

    public void ObjectPicker(int rarity)
    {
        /* 
         * =====================================================================
         * This function picks a new card once the cloud tool finishes running.
         * =====================================================================
        */

        bool found;

        //-1 means that the rarity will be chosen through the cloud tool gold
        if (rarity == -1)
        {
            found = false;

            while (found == false)
            {
                int index = Random.Range(0, goldSpawnChances.Length);
                if (Random.value > (100-goldSpawnChances[index]) / 100)
                {
                    found = true;
                    rarity = index;
                    break;
                }
            }
        }

        //Choses a card for the given rarity.
        switch (rarity)
        {
            case 0:
                RandomPicker(trashPool, 0);
                break;
            case 1:
                RandomPicker(bronzePool, 1);
                break;
            case 2:
                RandomPicker(silverPool, 2);
                break;
            case 3:
                RandomPicker(goldPool, 3);
                break;
        }
    }

    public void RandomPicker(List<SpawnableObject> pool, int rarity)
    {
        /* 
         * =====================================================================
         * This function handles picking a card.
         * =====================================================================
        */

        //TODO: If all the items are chosen then you get no items, maybe fix that to choose another rarity.

        int rand;
        bool found = false;
        while (true)
        {
            //If there is at least one free item continue to choosing in this rarity.
            rand = Random.Range(0, pool.Count);
            for (int i = 0; i < pool.Count; i++)
            {
                if (!objects.Contains(pool[i]))
                {
                    found = true;
                    break;
                }
            }

            //If an item is available, then choose one. If that item is not available the loop continues until one is chosen.
            if (found == true)
            {
                if (!objects.Contains(pool[rand]))
                {
                    objects.Add(pool[rand]);
                    weightCount += pool[rand].spawnRate;

                    suckTool.GetComponent<Cloud_Suck_Tool>().goldCloudCount -= 100;
                    goldCloudCounter.text = "Gold Clouds: " + suckTool.GetComponent<Cloud_Suck_Tool>().goldCloudCount;

                    canvas.GetComponent<Inventory_Manager>().CardAnim(rarity, pool[rand].solidObject.GetComponent<SpriteRenderer>().sprite);

                    break;
                }

            }
            else
            {
                //Runs if all the items are chosen in the rarity.
                Debug.Log("You have all the gold pool items.");
                ObjectPicker(-1);
                break;
            }
        }
    }

    public void CloudConverter(int amount)
    {
        /* 
         * =====================================================================
         * This function handles whether to turn on the cloud converter UI.
         * =====================================================================
        */

        if (amount >= 1)
        {
            cloudConverter.gameObject.SetActive(true);
        }
        else
        {
            cloudConverter.gameObject.SetActive(false);

        }
    }
    public void MeterChange(bool changeUp)
    {
        /* 
         * =====================================================================
         * This function handles changing the meter based on a successful
         * stability or level change.
         * =====================================================================
        */

        //If the change is to go up or down change the counter
        if (changeUp == true)
        {
            meterCounter += 1;
        }
        else
        {
            if (meterCounter > 0)
            {
                meterCounter -= 1;
            }
            else if (meterGoal - 28 > 0 && meterCounter == 0)
            {
                
                meterCounter = meterGoal - 28-1;
                meterGoal -= 28;
                counterGoal.text = "Items Needed: " + meterGoal;
            }
        }

       //Calculates the meter level
        counterText.text = "Count: " + meterCounter;
        int meterLevelInt = meterGoal / 28;
        levelText.text = "Level: " + meterLevelInt;

        //For each level UI object, set them to false to reset.
        foreach (GameObject level in meterLevels)
        {
            if (level.gameObject.activeInHierarchy == true)
            {
                level.gameObject.SetActive(false);
            }
        }

        //Then only activate the ones that are less than the meter counter/level.
        for (int i = 0; i < meterCounter / meterLevelInt; i++)
        {
            if (meterLevels[i] != null)
            {
                meterLevels[i].gameObject.SetActive(true);
            }
        }

        //If the counter equals the goal, it goes up a level (next goal is an extra 28) and reset the level UI.
        if (meterCounter == meterGoal && changeUp == true)
        {
            meterCounter = 0;
            counterText.text = "Count: " + meterCounter;
            meterGoal += 28;
            counterGoal.text = "Items Needed: " + meterGoal;
            Debug.Log("Next Level!!!");
            foreach (GameObject level in meterLevels)
            {
                if (level.gameObject.activeInHierarchy == true)
                {
                    level.gameObject.SetActive(false);
                }
            }
        }
    }

    IEnumerator Converter_Anim()
    {
        /* 
         * =====================================================================
         * This function controls the converter animation and starts the process for picking a new object.
         * =====================================================================
        */

        //Button clinking.
        while (runningConverter == false && cloudConverterUI.activeInHierarchy == true)
        {
            redButtonConverter.gameObject.SetActive(true);
            yield return new WaitForSeconds(.25f);
            redButtonConverter.gameObject.SetActive(false);
            yield return new WaitForSeconds(.25f);
        }

        //Converter shaking and then object picking.
        if (runningConverter == true)
        {
            cloudConverterUI.GetComponent<Animator>().enabled = true;
            cloudConverterUI.GetComponent<Animator>().Play("Converter_MainAnim", 0, 0f);

            yield return new WaitForSeconds(1.5f);
            cloudConverterUI.GetComponent<Animator>().enabled = false;
            runningConverter = false;
            ObjectPicker(-1);
            if (suckTool.GetComponent<Cloud_Suck_Tool>().goldCloudCount < 100)
            {
                cloudConverter.gameObject.SetActive(false);
                cloudConverterUI.gameObject.SetActive(false);
            }
            else
            {
                StartCoroutine(Converter_Anim());
            }
        }
    }
}
