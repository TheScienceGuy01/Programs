using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour
{
    public bool isPlayer;
    public GameObject playerHealthBar;
    public int health;

    public void IncreaseHealth()
    {

    }
    public void DecreaseHealth()
    {
        Debug.Log("Health Decreased");
        if (isPlayer)
        {
            for (int i = 0; i < playerHealthBar.transform.childCount; i++)
            {
                if (playerHealthBar.transform.GetChild(i).name.Contains("Cell"))
                {
                    if (playerHealthBar.transform.GetChild(i+1).name.Contains("Cell") && playerHealthBar.transform.GetChild(i+1).gameObject.activeInHierarchy == false)
                    {
                        playerHealthBar.transform.GetChild(i).gameObject.SetActive(false);
                    }
                    if (!playerHealthBar.transform.GetChild(i + 1).name.Contains("Cell"))
                    {
                        playerHealthBar.transform.GetChild(i).gameObject.SetActive(false);
                    }
                }
            }
        }

        if (health > 0)
        {
            health -= 1;
        }
        if (health == 0 && isPlayer == true)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

}
