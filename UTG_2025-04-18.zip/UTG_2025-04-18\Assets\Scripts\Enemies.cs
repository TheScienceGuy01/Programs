using System.Collections;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;


public class Enemies : MonoBehaviour
{
    public bool isDependent;
    public float jumpHeight;
    public bool isJumping;
    private Animator anim;
    public AnimationClip jumpAnim;
    private Rigidbody2D rb;
    public float peakVelocity;
    private bool canPeak;
    public GameObject body;
    public GameObject player;
    public float movementSpeed;
    public bool onHead;
    public bool isCollider;
    public GameObject physicalCollider;
    public GameObject triggerCollider;
    public float knockBackForce;
    public float hitDelay;
    public bool isDelay;
    public float initialHeight;
    public int objectsColliding;
    public Sprite onHeadSpriteEyes;
    public Sprite onHeadSpriteMouth;
    public Sprite offHeadSpriteEyes;
    public Sprite offHeadSpriteMouth;
    public Sprite defaultHeadSpriteEyes;
    public Sprite defaultHeadSpriteMouth;
    public float attackRange;
    public bool canAttack;
    public GameObject wholeParent;

    void Start()
    {
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        if (isDependent)
        {
            SetFirstFrame(jumpAnim);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (isDependent)
        {

            if (onHead != true && Vector2.Distance(transform.position, player.transform.position) < attackRange)
            {
                if (canAttack == false && isJumping == false && objectsColliding != 0)
                {
                    canAttack = true;
                    isJumping = true;
                    canPeak = false;
                    PlayFromPause(jumpAnim);
                    StartCoroutine(Delay());
                }

                if (rb != null)
                {
                    if (rb.linearVelocity.y < peakVelocity && canPeak == true && isJumping == true)
                    {
                        SetFirstFrame(jumpAnim);
                    }
                }

                if (isJumping == true && objectsColliding == 0)
                {
                    float newX = Mathf.MoveTowards(transform.position.x, player.transform.position.x, Mathf.Abs(transform.position.x - player.transform.position.x) * movementSpeed * Time.deltaTime);
                    transform.position = new Vector2(newX, transform.position.y);
                }
                if (objectsColliding != 0)
                {
                    isJumping = false;
                }
                else
                {
                    isJumping = true;
                }
            }

        }
    }

    IEnumerator Delay()
    {
        yield return new WaitForSeconds(.2f);
        if (GetComponent<Rigidbody2D>() != null)
        {
            GetComponent<Rigidbody2D>().AddForce(new Vector2(0f, jumpHeight), ForceMode2D.Impulse);

        }
        yield return new WaitForSeconds(.3f);
        canPeak = true;
        canAttack = false;
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.GetComponent<Object_Manager>() != null)
        {
            if (other.gameObject.CompareTag("Ground") && other.gameObject.GetComponent<Object_Manager>().isGhost == false)
            {
                if (isDependent != true)
                {
                    transform.parent.GetComponent<Enemies>().SetFirstFrame(jumpAnim);
                }
                objectsColliding += 1;
            }
        }
        else
        {
            if (other.gameObject.CompareTag("Ground"))
            {
                if (isDependent != true)
                {
                    transform.parent.GetComponent<Enemies>().SetFirstFrame(jumpAnim);

                }
                objectsColliding += 1;
            }
        }
        if (other.gameObject.CompareTag("Head") && isCollider && transform.parent.GetComponent<Enemies>().onHead == false && transform.parent.GetComponent<Enemies>().isDelay == false)
        {
            transform.parent.GetComponent<Enemies>().OnHead(other);
        }

        if (other.gameObject.GetComponent<Object_Manager>() != null)
        {
            if (other.gameObject.CompareTag("Ground") && isCollider && transform.parent.GetComponent<Enemies>().onHead == true && other.gameObject.GetComponent<Object_Manager>().isGhost == false)
            {
                if (other.GetComponent<Rigidbody2D>() != null && other.GetComponent<Rigidbody2D>().linearVelocity.magnitude * other.GetComponent<Rigidbody2D>().mass > 15)
                {

                    transform.parent.GetComponent<Enemies>().OffHead(other);
                }
            }
        }
        if (other.gameObject.CompareTag("Lava") && isCollider)
        {
            Destroy(wholeParent.gameObject);
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.GetComponent<Object_Manager>() != null)
        {
            if (other.gameObject.CompareTag("Ground") && other.gameObject.GetComponent<Object_Manager>().isGhost == false)
            {
                objectsColliding -= 1;
            }
        }
        else
        {
            if (other.gameObject.CompareTag("Ground"))
            {
                objectsColliding -= 1;
            }
        }
    }

    public void SetFirstFrame(AnimationClip animClip)
    {
        anim.Play(animClip.name, -1, 0f);
        anim.speed = 0;
    }

    public void SetLastFrame(AnimationClip animClip)
    {
        anim.Play(animClip.name, -1, 1f);
        anim.speed = 0;
    }

    public void PlayFromPause(AnimationClip animClip)
    {
        anim.speed = 1;
        anim.Play(animClip.name);
    }

    public void OnHead(Collider2D other)
    {
        transform.parent = other.transform;
        onHead = true;
        if (transform.GetComponent<Rigidbody2D>() != null)
        {
            Destroy(rb);
        }
        physicalCollider.transform.GetComponent<BoxCollider2D>().isTrigger = true;
        transform.position = other.transform.position;
        SetFirstFrame(jumpAnim);
        player.GetComponent<Player_Manager>().maxWalkSpeed = player.GetComponent<Player_Manager>().slowWalkSpeed;
        player.GetComponent<Player_Manager>().maxRunSpeed = player.GetComponent<Player_Manager>().slowRunSpeed;
        foreach (Transform x in transform)
        {
            if (x.gameObject.name.Contains("Eye"))
            {
                x.GetComponent<SpriteRenderer>().sprite = onHeadSpriteEyes;
            }
            if (x.gameObject.name.Contains("Mouth"))
            {
                x.GetComponent<SpriteRenderer>().sprite = onHeadSpriteMouth;
            }
        }
        player.GetComponent<Health>().DecreaseHealth();
    }

    void OffHead(Collider2D other)
    {
        transform.parent = null;

        triggerCollider.GetComponent<BoxCollider2D>().enabled = false;
        if (transform.GetComponent<Rigidbody2D>() == null)
        {
            transform.gameObject.AddComponent<Rigidbody2D>();

        }
        physicalCollider.transform.GetComponent<BoxCollider2D>().isTrigger = false;
        rb = GetComponent<Rigidbody2D>();
        transform.eulerAngles = new Vector2(0,0);
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        player.GetComponent<Player_Manager>().maxWalkSpeed = player.GetComponent<Player_Manager>().savedWalkSpeed;
        player.GetComponent<Player_Manager>().maxRunSpeed = player.GetComponent<Player_Manager>().savedRunSpeed;
        if (player.GetComponent<Player_Manager>().groundCount > 0)
        {
            player.GetComponent<Player_Manager>().groundCount -= 1;
        }
        if (other.transform.position.x < transform.position.x)
        {
            rb.AddForce(new Vector2(knockBackForce, 0f));
        }
        else
        {
            rb.AddForce(new Vector2(-knockBackForce, 0f));

        }
        foreach (Transform x in transform)
        {
            if (x.gameObject.name.Contains("Eye"))
            {
                x.GetComponent<SpriteRenderer>().sprite = offHeadSpriteEyes;
            }
            if (x.gameObject.name.Contains("Mouth"))
            {
                x.GetComponent<SpriteRenderer>().sprite = offHeadSpriteMouth;
            }
        }
        StartCoroutine(HitDelay());
    }

    IEnumerator HitDelay()
    {
        isDelay = true;
        yield return new WaitForSeconds(hitDelay);
        isDelay = false;
        onHead = false;
        triggerCollider.GetComponent<BoxCollider2D>().enabled = true;
        foreach (Transform x in transform)
        {
            if (x.gameObject.name.Contains("Eye"))
            {
                x.GetComponent<SpriteRenderer>().sprite = defaultHeadSpriteEyes;
            }
            if (x.gameObject.name.Contains("Mouth"))
            {
                x.GetComponent<SpriteRenderer>().sprite = defaultHeadSpriteMouth;
            }
        }
    }
}
