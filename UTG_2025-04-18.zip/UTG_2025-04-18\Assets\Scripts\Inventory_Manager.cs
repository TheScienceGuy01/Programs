using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine.Playables;

public class Inventory_Manager : MonoBehaviour
{
    public Sprite selectedInventorySprite;
    public Sprite notSelectedInventorySprite;

    public GameObject storageSlot1;
    public GameObject storageSlot2;
    public GameObject storageSlot2Item;
    public GameObject selectedObject;
    public GameObject nullSlotGameobject;

    public GameObject player;
    public GameObject[] powerups;
    public GameObject[] inventoryObjects;

    public bool slotFull;
    public bool slotSelected = true;

    public Sprite[] cardBackgrounds;
    public GameObject cardBackgroundObj;
    public bool animRunning = false;

    public GameObject inventoryHolder;
    public GraphicRaycaster raycaster;
    public EventSystem eventSystem;
    public string targetImageName = "Backpack_Inventory_Sprite"; // Change this to match your UI Image name
    public GameObject backPack;
    public Sprite hoverOverBackPackSprite;
    public Sprite backpackSprite;
    public bool toolBack;

    private void Start()
    {
        /* 
         * =====================================================================
         * This function handles initializing hotbar slots and initial cards
         * you get when the game starts.
         * =====================================================================
        */
        storageSlot2Item.GetComponent<Image>().sprite = null;
        slotSelected = true;

        //Initializes the preset sprites
        StartCoroutine(Initial_Inventory_Enable());
    }
    // Update is called once per frame
    void Update()
    {
        /* 
         * =====================================================================
         * This function updates as the scrollwheel gets turned, saves objects 
         * to the hotbar, and controls activing/deactivating the backpack UI.
         * =====================================================================
        */

        //Scroll Wheel for hotbar inventory items. Only runs if the cloud tool is not out.
        if ((Input.GetAxis("Mouse ScrollWheel") != 0f && player.GetComponent<Object_Spawner>().suckToolOut == false) || toolBack == true)
        {
            //If the slot is the first hotbar slot.
            if (slotSelected == false || toolBack == true)
            {
                toolBack = false;
                slotSelected = true;
                nullSlotGameobject.gameObject.SetActive(false);

                //Saves
                if (storageSlot2Item.GetComponent<Image>().sprite != null)
                {
                    player.GetComponent<Object_Spawner>().changeToSaved = true;
                }

                player.GetComponent<Object_Spawner>().ghostSpawner.gameObject.SetActive(true);

                //
                if (storageSlot2Item.GetComponent<Image>().sprite != null)
                {
                    player.GetComponent<Object_Spawner>().isClicked = true;
                }
                player.GetComponent<Object_Spawner>().nullSlots = false;
                storageSlot1.GetComponent<Image>().sprite = selectedInventorySprite;
                storageSlot2.GetComponent<Image>().sprite = notSelectedInventorySprite;

            }
            //Second Slot hotbar.
            else
            {
                slotSelected = false;
                if (storageSlot2Item.GetComponent<Image>().sprite == null)
                {
                    player.GetComponent<Object_Spawner>().nullSlots = true;
                    nullSlotGameobject.gameObject.SetActive(true);
                    player.GetComponent<Object_Spawner>().ghostSpawner.gameObject.SetActive(false);
                }
                else
                {
                    player.GetComponent<Object_Spawner>().isClicked = true;
                }
                storageSlot2.GetComponent<Image>().sprite = selectedInventorySprite;
                storageSlot1.GetComponent<Image>().sprite = notSelectedInventorySprite;
            }
        }

        //Saves objects into the second slot.
        foreach (GameObject x in inventoryObjects)
        {
            if (Input.GetKeyDown(KeyCode.E) && player.GetComponent<Object_Spawner>().chosenObject.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains(x.gameObject.name))
            {
                slotFull = false;

                //Does not save if the slot is already filled.
                foreach (GameObject y in inventoryObjects)
                {
                    if (y.activeInHierarchy == true)
                    {
                        slotFull = true;
                        break;
                    }
                }

                if (slotFull == true && slotSelected == true)
                {
                    Debug.Log("Slot full!");
                }

                //Sets the object image to the saved item.
                if (slotFull == false && slotSelected == true)
                {
                    foreach (SpawnableObject z in (player.GetComponent<Object_Spawner>().objects))
                    {
                        if (z.solidObject.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains(x.gameObject.name))
                        {
                            selectedObject = z.solidObject;
                            break;
                        }
                    }
                    storageSlot2Item.GetComponent<Image>().sprite = player.GetComponent<Object_Spawner>().chosenObject.GetComponent<Object_Manager>().presentedSprite;

                    x.gameObject.SetActive(true);
                    player.GetComponent<Object_Spawner>().saveNext = true;
                    player.GetComponent<Object_Spawner>().isClicked = true;
                }
            }
        }

        //Used for mouse clicking the backpack item.
        if (IsPointerOverUIElement(targetImageName))
        {
            backPack.GetComponent<Image>().sprite = hoverOverBackPackSprite;
            //If the left mouse button is pressed over the backpack sprite, then it turns the inventory off or on.
            player.GetComponent<Object_Spawner>().clickableSprite = true;
            if (Input.GetMouseButtonDown(0) && inventoryHolder.activeInHierarchy == false)
            {
                inventoryHolder.SetActive(true);
            }
            else if (Input.GetMouseButtonDown(0) && inventoryHolder.activeInHierarchy == true)
            {
                inventoryHolder.SetActive(false);
            }
        }
        else
        {
            if (inventoryHolder.activeInHierarchy == false)
            {
                //Allows for items to be places again 
                player.GetComponent<Object_Spawner>().clickableSprite = false;
            }
            if (backPack.GetComponent<Image>().sprite != backpackSprite)
            {
                backPack.GetComponent<Image>().sprite = backpackSprite;

            }
        }
    }

    public void CardAnim(int rarity, Sprite itemSprite)
    {
        /* 
         * =====================================================================
         * This function handles animation controls for the card pop ups when a
         * new item is added.
         * =====================================================================
        */

        //Sets all cards to false.
        foreach (Transform card in cardBackgroundObj.transform)
        {
            card.gameObject.SetActive(false);
        }

        //Plays the animation.
        cardBackgroundObj.gameObject.SetActive(true);
        GetComponent<Animator>().Play("New_Item_Anim",0, 0f);

        //Sets active the correct card to display.
        cardBackgroundObj.GetComponent<Image>().sprite = cardBackgrounds[rarity];
        foreach (Transform card in cardBackgroundObj.transform)
        {
            if (itemSprite.name.Contains(card.name))
            {
                card.gameObject.SetActive(true);
                Enable_Inventory_Card(card.gameObject.name);
            }
        }
        StartCoroutine(Animation_Controls());
    }

    public IEnumerator Animation_Controls()
    {
        /* 
         * =====================================================================
         * This function handles animation ending by waiting 5 seconds until the
         * next item can be chosen.
         * =====================================================================
        */
        animRunning = true;
        yield return new WaitForSeconds(5);
        cardBackgroundObj.gameObject.SetActive(false);
        animRunning = false;
    }

    bool IsPointerOverUIElement(string uiElementName)
    {
        /* 
         * =====================================================================
         * This function handles mouse over canvas image processing. This
         * returns a bool that tells if the mouse is hovering over a canvas item.
         * =====================================================================
        */

        //Gets mouse position and sets the point event.
        PointerEventData pointerData = new PointerEventData(eventSystem);
        pointerData.position = Input.mousePosition;

        //Gets objects it hits.
        List<RaycastResult> results = new List<RaycastResult>();
        raycaster.Raycast(pointerData, results);

        //For each if the item is the chosen item (uiElementName) then it returns true.
        foreach (RaycastResult result in results)
        {
            if (result.gameObject.name == uiElementName)
            {
                return true;
            }
        }

        return false;
    }

    IEnumerator Initial_Inventory_Enable()
    {
        /* 
         * =====================================================================
         * This function handles inventory card enabling when the backpack is
         * opened.
         * =====================================================================
        */

        //Waits 1 second from the start of the game and places the initial cards active.
        yield return new WaitForSeconds(1);
        string spriteName;
        string card;
        foreach (SpawnableObject obj in player.GetComponent<Object_Spawner>().objects)
        {
            spriteName = obj.solidObject.name;
            card = spriteName.Split('_')[0];
            Enable_Inventory_Card(card);
        }
    }

    public void Enable_Inventory_Card(string itemName)
    {        
        /* 
         * =====================================================================
         * This function enables the correct cards to be active in the backpack
         * inventory.
         * =====================================================================
        */

        //For each category of item, and for each item, if the name is similar, then the color is changed to white.
        for (int i = 0; i < inventoryHolder.transform.childCount; i++)
        {
            foreach (Transform card in inventoryHolder.transform.GetChild(i))
            {
                if (card.gameObject.name.Contains(itemName))
                {
                    card.GetComponent<Image>().color = Color.white;
                    card.transform.GetChild(0).GetComponent<Image>().color = Color.white;
                }
            }
        }
    }
}
