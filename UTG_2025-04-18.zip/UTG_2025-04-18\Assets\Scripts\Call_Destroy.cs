using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Call_Destroy : MonoBehaviour
{
    public float timeToDestroy;
    void Start()
    {
        StartCoroutine(Destroy_Object());
    }

    IEnumerator Destroy_Object()
    {
        yield return new WaitForSeconds(timeToDestroy);
        Destroy(gameObject);
    }
}
