using System.Collections;
using UnityEngine;

public class PowerUps_Update : MonoBehaviour
{
    private Rigidbody2D rb;
    private bool isDelayed = true;
    private bool clearToRun = true;
    private Vector3 lastPosition;
    public int waitTime = 2;
    public GameObject player;
    public float transparencySpeed;
    private SpriteRenderer sp;
    public float alphaVal = 1;
    private bool switchTrans;
    private bool corotineOn;
    private void Start()
    {
        /* 
         * =====================================================================
         * This function initializes delay for item stability checking so that
         * immediate spawning does not have a magnitude of 0.
         * =====================================================================
        */
        rb = GetComponent<Rigidbody2D>();
        sp = GetComponent<SpriteRenderer>();
        StartCoroutine(DelayedChecking());
    }

    private void FixedUpdate()
    {
        /* 
         * =====================================================================
         * This function updates to check for item stability.
         * =====================================================================
        */

        //If the item has a RB and is not moving much, then it starts the coroutine that checks if it is stable for a set amount of time.
        if (rb != null && rb.linearVelocity.magnitude <= .1f && isDelayed == false && clearToRun == true)
        {
            lastPosition = transform.position;
            clearToRun = false;
            corotineOn = true;
            StartCoroutine(IsStable());
        }

        //Else it stops the coroutine if the item moves before the coroutine is up.
        else
        {
            if (corotineOn == true)
            {
                clearToRun = true;
                StopCoroutine(IsStable());
            }
        }

        //Visual representation that the item is waiting to get stability verified.
        if (switchTrans == true)
        {
            alphaVal -= transparencySpeed;
        }
        else
        {
            alphaVal += transparencySpeed;
        }

        sp.color = new Color(1f, 1f, 1f, alphaVal);


        if (alphaVal >= 1)
        {
            switchTrans = true;
        }
        if (alphaVal <= 0)
        {
            switchTrans = false;
        }
    }

    IEnumerator DelayedChecking()
    {        
        /* 
         * =====================================================================
         * This function waits one second for the object to gain a magnitude so
         * that instant spawning does not trigger the stability checker.
         * =====================================================================
        */
        yield return new WaitForSeconds(1);
        isDelayed = false;
    }

    public IEnumerator IsStable()
    {        
        /* 
         * =====================================================================
         * This function checks if the object is stable after a certain amount
         * of time. If so the script is deleted and the meter goes up by 1.
         * =====================================================================
        */

        yield return new WaitForSeconds(waitTime);

        //Checks if the object is in the same location as before.
        if (transform.position == lastPosition)
        {
            player.GetComponent<Object_Spawner>().MeterChange(true);
            sp.color = new Color(1f, 1f, 1f, 1);
            Destroy(GetComponent<PowerUps_Update>());
        }
        else
        {
            clearToRun = true;
        }
    }

}
