using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Player_Collider : MonoBehaviour
{
    public int touchingCrumbs;
    public bool isSideColliders;
    public int touchingWalls;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isSideColliders == false)
        {
            if (other.gameObject.CompareTag("Ground"))
            {
                touchingCrumbs += 1;
            }
            if (other.gameObject.CompareTag("Lava"))
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }
        }
        else
        {
            if (other.gameObject.CompareTag("Ground"))
            {
                touchingWalls += 1;
            }
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (isSideColliders == false)
        {
            if (other.gameObject.CompareTag("Ground"))
            {
                touchingCrumbs -= 1;
            }
        }
        else
        {
            if (other.gameObject.CompareTag("Ground"))
            {
                touchingWalls -= 1;
            }
        }
    }
}