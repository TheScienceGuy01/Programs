using System.Collections;
using UnityEngine;
public class Tails : MonoBehaviour
{
    public float speed;
    public GameObject target;
    public float distanceUntilMove;

    // Update is called once per frame
    void Update()
    {

        if (Vector2.Distance(transform.position, target.transform.position) > distanceUntilMove)
        {
            if (target.GetComponent<Rigidbody2D>() != null)
            {
                speed = target.GetComponent<Rigidbody2D>().linearVelocity.magnitude+1;
            }

        }
        else if (target.GetComponent<Rigidbody2D>() == null || Vector2.Distance(transform.position, target.transform.position) <= distanceUntilMove)
        {
            speed = 3/(distanceUntilMove/2);
        }
        transform.position = Vector2.MoveTowards(transform.position, target.transform.position, speed * Time.deltaTime);

    }
}
