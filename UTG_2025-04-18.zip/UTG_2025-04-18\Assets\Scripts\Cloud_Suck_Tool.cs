using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Cloud_Suck_Tool : MonoBehaviour
{
    public bool isOn;
    public float cloudSuckSpeed;
    public float suckDistance;
    public float distanceUntilDespawn;
    public List<GameObject> clouds = new List<GameObject>();
    public int cloudCount;
    public int goldCloudCount;
    public GameObject player;
    public float decelerationSpeed;

    private void FixedUpdate()
    {
        /* 
         * =====================================================================
         * This function handles gold and normal cloud movement. This function
         * also helps with counting clouds and getting rid of them from the
         * cloud list if needed.
         * =====================================================================
        */

        //Foreach cloud that is in the game, then it checks if the cloud tool is on and within a certain distance.
        foreach (GameObject cloud in clouds)
        {
            if (cloud != null)
            {
                //If the tool is on, then it moves the clouds towards teh tool.
                if (Vector2.Distance(cloud.transform.position, transform.position) < suckDistance && isOn)
                {
                    cloud.GetComponent<Cloud_Parts>().speed = cloudSuckSpeed;
                    cloud.transform.position = Vector2.MoveTowards(cloud.transform.position, transform.position, cloudSuckSpeed * Time.deltaTime);
                    if (Vector2.Distance(cloud.transform.position, transform.position) < distanceUntilDespawn)
                    {
                        //If the cloud is gold then it +1 is sent to the goldcloudcount.
                        if (cloud.GetComponent<Cloud_Parts>().isGold == true)
                        {
                            goldCloudCount += 1;

                            player.transform.GetComponent<Object_Spawner>().goldCloudCounter.text = "Gold Clouds: " + goldCloudCount;
                            if (goldCloudCount >= 100)
                            {
                                player.GetComponent<Object_Spawner>().CloudConverter(goldCloudCount / 100);
                            }
                        }
                        else
                        {
                            cloudCount += 1;

                            player.transform.GetComponent<Object_Spawner>().cloudCounter.text = "Clouds: " + cloudCount;

                        }
                        Destroy(cloud.gameObject);
                    }
                }
                else
                {
                    //If the tool is not on but the cloud is still moving (like if the suck tool sucked then was off) the cloud still has resisual movement.
                    if (cloud.GetComponent<Cloud_Parts>().speed - decelerationSpeed > 0)
                    {
                        cloud.GetComponent<Cloud_Parts>().speed -= decelerationSpeed;
                        cloud.transform.position = Vector2.MoveTowards(cloud.transform.position, transform.position, cloud.GetComponent<Cloud_Parts>().speed * Time.deltaTime);
                    }
                }
            }
        }

        //If the tool is off and the cloud count is not 0, then it will remove the null clouds from the clouds list. This is for clean up.
        if (isOn == false && clouds.Count != 0)
        {
            for (int i = 0; i < clouds.Count; i++)
            {
                if (clouds[i] == null)
                {
                    clouds.Remove(clouds[i]);
                }
            }
        }
    }
}
