using System.Collections;
using UnityEngine;

public class Shaking : MonoBehaviour
{
    private Vector2 startPos;
    public bool isForever;
    public float time;
    public float shakeIntensity;
    public float shakeSpeed;

    void Start()
    {
        startPos = transform.localPosition;
        StartCoroutine(Start_Shaking());
    }

    IEnumerator Start_Shaking()
    {
        float startTime = 0;

        while (isForever == false && startTime < time)
        {
            transform.localPosition = new Vector2(startPos.x + Random.Range(-shakeIntensity, shakeIntensity), startPos.y + Random.Range(-shakeIntensity, shakeIntensity)) ;

            yield return new WaitForSeconds(shakeSpeed);
            startTime += shakeSpeed;
        }
        while (isForever == true)
        {
            transform.localPosition = new Vector2(startPos.x + Random.Range(-shakeIntensity, shakeIntensity), startPos.y + Random.Range(-shakeIntensity, shakeIntensity));

            yield return new WaitForSeconds(shakeSpeed);
            startTime += shakeSpeed;
        }
    }
}
