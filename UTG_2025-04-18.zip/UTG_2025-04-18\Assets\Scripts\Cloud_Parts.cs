using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;

public class Cloud_Parts : MonoBehaviour
{
    public float cloudPulseMin;
    public float cloudPulseMax;
    public float cloudPulseRateMax;
    public float cloudPulseRateMin;
    public float cloudPulseRateRate;
    public float cloudPulseRate;
    public bool flip = false;
    public float speed;
    public bool isGold;

    private void Start()
    {
        /* 
         * =====================================================================
         * This function initializes cloud pulses and the unique range each one
         * can pulse at.
         * =====================================================================
        */
        cloudPulseMin = transform.localScale.x;
        cloudPulseRateMax = Random.Range(0.1f,0.3f);
        cloudPulseRate = cloudPulseRateMax;
        cloudPulseMax = cloudPulseMin + 3;
    }

    private void FixedUpdate()
    {
        /* 
         * =====================================================================
         * This function handles rates in which the clouds pulsate.
         * =====================================================================
        */

        //Pulsates the cloud's localscale to show pulastions.
        if (flip == false && transform.localScale.x < cloudPulseMax)
        {

            if (cloudPulseRate > cloudPulseRateMin)
            {
                cloudPulseRate /= cloudPulseRateRate;
            }
            transform.localScale = new Vector3(transform.localScale.x+ cloudPulseRate, transform.localScale.y+cloudPulseRate, transform.localScale.z+cloudPulseRate);
        }
        else
        {
            if (flip == false)
            {
                cloudPulseRate = cloudPulseRateMax;
                flip = true;
            }
        }

        if (flip == true && transform.localScale.x > cloudPulseMin)
        {
            if (cloudPulseRate > cloudPulseRateMin)
            {
                cloudPulseRate /= cloudPulseRateRate;
            }
            transform.localScale = new Vector3(transform.localScale.x - cloudPulseRate, transform.localScale.y - cloudPulseRate, transform.localScale.z - cloudPulseRate);
        }
        else
        {
            if (flip == true)
            {
                cloudPulseRate = cloudPulseRateMax;
                flip = false;
            }
        }
    }
}
