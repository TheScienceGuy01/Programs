using System.Linq;
using UnityEditor;
using UnityEngine;
using System.Collections.Generic;


public class Sky_Spawning : MonoBehaviour
{
    public GameObject boundary1;
    public GameObject boundary2;

    public SpawnableObject[] possibleSpawns;

    public int spawnAmount;

    public bool isCloud;
    public GameObject[] cloudParts;
    public float cloudRadius;
    public int cloudPartAmount;
    public GameObject mainCloud;
    public int mainCloudSpawnRate;
    private GameObject temp;
    public GameObject spawnHolder;

    public GameObject cloudTool;

    public bool isIsland;
    public float islandWidth;
    public float islandHeight;
    public GameObject surfacePiece;
    public Sprite[] centerPieces;
    public Sprite[] sidePieces;
    public Sprite[] bottomPieces;
    public Sprite[] grassPieces;
    public Sprite[] sideGrassPieces;
    public Sprite[] pointedSides;
    public GameObject spawned;
    public GameObject spawned1;
    public List<Vector2> previousLocations = new List<Vector2>();
    public bool cantOverlap;
    public float distanceThreshold;
    private bool tooClose;

    private void Start()
    {
        /* 
         * =====================================================================
         * Based on the boundary objects, spawns clouds.
         * =====================================================================
        */

        //If the object is a cloud, then it spawns the amount that is set. If not, then cloud objects spawn within the boundary. This includes gold spawns.
        if (isCloud == false)
        {
            if (isIsland == false)
            {
                for (int i = 0; i < spawnAmount; i++)
                {
                    float randX = Random.Range(boundary1.transform.position.x, boundary2.transform.position.x);
                    float randY = Random.Range(boundary1.transform.position.y, boundary2.transform.position.y);
                    Vector2 spawnPosition = new Vector2(randX, randY);

                    bool chosen = false;

                    if (cantOverlap == true)
                    {
                        foreach (Vector2 pos in previousLocations)
                        {
                            if (Vector2.Distance(spawnPosition, pos) < distanceThreshold)
                            {
                                tooClose = true;
                            }
                        }
                    }
                    Debug.Log("refererfeferferf");
                    while (chosen == false && tooClose == false)
                    {
                        int ObjectIndexer = Random.Range(0, possibleSpawns.Length);
                        if ((float)possibleSpawns[ObjectIndexer].spawnRate / 100 > Random.value)
                        {
                            chosen = true;
                            temp = Instantiate(possibleSpawns[ObjectIndexer].solidObject, spawnPosition, boundary1.transform.rotation);
                            temp.SetActive(true);
                            temp.transform.parent = spawnHolder.transform;
                            previousLocations.Add(spawnPosition);
                        }
                    }
                    tooClose = false;
                }
            }
        }
        else
        {
            float newScale = 0;
            for (int i = 0; i < cloudPartAmount; i++)
            {
                newScale = Random.Range(4f, 10f);
                if (Random.value > (float)mainCloudSpawnRate/100)
                {
                    temp = Instantiate(cloudParts[Random.Range(0, cloudParts.Length)], Random.insideUnitCircle * cloudRadius + (Vector2)transform.position, transform.rotation);
                    cloudTool.GetComponent<Cloud_Suck_Tool>().clouds.Add(temp);
                }
                else
                {
                    temp = Instantiate(mainCloud, Random.insideUnitCircle * cloudRadius + (Vector2)transform.position, transform.rotation);
                    cloudTool.GetComponent<Cloud_Suck_Tool>().clouds.Add(temp);
                }
                temp.transform.localScale = new Vector3(newScale, newScale, newScale);
                temp.transform.parent = transform;
            }
        }
        if (isIsland == true)
        {
            float heights = Mathf.RoundToInt(islandHeight / islandWidth);
            Debug.Log(heights);
            bool isInitial = false;

            for (int i = 0; i < islandWidth; i++)
            {
                if (isInitial == false)
                {
                    spawned = Instantiate(surfacePiece, transform.position, transform.rotation);
                    spawned.GetComponent<SpriteRenderer>().sprite = sidePieces[Random.Range(0, sidePieces.Length)];
                    spawned1 = spawned;
                    isInitial = true;
                }
                else
                {
                    spawned = Instantiate(surfacePiece, spawned.transform.GetChild(1).transform.position, spawned.transform.rotation);
                    spawned.transform.GetChild(0).gameObject.GetComponent<SpriteRenderer>().sprite = grassPieces[Random.Range(0, grassPieces.Length)];
                    spawned1 = spawned;
                    if (i == islandWidth - 1)
                    {
                        spawned.GetComponent<SpriteRenderer>().sprite = sidePieces[Random.Range(0, sidePieces.Length)];
                        spawned.GetComponent<SpriteRenderer>().flipX = true;
                    }
                    else
                    {
                        spawned.GetComponent<SpriteRenderer>().sprite = centerPieces[Random.Range(0, centerPieces.Length)];

                    }
                }
                spawned.transform.parent = transform;
                spawned1.transform.parent = transform;
                if (islandWidth / 2 >= i)
                {
                    for (int j = 0; j < heights*i; j++)
                    {
                        spawned1 = Instantiate(surfacePiece, spawned1.transform.GetChild(3).transform.position, spawned1.transform.rotation);
                        if (j == heights * i - 1)
                        {
                            spawned1.GetComponent<SpriteRenderer>().flipX = false;
                            if (i != (int)islandWidth/2)
                            {
                                spawned1.GetComponent<SpriteRenderer>().sprite = sidePieces[Random.Range(0, sidePieces.Length)];
                            }
                            else
                            {
                                spawned1.GetComponent<SpriteRenderer>().sprite = pointedSides[Random.Range(0, pointedSides.Length)];
                            }
                        }
                        spawned1.transform.GetChild(0).gameObject.SetActive(false);
                        spawned.transform.parent = transform;
                        spawned1.transform.parent = transform;
                    }
                }
                else
                {
                    for (int j = 0; j < heights * (islandWidth - i-1); j++)
                    {
                        spawned1 = Instantiate(surfacePiece, spawned1.transform.GetChild(3).transform.position, spawned1.transform.rotation);
                        if (j+1 >= heights * (islandWidth - i - 1))
                        {
                            spawned1.GetComponent<SpriteRenderer>().flipX = true;
                            spawned1.GetComponent<SpriteRenderer>().sprite = sidePieces[Random.Range(0,sidePieces.Length)];
                        }
                        spawned1.transform.GetChild(0).gameObject.SetActive(false);
                        spawned.transform.parent = transform;
                        spawned1.transform.parent = transform;
                    }
                }
                if (i == 0 || i == islandWidth - 1)
                {
                    spawned.transform.GetChild(0).transform.localPosition = new Vector2(0, 0.2945f);
                    spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().sprite = sideGrassPieces[Random.Range(0, sideGrassPieces.Length)];
                }
                if (i == islandWidth - 1)
                {
                    spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().flipX = true;
                }
                spawned.transform.parent = transform;
                spawned1.transform.parent = transform;
            }
        }
    }
}
