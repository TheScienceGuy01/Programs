"""
    Course: IT 101-01 Spring 2020
    Program: iirizarry-IT-Project-040920-v6.00.py
    Description: This version contributed to side-scrolling enemies and sprite design.
    Author(s): Israel Irizarry (iirizarry33@students.cumberland.edu)
    Date:07-April-2020, Version 6.00 Improved enemy movements, added sprites, and improved framerate
    
    Objective(s):
        Create a series of enemies that move indepentently of their peers.
    
    Algorithm:
        1. Make the enemies contribute to screen scrolling through rewritten AI.
        2. Create character sprites for the player, enemies, and environment.
            **NOTE: The level design is still a work in progress.
        3. Improve framerate by placing it as a variable.

    **TO DO**:
        1. Create a better bullet system
        2. Create collisions for level design and gameplay elements
        3. Menu screen
        
    OS, IDLE and Python Versions:
       Windows 10 Home 1809
       IDLE 3.8
       Python 3.8.1
       
    Command line:
    C:/Users/Israel>iirizarry-IT-Project-040920-v6.00.py

    Output:

    Run program
"""
#Imports Libraries and creates canvas
import random
import pygame
pygame.init()

#Display and sprites
win = pygame.display.set_mode((1000,800))
pygame.display.set_caption("IT Project")

playerSprite = pygame.image.load('player1.png')
block = pygame.image.load('practice2.png')
bullet = pygame.image.load('bullet.png')
testEnemy = pygame.image.load('enemySprite.png')
ground = pygame.image.load('ground.png')
background = pygame.image.load('background.png')

#Easily controls the framerate of the game
framerate = 5

#--------------------------------------------------------------------------------------
#Class for object oriented programming.
class player(object):
    '''
    Is used to manage all sprites and converts the to object oriented programming.
    '''
    def __init__(self,x,y,width,height):
        #Player and static object Variables
        self.x = 300
        self.y = 470
        self.bubbleX = x+500
        self.restrictBullet = False
        self.yi = y
        self.width = 64
        self.vel = 5
        self.jumpPower = 50
        self.jumping = False
        self.jumpDown = self.jumpPower
        self.jumpSaved = self.jumpPower
        self.scrollValue = 0
        self.staticObjectX = 400
        self.staticObjectY = 100
        
        #Bullet stuff
        self.bulletColor = (255,255,23)
        self.bulletSpeed = 100
        self.bulletX = 0
        self.bulletY = 0
        self.fire = False
        self.bulletGO = False

        #Enemy AI variables
        self.enemySpeed = 2
        self.changedEnemySpeed = self.enemySpeed
        self.enemyLerp = 5
        
    def draw(self,win):
        '''
        Draws all the sprites and is called by the mainDraw function.
        '''
        win.fill((0,0,0))
        win.blit(background,(self.x-350,0))
        win.blit(block,(self.staticObjectX,self.staticObjectY))
        win.blit(playerSprite,(int(self.x),int(self.y)))
        win.blit(bullet,(int(self.bulletX),int(self.bulletY)))
        win.blit(ground,(self.staticObjectX,self.staticObjectY+100))
        win.blit(ground,(self.staticObjectX-550,self.staticObjectY+100))
        win.blit(ground,(self.staticObjectX+550,self.staticObjectY+100))
        win.blit(ground,(self.staticObjectX+1100,self.staticObjectY+100))
        win.blit(testEnemy,(self.enemyXList[0], self.enemyYList[0]))
        win.blit(testEnemy,(self.enemyXList[1], self.enemyYList[1]))
        win.blit(testEnemy,(self.enemyXList[2], self.enemyYList[2]))
    def fireBullet(self,win):
        '''
        Controls the bullet'pooo.txt
        '''
        self.bulletY = self.y
        self.bulletX = self.x
        self.fire = False
        self.restrictBullet = True
        
    def bulletGo(self):
        '''
        Shoots the bullet and makes sure it can't be fired again until it has
        an x value greater bubbleX.
        '''
        self.bulletX += self.bulletSpeed
        if (self.bulletX > self.bubbleX):
            self.restrictBullet = False

    def enemyAI(self):
        '''
        Controls the enemy's movement towards the player and whether it gets hit or not
        **NOTE: This will most likely get changed to fine tune the behaviour of the enemy sprite(s).
        '''

        #Sprites for 3 enemies
        pygame.display.update()
        
        #Movement towards the player
        #Loops through each element in each enemy's x and y value and changes them accordingly
        for i in range(len(self.enemyXList)):
            if (self.enemyXList[i]) > self.x:
                self.enemyXList[i] -= self.enemySpeed
            if (self.enemyXList[i] <= self.x):
                self.changedEnemySpeed = self.enemySpeed
                self.enemyXList[i] += self.enemySpeed
            if (self.enemyYList[i] > self.y):
                self.enemyYList[i] -= self.enemySpeed
            if (self.enemyYList[i] <= self.y):
                changedEnemySpeed = self.enemySpeed
                self.enemyYList[i] += self.enemySpeed
            #Executed when the enemy is shot
            if (self.bulletX >= self.enemyXList[i] - 50 and self.bulletX <= self.enemyXList[i] + 50 and self.bulletY >= self.enemyYList[i] - 20 and self.bulletY <= self.enemyYList[i] + 20):
                pygame.Rect(400,100,50,50)
                self.enemySpeed = 0

        #Changes the x value of the enemies based on side-scrolling movement
        keys = pygame.key.get_pressed()
        for i in range(len(self.enemyXList)):
            if keys[pygame.K_d]:
                self.enemyXList[i] -= self.vel
        for i in range(len(self.enemyXList)):
            if keys[pygame.K_a]:
                self.enemyXList[i] += self.vel

    def enemySpawning(self):
        '''
        Only called once to initialize each enemy's position and stores it in an array.
        It also randomizes their position.
        '''
        #Creates the list needed for storage
        self.enemyCount = 3
        self.currentEnemies = 0
        self.enemyXList = []
        self.enemyYList = []

        #Creates initial random variables
        while self.currentEnemies < self.enemyCount:
            self.enemyXList.append(random.randint(-200,600))
            self.enemyYList.append(random.randint(75,575))
            self.currentEnemies+=1
            print(self.currentEnemies)
        currentEnemies = 0
        print("done")
#--------------------------------------------------------------------------------------
def mainDraw1():
    '''
    Is the 'artist' and calls the draw function in the player class.
    This function also is a link to other parts of the player class.
    '''
    player1.draw(win)
    if (player1.fire == True):
        player1.fireBullet(win)
        player1.bulletGO = True
    if (player1.bulletGO == True):
        player1.bulletGo()
    pygame.display.update()

#Makes the player class available gloabally
player1 = player(300,470,64,64)
#Loop that controls all events and character interactions
gameOn = True
player1.enemySpawning()

while gameOn:
    player1.enemyAI()
    pygame.time.delay(framerate)
    #------------------------------------------------------------------------------
    #Player, enemy, and static object movement
    for event in pygame.event.get():
        if (event.type==pygame.QUIT):
            gameOn = False
        if (event.type == pygame.MOUSEBUTTONDOWN and player1.restrictBullet == False):
            player1.fire = True

    #Side-scrolling movement
    keys = pygame.key.get_pressed()
    if keys[pygame.K_d]:
        player1.staticObjectX -= player1.vel
    if keys[pygame.K_a]:
        player1.staticObjectX += player1.vel
        
    #Controls jumping
    if keys[pygame.K_SPACE]:
        player1.jumping = True
    if player1.jumping:
        if (player1.jumpPower >= 1):
            player1.jumpPower = player1.jumpPower/1.3
            player1.y -= player1.jumpPower
            player1.jumpDown = player1.jumpPower
        if (player1.jumpPower < 1 and player1.jumping):
            player1.jumpDown = player1.jumpDown*1.3
            player1.y += player1.jumpDown
            if (player1.yi <= player1.y):
                player1.y = player1.yi
                player1.jumping = False
                player1.jumpDown = player1.jumpSaved
                player1.jumpPower = player1.jumpSaved
    #------------------------------------------------------------------------------
    #Calls the mainDraw function
    mainDraw1()
#Quits game if the X button in the right corner is pressed
pygame.quit()
