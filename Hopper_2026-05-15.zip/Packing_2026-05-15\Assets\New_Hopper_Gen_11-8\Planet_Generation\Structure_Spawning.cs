using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

[System.Serializable]
public class StructurePiece
{
    public GameObject pieceObj;
    public GameObject nextPiece;
    public Vector2 nextPieceOffSet;
    public float modelOrientation;

    public int pieceObjDirection;
    public int nextPieceDirection;
    public int pieceAmount;

    public bool noOritentation;

    public bool goUntilStopped;
    public int maxSpawnCap;
    public float stopDistance;
    public bool ignoreWater;

    public GameObject fillObj;
    public bool fillDown;

    public bool isVariableLength;
    public Vector2Int variableLengthMinMax;
}

public class Structure_Spawning : MonoBehaviour
{
    public List<StructurePiece> structurePieces = new List<StructurePiece>();
    public GameObject gameManager;
    Game_Manager gm;
    public GameObject planet;
    public GameObject spawned;
    public List<GameObject> structureParts = new List<GameObject>();
    public List<GameObject> structureObjs = new List<GameObject>();
    public List<GameObject> subStructures = new List<GameObject>();
    public float delay;
    public bool isSubStructure;
    public GameObject mainStructure;
    public float subStructureChance;
    public bool stopCont;
    public LayerMask crumbLayer;
    public bool canDestroyCrumbs;
    public float destroyCrumbDistance;
    public bool canDestroyObj;
    public float destroyObjDistance;
    public GameObject fillerHolder;
    Spawning_Manager sm;
    private void Start()
    {
        if (Random.value > subStructureChance && isSubStructure)
        {
            //Debug.Log("Should be destroyed");
            Destroy(transform.GetChild(0).gameObject);
        }
        else
        {
            gm = gameManager.GetComponent<Game_Manager>();
            planet = transform.parent.transform.parent.transform.GetChild(0).gameObject;
            sm = planet.GetComponent<Spawning_Manager>();
            structureParts.Add(structurePieces[0].pieceObj);
            if (isSubStructure)
            {
                planet = mainStructure.GetComponent<Structure_Spawning>().planet;
                structureParts.Add(structurePieces[0].pieceObj.transform.GetChild(1).GetChild(structurePieces[0].pieceObjDirection).gameObject);
            }
            else
            {
                Vector2 directionToPlanet = planet.transform.position - transform.GetChild(0).transform.position;

                // Calculate angle so that bottom (negative Y) faces the planet
                float angle = Mathf.Atan2(directionToPlanet.y, directionToPlanet.x) * Mathf.Rad2Deg - 90f + 180;

                // Apply rotation
                transform.GetChild(0).transform.rotation = Quaternion.Euler(0f, 0f, angle);
            }
            StartCoroutine(StartBuilding());
        }
    }
    IEnumerator StartBuilding()
    {
        foreach (StructurePiece piece in structurePieces)
        {
            if (piece.goUntilStopped == true)
            {
                sm.stillSpawningStructures += 1;

            }
        }
        yield return new WaitForSeconds(delay);
        foreach (StructurePiece piece in structurePieces)
        {
            if (piece.goUntilStopped == false)
            {
                if (piece.isVariableLength)
                {
                    piece.pieceAmount = Random.Range(piece.variableLengthMinMax.x,piece.variableLengthMinMax.y);
                }
                for (int i = 0; i < piece.pieceAmount; i++)
                {
                    Transform parentObj = null;
                    if (i == 0 && piece.pieceObj == null)
                    {
                        piece.pieceObj = spawned;
                    }
                    if (i == 0)
                    {
                        parentObj = piece.pieceObj.transform.GetChild(1).GetChild(piece.pieceObjDirection).transform;
                        spawned = Instantiate(piece.nextPiece, piece.pieceObj.transform.GetChild(1).GetChild(piece.pieceObjDirection).transform.position, Quaternion.identity);
                        structureObjs.Add(spawned);
                        if (piece.noOritentation == false)
                        {
                            structureParts.Add(spawned.transform.GetChild(1).GetChild(piece.nextPieceDirection).gameObject);
                        }
                        spawned.transform.parent = parentObj;
                    }
                    else
                    {
                        parentObj = spawned.transform.GetChild(1).GetChild(piece.nextPieceDirection).transform;

                        spawned = Instantiate(piece.nextPiece, spawned.transform.GetChild(1).GetChild(piece.nextPieceDirection).transform.position, Quaternion.identity);
                        structureObjs.Add(spawned);
                        if (piece.noOritentation == false)
                        {
                            structureParts.Add(spawned.transform.GetChild(1).GetChild(piece.nextPieceDirection).gameObject);
                        }
                        spawned.transform.parent = parentObj;

                    }
                    spawned.transform.GetChild(0).transform.rotation = Quaternion.Euler(0, 0, piece.modelOrientation);
                    spawned.transform.position += (Vector3)piece.nextPieceOffSet;
                    spawned.transform.localRotation = Quaternion.identity;
                    if (spawned.GetComponent<Structure_Spawning>() != null)
                    {
                        subStructures.Add(spawned);
                        spawned.GetComponent<Structure_Spawning>().mainStructure = gameObject;
                    }
                    Vector2 directionToPlanet = planet.transform.position - spawned.transform.position;

                    // Calculate angle so that bottom (negative Y) faces the planet
                    float angle = Mathf.Atan2(directionToPlanet.y, directionToPlanet.x) * Mathf.Rad2Deg - 90f + 180;

                    // Apply rotation
                    spawned.transform.rotation = Quaternion.Euler(0f, 0f, angle);

                    if (canDestroyCrumbs)
                    {
                        DestroyCrumbs(spawned);
                    }

                    if (piece.fillDown)
                    {
                        StartCoroutine(FillDown(spawned, piece.fillObj,piece.maxSpawnCap));
                    }
                }
            }
            else
            {
                stopCont = false;
                piece.pieceObj = spawned;
                int maxSpawnCount = 0;

                while (stopCont == false && maxSpawnCount <= piece.maxSpawnCap)
                {
                    maxSpawnCount += 1;
                    yield return null;
                    // Debug.Log("Keep going....");
                    Transform parentObj = null;
                    parentObj = spawned.transform.GetChild(1).GetChild(piece.nextPieceDirection).transform;

                    spawned = Instantiate(piece.nextPiece, spawned.transform.GetChild(1).GetChild(piece.nextPieceDirection).transform.position, Quaternion.identity);
                    structureObjs.Add(spawned);
                    if (piece.noOritentation == false)
                    {
                        structureParts.Add(spawned.transform.GetChild(1).GetChild(piece.nextPieceDirection).gameObject);
                    }
                    spawned.transform.parent = parentObj;
                    spawned.transform.GetChild(0).transform.rotation = Quaternion.Euler(0, 0, piece.modelOrientation);
                    spawned.transform.position += (Vector3)piece.nextPieceOffSet;
                    spawned.transform.localRotation = Quaternion.identity;

                    if (spawned.GetComponent<Structure_Spawning>() != null)
                    {
                        spawned.GetComponent<Structure_Spawning>().mainStructure = gameObject;

                        subStructures.Add(spawned);
                    }

                    //Stopping ongoing spawning

                    Collider2D[] hits = Physics2D.OverlapCircleAll(
                        spawned.transform.position,
                        piece.stopDistance,
                        crumbLayer
                    );

                    foreach (Collider2D hit in hits)
                    {
                        if (hit != null && hit.GetComponent<Crumb_Manager>() != null)
                        {
                            if (hit.GetComponent<Crumb_Manager>().isWater == false)
                            {
                                //Debug.Log("Stopping Piece Spawns");
                                stopCont = true;
                                sm.stillSpawningStructures -= 1;

                                break;
                            }
                            else if (piece.ignoreWater == false)
                            {
                                //Debug.Log("Stopping Piece Spawns");
                                stopCont = true;
                                sm.stillSpawningStructures -= 1;

                                break;
                            }
                        }
                    }
                    Vector2 directionToPlanet = planet.transform.position - spawned.transform.position;

                    // Calculate angle so that bottom (negative Y) faces the planet
                    float angle = Mathf.Atan2(directionToPlanet.y, directionToPlanet.x) * Mathf.Rad2Deg - 90f + 180;

                    // Apply rotation
                    spawned.transform.rotation = Quaternion.Euler(0f, 0f, angle);

                    if (canDestroyCrumbs)
                    {
                        DestroyCrumbs(spawned);
                    }

                    if (piece.fillDown)
                    {
                        StartCoroutine(FillDown(spawned, piece.fillObj,piece.maxSpawnCap));
                    }
                }
            }
        }
        structureParts = structureParts.Distinct().ToList();
        foreach (GameObject subS in subStructures)
        {
            //Debug.Log("enabled:" + subS.name);
            subS.GetComponent<Structure_Spawning>().enabled = true;
        }
        if (canDestroyObj)
        {
            DestroyObjs();
        }
    }

    void DestroyCrumbs(GameObject obj)
    {
        Collider2D[] hits = Physics2D.OverlapCircleAll(
            obj.transform.position,
            destroyCrumbDistance,
            crumbLayer
        );

        foreach (Collider2D hit in hits)
        {
            if (hit.GetComponent<Crumb_Manager>() != null)
            {
                Destroy(hit.gameObject); // or mark mined
            }
        }
    }
    void DestroyObjs()
    {
        foreach (GameObject obj in structureObjs)
        {
            Collider2D hit = Physics2D.OverlapCircle(obj.transform.position, destroyObjDistance, crumbLayer);
            if (hit != null && obj.GetComponent<Structure_Spawning>() == null && hit.GetComponent<Crumb_Manager>() != null)
            {
                if (obj.GetComponent<SpriteRenderer>() != null)
                {
                    obj.GetComponent<SpriteRenderer>().enabled = false;

                }
                if (obj.GetComponent<Structure_Spawning>() == null)
                {
                    obj.transform.GetChild(0).gameObject.SetActive(false);

                }

            }
        }
    }
    IEnumerator FillDown(GameObject obj, GameObject fillObj,int maxCount)
    {
        GameObject fillSpawned;
        fillSpawned = Instantiate(fillObj, obj.transform.GetChild(1).GetChild(1).transform.position, obj.transform.rotation);
        fillSpawned.transform.SetParent(fillerHolder.transform);
        int maxSpawnCount = 0;
        while (maxSpawnCount <= maxCount)
        {
            maxSpawnCount += 1;
            yield return null;
            fillSpawned = Instantiate(fillObj, fillSpawned.transform.GetChild(1).GetChild(1).transform.position, fillSpawned.transform.GetChild(0).transform.rotation);
            fillSpawned.transform.SetParent(fillerHolder.transform);
            if (Physics2D.OverlapCircle(fillSpawned.transform.position, .2f, crumbLayer))
            {
                //Debug.Log("Stopping Piece Spawns");
                break;
            }
        }
    }
}
