﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]

public class PlayerAttacks
{
    public int uid;
    public float attackLength;
    public bool noAttackLengthLimit;
    public string testingDialog;
    public AnimationClip attackAnim;
    public GameObject displayModel;

    [Header("Gun Settings")]
    public GameObject armModel;
    public GameObject gunModel;
    public bool isGun;
    public GameObject shootPoint;
    public GameObject projectile;
    public int clipSize;
    public int maxClipSize;
    public float reloadSpeed;
    public bool isReloading;
    public bool canBeHeldDown;
}
public class Player_Manager : MonoBehaviour
{
    [Header("GameObjects Used")]
    public GameObject planet;
    public GameObject groundedObj;
    public GameObject groundTrigger;
    public GameObject wallTrigger;
    public GameObject controllerInUse;
    public GameObject gameManager;
    public GameObject model;
    public GameObject cameraObj;

    [Header("Movement Variables")]
    public float moveSpeed;
    public float curSpeed;
    public float sprintSpeed;
    public bool isSprinting;
    public float jumpForce;
    public float waterJumpForce;
    public bool isJumping;
    public bool pressedJump;
    public bool waterPressedJump;
    public float waterGravity;
    public float waterSpeed;
    public float movementDrag;
    public float gravRotSpeed;

    [Header("State Variables")]
    public bool isControlled;
    public bool isInSpace;
    public bool inWater;
    public bool canMoveRight;
    public bool canMoveLeft;
    public bool isMoving;

    [Header("Misc Variables")]
    public float itemSuckDistance;
    public float itemSuckForce;

    [Header("Attacks")]
    public bool isAttacking;
    public List<PlayerAttacks> attacks = new List<PlayerAttacks>();
    public PlayerAttacks chosenAttack;

    [Header("Testing Variables")]
    public float input;
    public float prevInput;
    public bool dirPressed = false;
    public bool executedJump;
    public bool canFlip;
    public bool flipDir;
    public GameObject reloadText;

    [Header("Animation Variables")]
    public AnimationClip currentAnim;
    public AnimationClip idleAnim;
    public AnimationClip walkingAnim;
    public AnimationClip runningAnim;
    public AnimationClip meleeTestAnim;
    public AnimationClip jumpingAnim;
    public AnimationClip chosenAnim;
    public GameObject defaultArm;

    Rigidbody2D rb;
    Game_Manager gm;
    Building_Manager bm;
    public Health h;
    Main_Camera_Manager cam;
    Animator modelAnim;


    private void Start()
    {
        h = GetComponent<Health>();
        rb = GetComponent<Rigidbody2D>();
        gm = gameManager.GetComponent<Game_Manager>();
        bm = gameManager.GetComponent<Building_Manager>();
        cam = cameraObj.GetComponent<Main_Camera_Manager>();
        modelAnim = model.GetComponent<Animator>();
    }

    private void Update()
    {
        if (isControlled == false && isInSpace == false)
        {
            if (Input.GetButtonDown("Jump") && (isJumping == false && inWater == false) && gm.buildingOn == false)
            {
                pressedJump = true;
                executedJump = false;
            }
            if (Input.GetButton("Jump") && inWater)
            {
                waterPressedJump = true;
            }
            else
            {
                waterPressedJump = false;
            }
            if (Input.GetKeyDown(KeyCode.LeftShift) && gm.buildingOn == false)
            {
                if (isSprinting == false)
                {
                    isSprinting = true;
                    SetAnimation();
                }
                else
                {
                    isSprinting = false;
                }
            }
        }
        if (chosenAttack == null)
        {
            //Debug.Log(defaultArm.activeInHierarchy);
            if (defaultArm.activeInHierarchy == false)
            {
                gm.UpdateWeaponInHand();

                defaultArm.SetActive(true);
            }
        } 
        else if (chosenAttack.isGun)
        {
            Vector3 mousePos = Input.mousePosition;
            mousePos.z = -gm.mainCamera.transform.position.z; // distance from camera to 0-plane

            Vector3 worldPos = gm.mainCamera.ScreenToWorldPoint(mousePos);
            worldPos.z = 0;

            Vector2 directionToPlanet = (Vector2)worldPos - rb.position;

            float angle = Mathf.Atan2(directionToPlanet.y, directionToPlanet.x) * Mathf.Rad2Deg;

            if (chosenAttack.armModel.activeInHierarchy == false)
            {
                //Debug.Log("should b setting on");
                chosenAttack.armModel.SetActive(true);
                chosenAttack.displayModel.SetActive(true);
                defaultArm.SetActive(false);
            }

            chosenAttack.armModel.transform.rotation = Quaternion.Euler(0f, 0f, angle + 90);

            Vector2 localPos = transform.InverseTransformPoint(chosenAttack.gunModel.transform.position);
            if (flipDir == true)
            {
                if (localPos.x > 0)
                {
                    //Debug.Log("is facing right");
                    Vector3 scale = chosenAttack.gunModel.transform.localScale;
                    scale.y = Mathf.Abs(scale.y);
                    chosenAttack.gunModel.transform.localScale = scale;
                }
                else
                {
                    //Debug.Log("is facing left");

                    Vector3 scale = chosenAttack.gunModel.transform.localScale;
                    scale.y = -Mathf.Abs(scale.y);
                    chosenAttack.gunModel.transform.localScale = scale;
                }
                chosenAttack.shootPoint.transform.localRotation = Quaternion.Euler(0, 0, 0);
            }
            else
            {
                if (localPos.x > 0)
                {
                    //Debug.Log("is facing right");
                    Vector3 scale = chosenAttack.gunModel.transform.localScale;
                    scale.y = -Mathf.Abs(scale.y);
                    chosenAttack.gunModel.transform.localScale = scale;
                }
                else
                {
                    //Debug.Log("is facing left");

                    Vector3 scale = chosenAttack.gunModel.transform.localScale;
                    scale.y = Mathf.Abs(scale.y);
                    chosenAttack.gunModel.transform.localScale = scale;
                }
                chosenAttack.shootPoint.transform.localRotation = Quaternion.Euler(0, 180, 0);

            }

            if (chosenAttack.isGun && chosenAttack.clipSize != chosenAttack.maxClipSize && Input.GetKeyDown(KeyCode.R) && chosenAttack.isReloading == false)
            {
                //Debug.Log("Reloading!");
                chosenAttack.isReloading = true;
                StartCoroutine(Reload());
            }
        }
        else if (!chosenAttack.isGun)
        {
            if (chosenAttack.armModel != null)
            {
                if (chosenAttack.armModel.activeInHierarchy == false)
                {
                    //Debug.Log("should b setting on");
                    defaultArm.SetActive(false);

                    chosenAttack.armModel.SetActive(true);
                    if (chosenAttack.displayModel)
                    {
                        chosenAttack.displayModel.SetActive(true);

                    }
                }
            }

        }
    }

    private void FixedUpdate()
    {
        if (isControlled == false && isInSpace == false && gm.buildingOn == false)
        {
            h.CheckFallDamage();

            //Checks movement
            if (rb.linearVelocity.magnitude > 0.01f)
            {
                isMoving = true;
                SetAnimation();
            }
            else
            {
                isMoving = false;
                SetAnimation();
            }

            curSpeed = 0;
            if (planet != null)
            {
                Vector2 jumpDir = (rb.position - (Vector2)planet.transform.position).normalized;
                //Jumping
                if (pressedJump && executedJump == false)
                {
                    rb.AddForce(jumpDir * jumpForce, ForceMode2D.Impulse);
                    //Debug.Log("Player Jumped");
                    executedJump = true;
                    SetAnimation();
                }
            }
            if (waterPressedJump)
            {
                rb.AddRelativeForce(Vector2.up * waterJumpForce, ForceMode2D.Impulse);
                //Debug.Log("Player Jumped WATER");

            }

            if (inWater == false)
            {
                if (isSprinting == false)
                {
                    curSpeed = moveSpeed;
                }
                else
                {
                    curSpeed = sprintSpeed;
                }
            }
            else
            {
                isSprinting = false;
            }
            if (isSprinting == false)
            {
                if (inWater == false)
                {
                    curSpeed = moveSpeed;
                }
                else
                {
                    curSpeed = waterSpeed;
                }
            }
            if (planet != null)
            {
                Vector2 directionToPlanet = (planet.transform.position - transform.position).normalized;
                input = Input.GetAxis("Horizontal");
                if (input == 0)
                {
                    isSprinting = false;
                }
                if ((Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D)))
                {
                    if (isJumping)
                    {
                        if ((Input.GetKey(KeyCode.A) && prevInput < 0 && input > prevInput) || (Input.GetKey(KeyCode.D) && prevInput > 0 && input < prevInput))
                        {
                            input = prevInput;
                        }
                    }
                    if ((Input.GetKey(KeyCode.A) && !canMoveLeft) || (Input.GetKey(KeyCode.D) && !canMoveRight))
                    {
                        input = 0;
                        //Debug.Log("Input should be 0");
                    }
                    Vector2 platformVelocity = Vector2.zero;

                    if (groundedObj != null)
                    {
                        Rigidbody2D platRb = groundedObj.GetComponent<Rigidbody2D>();
                        if (platRb != null)
                            platformVelocity = platRb.linearVelocity;
                    }

                    Vector2 tangent = new Vector2(-directionToPlanet.y, directionToPlanet.x);

                    // Current velocity RELATIVE to platform
                    Vector2 relativeVelocity = rb.linearVelocity - platformVelocity;

                    // Extract current tangent component
                    float currentTangentSpeed = Vector2.Dot(relativeVelocity, tangent);

                    // Desired tangent speed
                    float desiredTangentSpeed = input * curSpeed;

                    // Compute delta only on tangent axis
                    float deltaTangentSpeed = desiredTangentSpeed - currentTangentSpeed;

                    // Apply force ONLY along tangent
                    Vector2 force = tangent * deltaTangentSpeed * rb.mass / Time.fixedDeltaTime;

                    float TANGENT_EPSILON = 0.1f;

                    if (Mathf.Abs(deltaTangentSpeed) > TANGENT_EPSILON)
                    {
                        force = tangent * deltaTangentSpeed * rb.mass / Time.fixedDeltaTime;
                        rb.AddForce(force);
                    }
                    prevInput = input;
                    FlipPlayer();
                }
            }
        }
        if ((isControlled == false && isInSpace == false && planet != null))
        {
            Vector2 directionToPlanet = (Vector2)planet.transform.position - rb.position;

            float angle = Mathf.Atan2(directionToPlanet.y, directionToPlanet.x) * Mathf.Rad2Deg - 90f + 180f;
            Quaternion targetRotation = Quaternion.Euler(0, 0, angle);
            transform.rotation = Quaternion.RotateTowards(
                transform.rotation,
                targetRotation,
                gravRotSpeed * Time.deltaTime
            );
        }
        if (isJumping == true)
        {
            pressedJump = false;
        }
    }

    public void InController()
    {
        transform.parent.SetParent(controllerInUse.transform);
        Destroy(rb);
        isControlled = true;
        transform.position = controllerInUse.transform.position + controllerInUse.transform.up * 1f;
        transform.rotation = controllerInUse.transform.rotation;
    }
    public void ExitController()
    {
        isControlled = false;
        Debug.Log("Should be exiting");
        transform.parent.SetParent(null);
        rb = gameObject.AddComponent<Rigidbody2D>();
        rb.gravityScale = 0;
        rb.interpolation = RigidbodyInterpolation2D.Interpolate;
        rb.mass = 2;
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
        rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        h.rb = rb;
        groundTrigger.GetComponent<Ground_Trigger_v2>().ResetFromMissingRB();
        wallTrigger.GetComponent<Ground_Trigger_v2>().ResetFromMissingRB();
    }

    public void SetInSpace()
    {
        isInSpace = true;
        planet.GetComponent<Generation_Manager>().gravityAffectedObjs.Remove(gameObject);
        planet.SetActive(false);
        planet = null;
    }
    public void SetOnPlanet()
    {
        isInSpace = false;
        planet.SetActive(true);

        cam.planet = planet;

        gameManager.GetComponent<Game_Manager>().genManager = planet;
        gameManager.GetComponent<Game_Manager>().currentPlanet = planet;
        gameManager.GetComponent<Game_Manager>().gm = planet.GetComponent<Generation_Manager>();
    }
    public void GetChosenAttack(int uid)
    {
        foreach (PlayerAttacks attack in attacks)
        {
            if (attack.uid == uid)
            {
                chosenAttack = attack;
                chosenAttack.displayModel.SetActive(true);
                if (chosenAttack.isReloading)
                {
                    chosenAttack.isReloading = false;
                }
                break;
            }
            else if (chosenAttack != null)
            {
                if (attack.isGun && chosenAttack.isGun)
                {
                    attack.clipSize = chosenAttack.clipSize;
                }
                attack.displayModel.SetActive(false);
            }
        }
    }
    public IEnumerator Reload()
    {
        if (chosenAttack.isReloading)
        {
            reloadText.SetActive(true);
            yield return new WaitForSeconds(chosenAttack.reloadSpeed);
            chosenAttack.clipSize = chosenAttack.maxClipSize;
            chosenAttack.isReloading = false;
            reloadText.SetActive(false);
            //Debug.Log("Reloaded!");
        }
    }
    public IEnumerator Attacks()
    {
        isAttacking = true;
        SetAnimation();
        if (isAttacking == true)
        {
            if (chosenAttack.isReloading == false)
            {
                if (chosenAttack.isGun && chosenAttack.clipSize > 0)
                {
                    //shoot goes here.
                    //Debug.Log("BAM!");
                    chosenAttack.clipSize -= 1;
                    GameObject proj = Instantiate(chosenAttack.projectile, chosenAttack.shootPoint.transform.position, chosenAttack.shootPoint.transform.rotation);
                    proj.GetComponent<Projectiles>().parentObj = gameObject;
                    proj.SetActive(true);

                }
            }
            if (chosenAttack.isReloading == false)
            {
                if (!chosenAttack.isGun)
                {
                    yield return new WaitForSeconds(chosenAttack.attackAnim.length);

                }
                else
                {
                    yield return new WaitForSeconds(chosenAttack.attackLength);

                }
            }
        }
        isAttacking = false;
    }

    public void FlipPlayer()
    {
        if (canFlip == true)
        {
            if (input > 0)
            {
                Vector3 scale = model.transform.localScale;
                scale.x = Mathf.Abs(scale.x);
                model.transform.localScale = scale;
                flipDir = true;
            }
            else if (input < 0)
            {
                Vector3 scale = model.transform.localScale;
                scale.x = -Mathf.Abs(scale.x);
                model.transform.localScale = scale;
                flipDir = false;
            }
        }
    }

    public void SetAnimation()
    {
        //Sprinting
        if (isSprinting && isAttacking == false && isMoving && !isJumping)
        {
            chosenAnim = runningAnim;
        }

        //Walking
        if (isMoving && !isSprinting && isAttacking == false && !isJumping)
        {
            chosenAnim = walkingAnim;
        }

        //Idle
        if (!isMoving && isAttacking == false && !isJumping)
        {
            chosenAnim = idleAnim;
        }

        //Jumping
        if (isJumping && isAttacking == false)
        {
            //Debug.Log("jumpin!!!!");
            chosenAnim = jumpingAnim;
        }

        if (isAttacking == true && !chosenAttack.isGun)
        {
            chosenAnim = chosenAttack.attackAnim;
        }

        if (chosenAnim != currentAnim)
        {
            currentAnim = chosenAnim;
            modelAnim.CrossFade(currentAnim.name, .08f);
        }
    }
}
