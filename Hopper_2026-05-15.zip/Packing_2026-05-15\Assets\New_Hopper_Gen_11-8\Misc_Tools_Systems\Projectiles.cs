using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Projectiles : MonoBehaviour
{
    public float launchForce;
    Rigidbody2D rb;
    public GameObject gameManager;
    Game_Manager gm;
    public int projectileDamage;
    public GameObject parentObj;
    bool hasHit;
    public float lifeTime;
    private void Start()
    {
        gm = gameManager.GetComponent<Game_Manager>();
        rb = GetComponent<Rigidbody2D>();
        rb.AddForce(launchForce * transform.right, ForceMode2D.Impulse);
        StartCoroutine(DestroyProjectile());
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("MiningTool"))
        {
            if (hasHit)
            {
                return;
            }
            if (other.GetComponent<Crumb_Manager>() != null)
            {
                if (other.GetComponent<Crumb_Manager>().isAir == false)
                {
                    CheckPlayerCollider(other);
                    CheckNPCCollider(other);
                }
            }
            else
            {
                CheckPlayerCollider(other);
                CheckNPCCollider(other);
            }
            if (other.CompareTag("Planet_Atmosphere"))
            {
                if (!other.transform.parent.GetChild(0).GetComponent<Generation_Manager>().gravityAffectedObjs.Contains(gameObject))
                {
                    other.transform.parent.GetChild(0).GetComponent<Generation_Manager>().gravityAffectedObjs.Add(gameObject);
                }
            }
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Planet_Atmosphere"))
        {
            other.transform.parent.GetChild(0).GetComponent<Generation_Manager>().gravityAffectedObjs.Remove(gameObject);
        }
    }
    void CheckPlayerCollider(Collider2D other)
    {
        GameObject otherParent = null;

        if (other.transform.parent != null)
        {
            otherParent = other.transform.parent.gameObject;
        }

        Player_Manager otherParentNPC = null;

        if (otherParent != null)
        {
            otherParentNPC = otherParent.gameObject.GetComponent<Player_Manager>();

        }
        Player_Manager otherNPC = null;
        if (other.gameObject.GetComponent<Player_Manager>())
        {
            otherNPC = other.gameObject.GetComponent<Player_Manager>();
        }
        bool hasParent = false;
        if (otherParent != null)
        {
            hasParent = true;
        }

        if (hasParent)
        {
            if (otherParent != parentObj && other.gameObject != parentObj)
            {
                if (otherNPC)
                {
                    otherNPC.h.ChangeHealth(projectileDamage);
                    //Debug.Log("Hit something: " + other.gameObject.name + " Parent:" + parentObj.name);
                    hasHit = true;
                    Destroy(gameObject);
                    return;
                }
                if (otherParentNPC)
                {
                    //Debug.Log("Hit something: " + other.gameObject.name + " Parent:" + parentObj.name);

                    otherParentNPC.h.ChangeHealth(projectileDamage);
                    hasHit = true;

                    Destroy(gameObject);
                    return;

                }
            }
            if (!otherNPC && !otherParentNPC && otherParent != parentObj && other.gameObject != parentObj && !other.CompareTag("Planet_Atmosphere") && !other.CompareTag("Attack"))
            {
                //Debug.Log("Hit something: " + other.gameObject.name + " Parent:" + otherParent.name);
                hasHit = true;

                Destroy(gameObject);
                return;

            }
        }
        else
        {
            if (other.gameObject != parentObj)
            {
                if (otherNPC)
                {
                    //Debug.Log("Hit something: " + other.gameObject.name + " Parent:" + parentObj.name);

                    otherNPC.h.ChangeHealth(projectileDamage);
                    hasHit = true;

                    Destroy(gameObject);
                    return;

                }
            }
            if (other.gameObject != parentObj && !otherNPC && !other.CompareTag("Planet_Atmosphere") && !other.CompareTag("Attack"))
            {
                //Debug.Log("Hit something: " + other.gameObject.name + " Parent:" + parentObj.name);
                hasHit = true;

                Destroy(gameObject);
                return;

            }
        }
    }
    void CheckNPCCollider(Collider2D other)
    {
        GameObject otherParent = null;

        if (other.transform.parent != null)
        {
            otherParent = other.transform.parent.gameObject;
        }

        NPC_Manager otherParentNPC = null;

        if (otherParent != null)
        {
            otherParentNPC = otherParent.gameObject.GetComponent<NPC_Manager>();

        }
        NPC_Manager otherNPC = null;

        if (other.gameObject.GetComponent<NPC_Manager>())
        {
            otherNPC = other.gameObject.GetComponent<NPC_Manager>();
        }
        bool hasParent = false;
        if (otherParent != null)
        {
            hasParent = true;
        }


        if (hasParent)
        {
            if (otherParent != parentObj && other.gameObject != parentObj)
            {
                //Debug.Log($"otherNPC: {other.name}, otherParentNPC: {otherParent.name}");
                if (otherNPC)
                {
                    otherNPC.FightFlight(parentObj);
                    //Debug.Log("Hit something: " + other.gameObject.name + " Parent:" + otherParent.name);
                    otherNPC.h.ChangeHealth(projectileDamage);
                    hasHit = true;

                    Destroy(gameObject);
                    return;

                }
                else if (otherParentNPC)
                {
                    //Debug.Log("Hit something: " + other.gameObject.name + " Parent:" + otherParent.name);

                    otherParentNPC.FightFlight(parentObj);
                    otherParentNPC.h.ChangeHealth(projectileDamage);
                    hasHit = true;

                    Destroy(gameObject);
                    return;

                }
            }
            if (!otherNPC && !otherParentNPC && otherParent != parentObj && other.gameObject != parentObj && !other.CompareTag("Planet_Atmosphere") && !other.CompareTag("Attack"))
            {
                //Debug.Log("Hit something: " + other.gameObject.name + " Parent:" + otherParent.name);
                hasHit = true;

                Destroy(gameObject);
                return;

            }
        }
        else
        {
            if (other.gameObject != parentObj)
            {
                if (otherNPC)
                {
                    //Debug.Log("Hit something: " + other.gameObject.name + " Parent:" + otherParent.name);

                    otherNPC.FightFlight(parentObj);
                    otherNPC.h.ChangeHealth(projectileDamage);
                    hasHit = true;

                    Destroy(gameObject);
                    return;

                }
            }
            if (other.gameObject != parentObj && !otherNPC && !other.CompareTag("Planet_Atmosphere") && !other.CompareTag("Attack"))
            {
                //Debug.Log("Hit something: " + other.gameObject.name + " Parent:" + otherParent.name);
                hasHit = true;

                Destroy(gameObject);
                return;

            }
        }
    }
    IEnumerator DestroyProjectile()
    {
        yield return new WaitForSeconds(lifeTime);
        Destroy(gameObject);
    }
}
