using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Ground_Trigger_v2 : MonoBehaviour
{
    public GameObject parentObj;
    public int currCollisions;
    public List<GameObject> collisionObjs = new List<GameObject>();
    public bool isWallCollider;
    public bool isLoadTrigger;
    Player_Manager pm;

    private void Start()
    {
        if (parentObj == null)
        {
            parentObj = transform.parent.gameObject;
        }
        pm = parentObj.GetComponent<Player_Manager>();
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("MiningTool") && !other.CompareTag("BuildTool"))
        {
            //Debug.Log("starting trigger check" + other.tag);
            if (isWallCollider == false && isLoadTrigger == false)
            {
                //Debug.Log("triggered someting");
                if (other.CompareTag("Crumb"))
                {
                    if (other.GetComponent<Crumb_Manager>() != null)
                    {
                        if (other.GetComponent<Crumb_Manager>().isAir == false)
                        {
                            //Debug.Log("crumb should be added");
                            currCollisions += 1;
                            collisionObjs.Add(other.gameObject);
                            pm.isJumping = false;
                            if (other.GetComponent<Rigidbody2D>() != null)
                            {
                                pm.groundedObj = other.gameObject;

                            }
                        }
                    }
                    else
                    {
                        currCollisions += 1;
                        collisionObjs.Add(other.gameObject);
                        pm.isJumping = false;
                        if (other.GetComponent<Rigidbody2D>() != null)
                        {
                            pm.groundedObj = other.gameObject;

                        }
                    }
                }
                else if (other.CompareTag("Planet_Atmosphere"))
                {
                    //Debug.Log("Setting on Planet");
                    if (pm.planet == null)
                    {
                        pm.planet = other.transform.parent.GetChild(0).gameObject;
                        pm.SetOnPlanet();
                    }
                }
                else
                {
                    currCollisions += 1;
                    collisionObjs.Add(other.gameObject);
                    pm.isJumping = false;
                    if (other.GetComponent<Rigidbody2D>() != null)
                    {
                        pm.groundedObj = other.gameObject;

                    }
                }
            }
            else if (isLoadTrigger == false)
            {
                if (!other.CompareTag("Planet_Atmosphere"))
                {
                    if (other.GetComponent<Crumb_Manager>())
                    {
                        if (!other.GetComponent<Crumb_Manager>().isAir)
                        {
                            collisionObjs.Add(other.gameObject);
                            currCollisions += 1;
                            CheckValidSides();
                        }
                    }
                    else
                    {
                        if (other.GetComponent<Object_Manager>() != null)
                        {
                            if (!other.GetComponent<Object_Manager>().isController)
                            {
                                collisionObjs.Add(other.gameObject);
                                currCollisions += 1;
                                CheckValidSides();
                            }
                        }
                        else
                        {
                            collisionObjs.Add(other.gameObject);
                            currCollisions += 1;
                            CheckValidSides();
                        }
                    }
                }

            }
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (!other.CompareTag("MiningTool") && !other.CompareTag("BuildTool"))
        {
            //Debug.Log("starting trigger exit" + other.tag);

            if (isWallCollider == false && isLoadTrigger == false)
            {
                if (other.CompareTag("Crumb"))
                {
                    if (other.GetComponent<Crumb_Manager>() != null)
                    {
                        if (other.GetComponent<Crumb_Manager>().isAir == false)
                        {
                            currCollisions -= 1;
                            collisionObjs.Remove(other.gameObject);

                            if (currCollisions == 0)
                            {
                                pm.groundedObj = null;
                                pm.isJumping = true;
                            }
                        }
                    }
                    else
                    {
                        currCollisions -= 1;
                        collisionObjs.Remove(other.gameObject);

                        if (currCollisions == 0)
                        {
                            pm.groundedObj = null;
                            pm.isJumping = true;
                        }
                    }
                }
                else if (other.CompareTag("Planet_Atmosphere"))
                {
                    //debug.Log("Setting In Space" + other.name);
                    pm.SetInSpace();

                }
                else
                {
                    currCollisions -= 1;
                    collisionObjs.Remove(other.gameObject);

                    if (currCollisions == 0)
                    {
                        pm.groundedObj = null;
                        pm.isJumping = true;
                    }

                }
            }
            else if (isLoadTrigger == false)
            {
                if (!other.CompareTag("Planet_Atmosphere"))
                {
                    if (other.GetComponent<Crumb_Manager>())
                    {
                        if (!other.GetComponent<Crumb_Manager>().isAir)
                        {
                            collisionObjs.Remove(other.gameObject);

                            currCollisions -= 1;
                            CheckValidSides();
                        }
                    }
                    else
                    {
                        collisionObjs.Remove(other.gameObject);

                        currCollisions -= 1;
                        CheckValidSides();
                    }
                }
            }
        }
    }

    void CheckValidSides()
    {
        pm.canMoveLeft = true;
        pm.canMoveRight = true;
        foreach (GameObject obj in collisionObjs)
        {
            Vector2 localPos = transform.InverseTransformPoint(obj.transform.position);

            if (localPos.x > 0)
            {
                pm.canMoveRight = false;
            }
            else
            {
                pm.canMoveLeft = false;

            }
        }
    }

    public void RemoveGoneCrumbsManually(GameObject colliderObj)
    {
        for (int i = 0; i < collisionObjs.Count; i++)
        {
            
            if (collisionObjs[i] != null)
            {
                if (collisionObjs[i] == colliderObj)
                {
                    currCollisions -= 1;
                    collisionObjs.Remove(collisionObjs[i]);
                    //Debug.Log("Should have removed count: " + collisionObjs.Count);
                    if (currCollisions == 0)
                    {
                        pm.groundedObj = null;
                        pm.isJumping = true;
                    }
                }
            }
        }
    }
    public void ResetFromMissingRB()
    {
        currCollisions = 0;
        collisionObjs.Clear();
    }
}
