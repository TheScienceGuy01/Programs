using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using TMPro;
using Unity.VisualScripting;

[System.Serializable]
public struct BuildingInfo
{
    public Item itemInfo;
    public GameObject obj;
    public bool isPhysicsObj;
}
public class Building_Manager : MonoBehaviour
{
    public List<BuildingInfo> buildingObjs = new List<BuildingInfo>();
    public GameObject gameManager;
    Game_Manager gm;
    Item_Drops itemD;
    GameObject spawned;
    Slot_Manager handlerSM;
    public GameObject onHandler;
    public BuildingInfo foundObj;
    public Camera mainCamera;
    public List<GameObject> sensorsInScene = new List<GameObject>();
    public List<GameObject> handlerSensors = new List<GameObject>();
    public List<GameObject> anchorObjs = new List<GameObject>();
    public List<GameObject> allObjects = new List<GameObject>();
    public GameObject snapableObj;
    public float sensorDistCheck;
    public float rotateAmount;
    public GameObject buildingTool;
    public bool canDisconnect;
    public GameObject objToDisconnect;
    private void Start()
    {
        itemD = GetComponent<Item_Drops>();
        gm = gameManager.GetComponent<Game_Manager>();
        handlerSM = gm.handler.GetComponent<Slot_Manager>();
    }

    private void LateUpdate()
    {
        Vector3 mousePos = Input.mousePosition;
        mousePos.z = -mainCamera.transform.position.z; // distance from camera to 0-plane

        Vector3 worldPos = mainCamera.ScreenToWorldPoint(mousePos);
        worldPos.z = 0;
        if (gm.isObjOnHanlder == false && buildingTool.activeInHierarchy == false)
        {
            buildingTool.SetActive(true);
        }
        else
        {
            if (gm.isObjOnHanlder == true && buildingTool.activeInHierarchy == true)
            {
                buildingTool.SetActive(false);
            }
        }
        buildingTool.transform.position = worldPos;

        if (onHandler != null)
        {
            onHandler.transform.position = worldPos;

        }

        if (Input.GetMouseButtonDown(0) && objToDisconnect != null && handlerSM.isHandlerFree && gm.isInventoryOn == false)
        {
            //Debug.Log("Should be destroying obj");
            foundObj = buildingObjs.Find(s => s.itemInfo.uID == objToDisconnect.GetComponent<Object_Manager>().objInfo.itemInfo.uID);

            handlerSM.slotInfo.curItem = foundObj.itemInfo;
            handlerSM.slotInfo.slotCount = 1;
            gm.handler.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = "1";
            gm.handler.GetComponent<Image>().sprite = handlerSM.slotInfo.curItem.itemSprite;
            handlerSM.isHandlerFree = false;
            SetObjOnHandler();
            objToDisconnect.GetComponent<Object_Manager>().DestroyObj(false);
            objToDisconnect = null;
        }
        if (onHandler != null && !handlerSM.isHandlerFree && handlerSM.slotInfo.curItem.uID != 8)
        {
            CheckIfCanSnap();

            if (Input.GetKeyDown(KeyCode.Z))
            {
                Physics_Object_Manager pom = onHandler.GetComponent<Physics_Object_Manager>();
                if (pom)
                {
                    if (pom.isHinge)
                    {
                        pom.FlipHinge();
                    }
                }
            }
        }
    }
    private void FixedUpdate()
    {
        if (onHandler != null && !handlerSM.isHandlerFree)
        {

            if (Input.GetMouseButton(1))
            {
                onHandler.transform.Rotate(0,0,rotateAmount);
            }
        }
    }
    public void SetObjOnHandler()
    {
        if (!handlerSM.isHandlerFree || handlerSM.slotInfo.curItem.isItem == false)
        {
            gm.handler.GetComponent<Image>().enabled = false;

            foundObj = buildingObjs.Find(s => s.itemInfo.uID == handlerSM.slotInfo.curItem.uID);

            if (foundObj.obj == null)
            {
                Debug.Log("Could not find Obj for Handler");
            }
            else
            {
                Vector3 mousePos = Input.mousePosition;
                mousePos.z = -mainCamera.transform.position.z; // distance from camera to 0-plane

                Vector3 worldPos = mainCamera.ScreenToWorldPoint(mousePos);
                worldPos.z = 0;

                spawned = Instantiate(foundObj.obj, mousePos, Quaternion.identity);
                gm.objOnHandler = spawned;
                gm.isObjOnHanlder = true;
                onHandler = spawned;
                handlerSensors.Clear();
                if (spawned.transform.GetChild(0))
                {
                    foreach (Transform child in spawned.transform.GetChild(0))
                    {
                        sensorsInScene.Add(child.gameObject);
                        handlerSensors.Add(child.gameObject);
                        child.GetComponent<SpriteRenderer>().enabled = true;
                    }
                }
                if (spawned.GetComponent<Object_Manager>().isAnchor && spawned.transform.GetChild(1) != null)
                {
                    spawned.transform.GetChild(1).gameObject.SetActive(true);
                }
            }

        }
    }
    public void SetObjOffHandlerFromView()
    {
        if (onHandler != null)
        {
            if (!handlerSM.isHandlerFree)
            {
                gm.handler.GetComponent<Image>().enabled = true;
            }

            foreach (Transform child in onHandler.transform.GetChild(0))
            {
                sensorsInScene.Remove(child.gameObject);
                handlerSensors.Remove(child.gameObject);
            }

            Destroy(onHandler.gameObject);
            gm.isObjOnHanlder = false;
            gm.objOnHandler = null;
            onHandler = null;
        }
    }

    public void CheckIfCanSnap()
    {
        bool isFoundForHandler = false;
        bool snappedToAnchor = false;
        handlerSensors.RemoveAll(item => item == null);
        onHandler.GetComponent<Object_Manager>().snappedObj.Clear();
        bool isFound = false;

        foreach (GameObject child in handlerSensors)
        {
            sensorsInScene.RemoveAll(item => item == null);
            foreach (GameObject sensor in sensorsInScene)
            {
                if (sensor.transform.parent != child.transform.parent && sensor.transform.parent.transform.parent.GetComponent<Object_Manager>().hingeParent != child.transform.parent.transform.parent.gameObject)
                {
                    //Debug.Log("Sensor went through step 1");
                    if ((child.transform.position - sensor.transform.position).sqrMagnitude < sensorDistCheck)
                    {

                        snapableObj = sensor.transform.parent.transform.parent.gameObject;
                        isFound = true;
                        if (!onHandler.GetComponent<Object_Manager>().snappedObj.Contains(sensor))
                        {
                            //Debug.Log("Sensor went through step 3");
                            onHandler.GetComponent<Object_Manager>().snappedObj.Add(sensor);
                        }
                    }
                }
            }
            if (isFound)
            {
                GameObject childParent = child.transform.parent.transform.parent.gameObject;
                if (childParent)
                {
                    //Debug.Log(snapableObj.name + " "+ childParent.name);
                    SnapBtoA(snapableObj,childParent);
                }

                child.GetComponent<SpriteRenderer>().color = child.transform.parent.transform.parent.GetComponent<Object_Manager>().canSnapSensorColor;
                isFoundForHandler = true;
                if ((snapableObj.GetComponent<Anchor_Manager>() != null || snapableObj.GetComponent<Object_Manager>().snappedToAnchor == true) && snapableObj.GetComponent<Object_Manager>().anchorObj.GetComponent<Anchor_Manager>().CheckIfInRangeBool(childParent))
                {
                    snappedToAnchor = true;
                    if (childParent.GetComponent<Object_Manager>().isAnchor == false && childParent.GetComponent<Object_Manager>().isLoose == false)
                    {
                        childParent.GetComponent<Object_Manager>().anchorObj = snapableObj.GetComponent<Object_Manager>().anchorObj;
                    }
                }
                else
                {
                    snappedToAnchor = false;
                }
            }
            else
            {
                onHandler.GetComponent<Object_Manager>().snappedObj.Clear();
                child.GetComponent<SpriteRenderer>().color = child.transform.parent.transform.parent.GetComponent<Object_Manager>().sensorDefault;
            }
        }
        if (isFoundForHandler)
        {
            onHandler.GetComponent<Object_Manager>().isSnapped = true;
            if ((snappedToAnchor == true && onHandler.GetComponent<Object_Manager>().snappedToAnchor == false) || (onHandler.GetComponent<Object_Manager>().isAnchor || onHandler.GetComponent<Object_Manager>().isLoose))
            {
                onHandler.GetComponent<Object_Manager>().snappedToAnchor = true;
                onHandler.GetComponent<Object_Manager>().CanPlace();
                //Debug.Log("Can place should be called");
            }
        }
        else
        {
            if (snappedToAnchor == false && onHandler.GetComponent<Object_Manager>().snappedToAnchor == true)
            {
                onHandler.GetComponent<Object_Manager>().snappedToAnchor = false;
                onHandler.GetComponent<Object_Manager>().CannotPlace();

            }
            onHandler.GetComponent<Object_Manager>().isSnapped = false;
            onHandler.GetComponent<Object_Manager>().snappedObj.Clear();
        }
    }

    void SnapBtoA(GameObject boxA, GameObject boxB)
    {
        Debug.Log("Should be snapping");
        float angleA = boxA.transform.eulerAngles.z;
        float angleB = boxB.transform.eulerAngles.z;

        float localBY = boxB.transform.eulerAngles.y;

        float relative = angleB - angleA;

        float snapped = Mathf.Round(relative / 90f) * 90f;

        float finalAngle = angleA + snapped;
        boxB.transform.rotation = Quaternion.Euler(0f, localBY, finalAngle);
    }
}
