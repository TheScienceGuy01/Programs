using UnityEngine;
using System.Collections.Generic;

[System.Serializable]

public class CraftingRecipe
{
    public int craftingID;
    public GameObject craftingObj;
    public CraftingItem[] inputs;
    public CraftingItem[] outputs;
}

[System.Serializable]

public struct CraftingItem
{
    public Item itemInfo;
    public int neededCount;
}

public class Crafting_Manager : MonoBehaviour
{
    public GameObject inventory;
    Inventory_Manager im;
    public CraftingRecipe[] craftingRecipes;
    public List<CraftingRecipe> validRecipes = new List<CraftingRecipe>();
    public Vector2 initialRecipeStartPos;
    public Vector2 nextRecipeDifference;

    private void Start()
    {
        im = inventory.GetComponent<Inventory_Manager>();
    }
    public bool CheckForInputs(CraftingRecipe cr)
    {
        bool foundInputs;
        foundInputs = true;
        foreach (CraftingItem ci in cr.inputs)
        {
            if (!im.GetInventoryCounts(ci))
            {
                foundInputs = false;
                break;
            }
        }

        if (foundInputs == false)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public void ClickedCraft(int cID)
    {
        bool canCraft = true;
        Debug.Log("Clicked Craft");
        foreach (CraftingRecipe cr in craftingRecipes)
        {
            if (cr.craftingID == cID)
            {
                if (!CheckForInputs(cr))
                {
                    Debug.Log("Cannot Craft");

                    canCraft = false;
                    break;
                }
            }
        }

        if (canCraft == true)
        {
            foreach (CraftingRecipe cr in craftingRecipes)
            {
                if (cr.craftingID == cID)
                {
                    Debug.Log("Can Execute Craft");
                    Debug.Log("============================");
                    Debug.Log("CR ID: "+cr.craftingID);
                    Debug.Log("CR Inputs: " + cr.inputs.Length);
                    Debug.Log("CR Outputs: " + cr.outputs.Length);
                    if (cr.inputs == null) Debug.LogError("inputs is NULL");
                    if (cr.outputs == null) Debug.LogError("outputs is NULL");
                    Debug.Log("============================");

                    ExecuteCraft(cr);
                }
            }
        }
    }

    void ExecuteCraft(CraftingRecipe cr)
    {
        foreach (CraftingItem ci in cr.inputs)
        {
            Debug.Log("Decreasing Slots");
            im.DecreaseSlots(ci.itemInfo.uID,ci.neededCount);
        }
        foreach (CraftingItem ci in cr.outputs)
        {
            Debug.Log("Adding Items Slots");
            im.AddItem(ci.itemInfo, ci.neededCount);
        }
    }

    public void GetAllValidRecipes()
    {
        validRecipes.Clear();
        foreach (CraftingRecipe cr in craftingRecipes)
        {
            if (CheckForInputs(cr))
            {
                validRecipes.Add(cr);
                cr.craftingObj.SetActive(true);
            }
            else
            {
                cr.craftingObj.SetActive(false);

            }
        }
        OrganizeRecipes();

    }
    void OrganizeRecipes()
    {
        for (int i = 0; i < validRecipes.Count; i++)
        {
            if (i == 0)
            {
                validRecipes[0].craftingObj.GetComponent<RectTransform>().anchoredPosition = initialRecipeStartPos;
            }
            else
            {
                validRecipes[i].craftingObj.GetComponent<RectTransform>().anchoredPosition = validRecipes[i-1].craftingObj.GetComponent<RectTransform>().anchoredPosition + nextRecipeDifference;

            }
        }
    }
}
