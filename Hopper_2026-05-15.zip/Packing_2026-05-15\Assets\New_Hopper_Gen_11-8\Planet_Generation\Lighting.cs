using System.Collections.Generic;
using UnityEngine;

public class Lighting : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    /*
     * Plan!
     * 1. only light active chunks
     * 1.5. all crumbs need to know how far they are from their own suraface crumb reference.
     * 2. based on who is surface or not.
     * 
    */
    Generation_Manager gm;
    public GameObject gameManager;
    Game_Manager gameM;
    public bool isOn;
    public bool isDynamic;
    public LayerMask crumbMask;
    public float lightStrength;
    public float lightRadius;
    void Start()
    {
        //gameM = gameManager.GetComponent<Game_Manager>();
        //gm = gameM.currentPlanet.GetComponent<Generation_Manager>();
        GetComponent<CircleCollider2D>().radius = lightRadius;
    }

    // Update is called once per frame
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<Crumb_Manager>() != null)
        {
            Crumb_Manager cm = other.GetComponent<Crumb_Manager>();
            //cm.currentDarkness = Vector2.Distance(other.transform.position, transform.position);
            cm.lightSources += 1;
        }
    }
    private void OnTriggerStay2D(Collider2D other)
    {

        if (other.GetComponent<Crumb_Manager>() != null)
        {
            Crumb_Manager cm = other.GetComponent<Crumb_Manager>();
            float currentDarkness = (Vector2.Distance(other.transform.position, transform.position) / lightRadius) * (1/lightStrength);
            if (cm.currentDarkness > currentDarkness && cm.defaultDarkness > currentDarkness)
            {
                cm.currentDarkness = currentDarkness;
                cm.SetLighting();

            }
            //cm.currentDarkness = 0;
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.GetComponent<Crumb_Manager>() != null && (transform.position - other.transform.position).sqrMagnitude > lightRadius*lightRadius)
        {
            Crumb_Manager cm = other.GetComponent<Crumb_Manager>();
            cm.lightSources -= 1;
            //Debug.Log((transform.position - other.transform.position).sqrMagnitude > lightRadius * lightRadius);
            if (cm.lightSources == 0)
            {
                cm.currentDarkness = cm.defaultDarkness;
                cm.SetLighting();
            }
        }
    }
}
