using UnityEngine;

public class Nonphysics_Functional_Objects : MonoBehaviour
{
    public float accessRange;
    public GameObject menuManager;
    public bool isActive;
    public GameObject player;
    public GameObject gameManager;
    Game_Manager gm;
    Game_Menu_Manager gmm;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        gm = gameManager.GetComponent<Game_Manager>();
        gmm = menuManager.GetComponent<Game_Menu_Manager>();
    }

    // Update is called once per frame

}
