using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
    [Header("Testing")]
    public bool isTesting;
    public GameObject[] modelParts;
    public Color defaultColor;
    public Color hurtColor;
    public Color healingColor;
    public bool addHurt;
    public int hurtAmount;
    public bool addHealth;
    public int healthAmount;

    [Header("Health Setters")]
    public int maxHealth;
    public int currentHealth;
    public float healTimeRate;
    public int healAmountRate;
    public float healWaitTime;
    public float fallDamageThreshold;
    public float fallDamageMultiplier;
    public float peakfallDamage;

    [Header("Health Bools")]
    public bool canStartHealing;
    public bool canHeal;
    public bool canDie;
    public bool isDead;
    public bool isPlayer;
    public bool isHealing;
    public bool canTakeFallDamage;
    Game_Manager gm;
    public Rigidbody2D rb;
    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        if (isPlayer)
        {
            gm = GetComponent<Player_Manager>().gameManager.GetComponent<Game_Manager>();
        }
        else if (GetComponent<NPC_Manager>().gameManager)
        {
            gm = GetComponent<NPC_Manager>().gameManager.GetComponent<Game_Manager>();
        }
    }
    private void Update()
    {
        if (isTesting)
        {
            if (addHealth)
            {
                addHealth = false;
                ChangeHealth(healthAmount);

            }
            if (addHurt)
            {
                addHurt = false;
                ChangeHealth(hurtAmount);
            }
        }
    }
    public void ChangeHealth(int changeAmount)
    {

        if (changeAmount < 0)
        {
            currentHealth += changeAmount;

            Hurt();
        }
        else if (canHeal && canStartHealing)
        {
            Debug.Log("Change function should be calling healing");
            StartCoroutine(Healing());
        }
        
    }

    public void Hurt()
    {
        StopAllCoroutines();
        StartCoroutine(HealWait());
        //Debug.Log("Hurt!");
        if (currentHealth <= 0)
        {
            currentHealth = 0;
            if (canDie)
            {
                isDead = true;
                if (isPlayer)
                {
                    //Debug.Log("Player Dead!!!");
                }
                else
                {
                    GetComponent<NPC_Manager>().SetDeath();
                }
            }
        }
        else
        {
            StartCoroutine(HealthChangeVisuals(false));
        }
    }
    IEnumerator Healing()
    {

        isHealing = true;
        while (isHealing)
        {
            Debug.Log("Healing!");
            currentHealth += healAmountRate;
            yield return new WaitForSeconds(healTimeRate);
            if (currentHealth >= maxHealth)
            {
                currentHealth = maxHealth;
                isHealing = false;
                break;
            }
            StartCoroutine(HealthChangeVisuals(true));
        }
    }

    IEnumerator HealthChangeVisuals(bool healthChange)
    {
        foreach (GameObject part in modelParts)
        {
            //Debug.Log("Called Visuals!");
            if (healthChange == false)
            {
                part.GetComponent<SpriteRenderer>().color = hurtColor;
            }
            else
            {
                part.GetComponent<SpriteRenderer>().color = healingColor;
            }
        }
        yield return new WaitForSeconds(.2f);
        foreach (GameObject part in modelParts)
        {
            //Debug.Log("Called Visuals!");
            if (healthChange == false)
            {

                part.GetComponent<SpriteRenderer>().color = defaultColor;
            }
            else
            {
                part.GetComponent<SpriteRenderer>().color = defaultColor;
            }
        }
    }

    IEnumerator HealWait()
    {
        //Debug.Log("Waiting to heal!");

        canStartHealing = false;
        yield return new WaitForSeconds(healWaitTime);
        canStartHealing = true;
        ChangeHealth(healAmountRate);
        //Debug.Log("Can now heal!!!");
    }
    public void CheckFallDamage()
    {
        if (canTakeFallDamage && gm.currentPlanet != null && rb != null)
        {
            Vector2 directionToPlanet = (gm.currentPlanet.transform.position - transform.position).normalized;
            float fallDamage = Vector2.Dot(rb.linearVelocity, directionToPlanet);
            if (fallDamage > peakfallDamage)
            {
                peakfallDamage = fallDamage;
            }
            if (peakfallDamage > fallDamageThreshold)
            {
                if (isPlayer)
                {
                    if (GetComponent<Player_Manager>().isJumping == false && (int)peakfallDamage != 0)
                    {
                        if (GetComponent<Player_Manager>().inWater)
                        {
                            peakfallDamage = fallDamage;
                        }
                        //Debug.Log((int)(peakfallDamage * fallDamageMultiplier) + " fall damage taken!");

                        ChangeHealth(-(int)(peakfallDamage * fallDamageMultiplier));
                        peakfallDamage = 0;

                    }
                }
                else
                {
                    if (GetComponent<NPC_Manager>().isJumping == false && (int)peakfallDamage != 0)
                    {
                        //Debug.Log((int)(peakfallDamage * fallDamageMultiplier) + " fall damage taken!");
                        ChangeHealth(-(int)(peakfallDamage * fallDamageMultiplier));
                        peakfallDamage = 0;
                    }
                }
            }
        }
    }
}
