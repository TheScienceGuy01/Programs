using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Chunk_Manager : MonoBehaviour
{
    public bool isEnabled;
    public GameObject crumbHolder;

}
