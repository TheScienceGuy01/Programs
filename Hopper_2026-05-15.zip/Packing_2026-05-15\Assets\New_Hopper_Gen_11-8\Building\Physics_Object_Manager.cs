using System.Collections;
using UnityEditor;
using UnityEngine;

public class Physics_Object_Manager : MonoBehaviour
{
    public bool isLocalDir;
    public bool isOn;
    public bool isIdle;
    public bool alwaysOn;
    public GameObject isOnObj;
    public bool destroyImmediatelyWhenUnLinked;
    public string dir;
    public float forceAmount;
    public float forceCap;
    public float currentSpeed;
    Vector2 dirVector;
    Vector2 localDir;
    Quaternion localUp;
    public GameObject mainBody;
    public bool isConstantForce;
    public bool nonConstantForceChecker;
    public bool dirInPlanetY;
    public GameObject gameManager;
    Game_Manager gm;
    Rigidbody2D rb;
    GameObject spawned;
    public bool canUseInSpace;
    public bool inSpace;
    public bool destroyInSpace;
    public bool isWheel;
    public bool isWheelOnGround;
    public bool isHinge;
    public bool isChest;
    public GameObject chestSpawnPoint;
    public GameObject chestParent;
    public float hingeStartAngle;
    public float hingeTargetAngle;
    public float hingeTurnSpeed;
    public float hingeDefaultOffet;
    public Vector2 hingeOffset;
    public bool isHingeFlipped;
    public GameObject wheelObj;
    public GameObject wheelTouchingObj;
    public int triggerCount;
    public bool followsMouse;
    public Camera mainCamera;
    public bool isHoldForThrust;
    public bool canTurnOn;
    public bool isStabilizer;
    public float stabilizerAngularCutOff;
    public float stabilizerLinearCutOff;
    public float stablizerAnglularForce;
    public float stabilizerLinearForce;
    public float currAngular;
    public float currLinear;
    public Color turnOnColor;
    public Color defaultColor;
    public GameObject spriteObj;
    public GameObject turnOnObject;
    public float newAngle;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        gm = gameManager.GetComponent<Game_Manager>();
        rb = transform.GetComponent<Rigidbody2D>();
        if (isHinge)
        {
            rb = mainBody.transform.GetComponent<Rigidbody2D>();
        }

        if (spriteObj)
        {
            defaultColor = spriteObj.GetComponent<SpriteRenderer>().color;
        }
        if (mainBody == null)
        {
            mainBody = gameObject;
        }
        if (dirInPlanetY)
        {
            spawned = Instantiate(mainBody, transform.position, Quaternion.identity);
            mainBody = spawned;
            transform.GetChild(1).gameObject.SetActive(false);
        }
        if (isWheel)
        {
            wheelObj.GetComponent<Collider2D>().enabled = true;
        }
    }
    private void Update()
    {
        if (isHoldForThrust && canTurnOn)
        {
            if (isIdle == true)
            {
                isIdle = false;
            }
            else
            {
                isIdle = true;
            }
            canTurnOn = false;
        }
        else if (isHoldForThrust && Input.GetMouseButton(0) && isIdle)
        {
            if (isOn == false)
            {
                TurnOn();

            }
        }
        else if (isHoldForThrust && isIdle)
        {
            if (isOn == true)
            {
                TurnOff();

            }
        }
        if (isHoldForThrust == false && alwaysOn == false && canTurnOn)
        {
            if (isOn == true && !GetComponent<Object_Manager>().cannotPickUpObj)
            {
                TurnOff();
            }
            else
            {
                TurnOn();
            }
        }
        //Balloons
        if (dirInPlanetY && spawned != null)
        {
            spawned.transform.position = transform.GetChild(0).transform.GetChild(0).transform.position;
        }
    }
    // Update is called once per frame
    void FixedUpdate()
    {
        if (spawned != null)
        {
            // Direction from object to planet
            Vector2 directionToPlanet = gm.currentPlanet.transform.position - spawned.transform.position;

            // Calculate angle so that bottom (negative Y) faces the planet
            float angle = Mathf.Atan2(directionToPlanet.y, directionToPlanet.x) * Mathf.Rad2Deg - 90f + 180;

            // Apply rotation
            localUp = Quaternion.Euler(0f, 0f, angle);
            spawned.transform.rotation = Quaternion.Euler(0f, 0f, angle);
        }

        if (isOn && isStabilizer)
        {
            ActivateStabilizer();
        }
        else if (isHinge)
        {
            if (!isChest || (isChest && isOn))
            {
                if (rb.bodyType == RigidbodyType2D.Kinematic)
                {
                    rb.bodyType = RigidbodyType2D.Dynamic;
                }
                Transform parent = mainBody.transform.parent.GetChild(2);

                Vector2 offset = parent.right * hingeOffset.x + parent.up * hingeOffset.y;
                Vector2 targetPos = (Vector2)parent.position + offset;

                rb.MovePosition(targetPos);

                if (isOn)
                {
                    float targetAngle = transform.eulerAngles.z + hingeTargetAngle;

                    float error = Mathf.DeltaAngle(rb.rotation, targetAngle);
                    float torque = error * hingeTurnSpeed;

                    rb.AddTorque(torque);
                    rb.angularVelocity *= 0.9f; // damping
                }
                else
                {
                    float targetAngle = transform.eulerAngles.z + hingeDefaultOffet;

                    float error = Mathf.DeltaAngle(rb.rotation, targetAngle);
                    float torque = error * hingeTurnSpeed;

                    rb.AddTorque(torque);
                    rb.angularVelocity *= 0.9f; // damping
                }
            }
        }

        if (isOn && rb.linearVelocity.magnitude < forceCap && (isWheel == false || (isWheel == true && isWheelOnGround == true)) && isStabilizer == false && isHinge == false)
        {
            if (followsMouse)
            {
                Vector3 mousePos = mainCamera.ScreenToWorldPoint(Input.mousePosition);
                mousePos.z = 0;
                Vector3 direction = mousePos - mainBody.transform.position;
                mainBody.transform.up = direction;
            }

            if (isLocalDir == false)
            {
                switch (dir)
                {
                    case "Right":
                        //Debug.Log("Right dir Chosen");
                        dirVector = spawned.transform.right;
                        break;
                    case "Down":
                        //Debug.Log("Down dir Chosen");
                        dirVector = -spawned.transform.up;
                        break;
                    case "Left":
                        //Debug.Log("Left dir Chosen");
                        dirVector = -spawned.transform.right;
                        break;
                    case "Up":
                        //Debug.Log("Up dir Chosen");
                        dirVector = spawned.transform.up;
                        break;
                    default:
                        break;
                }
            }
            else
            {
                switch (dir)
                {
                    case "Right":
                        //Debug.Log("Right dir Chosen");
                        dirVector = mainBody.transform.right;
                        break;
                    case "Down":
                        //Debug.Log("Down dir Chosen");
                        dirVector = -mainBody.transform.up;
                        break;
                    case "Left":
                        //Debug.Log("Left dir Chosen");
                        dirVector = -mainBody.transform.right;
                        break;
                    case "Up":
                        //Debug.Log("Up dir Chosen");
                        dirVector = mainBody.transform.up;
                        break;
                    default:
                        break;
                }
            }
            //localDir = spawned.transform.InverseTransformDirection(dirVector);
            if (inSpace == false || (inSpace && canUseInSpace))
            {
                if (isConstantForce)
                {
                    rb.AddForce(dirVector * forceAmount);
                    //Debug.Log("Adding Force!");
                }
            }

            //Special Attributes
        }

    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Planet_Atmosphere"))
        {
            SetOnPlanet();
        }
        else if (other.CompareTag("BuildTool"))
        {
            //Debug.Log("detecting build tool");
            spriteObj.GetComponent<SpriteRenderer>().color = turnOnColor;
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {

        if (other.CompareTag("Planet_Atmosphere") && GetComponent<Object_Manager>().isActive)
        {
            SetInSpace();
        }
        else if (other.CompareTag("BuildTool"))
        {
            spriteObj.GetComponent<SpriteRenderer>().color = defaultColor;
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if (isWheel)
        {
            triggerCount += 1;
            isWheelOnGround = true;
            wheelTouchingObj = other.gameObject;
        }
    }
    private void OnCollisionExit2D(Collision2D other)
    {
        if (isWheel)
        {
            triggerCount -= 1;
            if (triggerCount <= 0)
            {
                triggerCount = 0;
                isWheelOnGround = false;
            }
        }
    }

    public void SetInSpace()
    {
        //Debug.Log("Destroyed in Space!");
        if (destroyInSpace)
        {
            Destroy(mainBody);
        }
        inSpace = true;
        if (canUseInSpace == false)
        {
            spriteObj.GetComponent<SpriteRenderer>().color = GetComponent<Object_Manager>().invalidColor;
            TurnOff();

        }
    }
    public void SetOnPlanet()
    {
        inSpace = false;
        spriteObj.GetComponent<SpriteRenderer>().color = GetComponent<Object_Manager>().defaultColor;
    }

    public void ActivateStabilizer()
    {
        currAngular = Mathf.Abs(rb.angularVelocity);
        currLinear = rb.linearVelocity.magnitude;
        if (Mathf.Abs(rb.angularVelocity) > stabilizerAngularCutOff)
        {
            //Debug.Log("Stabilizing Anglular!!!!");
            rb.angularVelocity *= stablizerAnglularForce;
        }
        if (rb.linearVelocity.magnitude > stabilizerLinearCutOff)
        {
            //Debug.Log("Stabilizing Linear!!!!");

            rb.linearVelocity *= stabilizerLinearForce;
        }
    }

    public void TurnOn()
    {
        Debug.Log("Should be turned on!");
        if (isChest && isOn == false)
        {
            chestParent.GetComponent<Loot_Tables>().StartLootSpawning((Vector2)chestSpawnPoint.transform.position);
        }
        isOn = true;
        if (isOnObj)
        {
            isOnObj.SetActive(true);
        }
        canTurnOn = false;
        if (turnOnObject != null)
        {
            turnOnObject.SetActive(true);
        }
    }

    public void TurnOff()
    {
        isOn = false;
        if (isOnObj)
        {
            isOnObj.SetActive(false);
        }
        canTurnOn = false;
        if (turnOnObject != null)
        {
            turnOnObject.SetActive(false);
        }
    }
    public void FlipHinge()
    {
        Debug.Log("Flipped Hinge!");
        if (isHingeFlipped)
        {
            isHingeFlipped = false;
            hingeDefaultOffet = 0;
            mainBody.transform.GetChild(0).localRotation = Quaternion.Euler(0, 0, 0);

            transform.GetChild(2).GetComponent<SpriteRenderer>().flipX = false;

        }
        else
        {
            isHingeFlipped = true;

            hingeDefaultOffet = 180;

            hingeOffset.x *= -1;
            mainBody.transform.GetChild(0).localRotation = Quaternion.Euler(180, 0, 0);

            transform.GetChild(2).GetComponent<SpriteRenderer>().flipX = true;
        }
    }

}

