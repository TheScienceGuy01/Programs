using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

[System.Serializable]
public class LootItems
{
    public int uID;
    public int spawnWeight;
    public int spawnAmount;
}
public class Loot_Tables : MonoBehaviour
{
    public GameObject gameManager;
    Game_Manager gm;
    Item_Drops id;
    public LootItems[] lootTable;
    List<int> lootWeights = new List<int>();
    public int spawnAmount;
    public bool spawnAll;
    public float spawnRate;
    public float initialDelay;
    private void Start()
    {
        gm = gameManager.GetComponent<Game_Manager>();
        id = gameManager.GetComponent<Item_Drops>();
        foreach (LootItems li in lootTable)
        {
            lootWeights.Add(li.spawnWeight);
        }
        //StartLootSpawning((Vector2)transform.position);
    }
    public void StartLootSpawning(Vector2 spawnPos)
    {
        if (spawnAll)
        {
            StartCoroutine(SpawnAllLoot(spawnPos));
        }
        else
        {
            StartCoroutine(ChooseLoot(spawnPos));
        }
    }
    IEnumerator ChooseLoot(Vector2 spawnLocation)
    {
        yield return new WaitForSeconds(initialDelay);
        Debug.Log("Choosing random loot...");
        int chosenIndex = gm.GetRandomWeightedReturn(lootWeights);
        LootItems chosenItem = lootTable[chosenIndex];
        id.SpawnItem(chosenItem.uID, spawnLocation, transform.rotation, false);
    }
    IEnumerator SpawnAllLoot(Vector2 spawnLocation)
    {
        yield return new WaitForSeconds(initialDelay);

        Debug.Log("Choosing all loot...");
        foreach (LootItems li in lootTable)
        {
            id.SpawnItem(li.uID, spawnLocation, transform.rotation, false);
            yield return new WaitForSeconds(spawnRate);
        }
    }
}
