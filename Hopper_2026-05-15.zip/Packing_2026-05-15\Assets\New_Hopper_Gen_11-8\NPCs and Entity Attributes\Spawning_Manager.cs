using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class NPCSpawn
{
    public GameObject npc;
    public float neededRoomForSpawning;
    public float anotherSpawnRoom;
    public int spawnRate;
    public Vector2 offSet;
    public bool needsAir;
    public bool needsWater;
    public bool needsSurface;
    public bool needsSky;
    public bool isStructure;
}

public class Spawning_Manager : MonoBehaviour
{
    public NPCSpawn[] npcSpawns;
    List<int> npcSpawnInts = new List<int>();
    public List<GameObject> currentSpawnCrumbs = new List<GameObject>();
    public List<Vector2> currentSpawnPos = new List<Vector2>();
    public List<GameObject> randomizedList = new List<GameObject>();
    public List<GameObject> planetNPCs = new List<GameObject>();
    public NPCSpawn chosenNPC;
    public bool canSpawn;
    public GameObject spawningObj;
    public int maxSpawns;
    public GameObject gameManager;
    public float planetRadius;
    public GameObject planetBoundsObj;
    public LayerMask crumbLayer;
    public GameObject npcHolder;
    public int stillSpawningStructures;

    Game_Manager gm;
    Generation_Manager genM;
    GameObject spawned;
    private void Start()
    {

        //TODO
        // Done but will eventually liek to have all spawn locations have their own independent maxCounts.
        //Work on FIXING MINING

        npcHolder = transform.parent.GetChild(3).gameObject;

        gm = gameManager.GetComponent<Game_Manager>();
        genM = GetComponent<Generation_Manager>();
        planetRadius = planetBoundsObj.GetComponent<CircleCollider2D>().radius * planetBoundsObj.transform.lossyScale.x;
        npcSpawnInts.Clear();
        foreach (NPCSpawn nSpawn in npcSpawns)
        {
            npcSpawnInts.Add(nSpawn.spawnRate);
        }

    }

    public IEnumerator StartSpawning()
    {
        yield return new WaitForSeconds(1);
        for (int i = 0; i < maxSpawns*3; i++)
        {
            if (canSpawn && planetNPCs.Count < maxSpawns)
            {
                yield return null;

                int chosenNPCIndex = gm.GetRandomWeightedReturn(npcSpawnInts);
                chosenNPC = npcSpawns[chosenNPCIndex];

                //Debug.Log("Chosen new NPC! " + chosenNPCIndex);

                //Spawning Locations
                if (chosenNPC.needsAir)
                {
                    //Debug.Log(i + " spawning in air");

                    SpawnInAir();
                }
                //If Surface
                if (chosenNPC.needsSurface)
                {
                    //Debug.Log(i + "spawning in surface");
                    SpawnInSurface();
                }
                if (chosenNPC.needsSky)
                {
                    //Debug.Log(i + "spawning in sky");

                    SpawnInSky();
                }
                if (chosenNPC.needsWater)
                {
                    //Debug.Log(i + "spawning in water");

                    SpawnInWater();
                }
            }
            else
            {
                break;
            }
        }
        yield return null;
        genM.isDoneNPCSpawn = true;

        //Debug.Log("Done Spawning NPCs");
    }
    public void SpawnInAir ()
    {
        randomizedList = ShuffleList(genM.airCrumbs);

        foreach (GameObject airCrumb in randomizedList)
        {
            bool canCont = true;
            foreach (GameObject currCrumb in currentSpawnCrumbs)
            {
                if ((currCrumb.transform.position - airCrumb.transform.position).sqrMagnitude < chosenNPC.anotherSpawnRoom || currentSpawnCrumbs.Contains(airCrumb))
                {
                    canCont = false;
                    break;
                }
            }


            if (canCont && !IsCrumbInDistance(airCrumb.transform.position, false))
            {
                //Debug.Log("Spawned NPC");
                spawned = Instantiate(chosenNPC.npc, airCrumb.transform.position, airCrumb.transform.rotation);
                // spawned.GetComponent<NPC_Manager>().enabled = false;
                planetNPCs.Add(spawned);
                currentSpawnCrumbs.Add(airCrumb);
                if (chosenNPC.isStructure == false && spawned.GetComponent<NPC_Manager>().applyGravity == true)
                {
                    //genM.gravityAffectedObjs.Add(spawned);
                }

                spawned.transform.SetParent(npcHolder.transform);
                spawned.SetActive(true);
                StartCoroutine(spawned.GetComponent<NPC_Manager>().SetDisabled());
                break;
            }

        }
    }
    public void SpawnInWater()
    {
        randomizedList = ShuffleList(genM.waterCrumbs);

        foreach (GameObject waterCrumb in randomizedList)
        {
            bool canCont = true;
            foreach (GameObject currCrumb in currentSpawnCrumbs)
            {
                if ((currCrumb.transform.position - waterCrumb.transform.position).sqrMagnitude < chosenNPC.anotherSpawnRoom || currentSpawnCrumbs.Contains(waterCrumb))
                {
                    canCont = false;
                    break;
                }
            }
            if (canCont && !IsCrumbInDistance(waterCrumb.transform.position, true))
            {
                //Debug.Log("Spawned NPC");
                spawned = Instantiate(chosenNPC.npc, waterCrumb.transform.position, waterCrumb.transform.rotation);
                // spawned.GetComponent<NPC_Manager>().enabled = false;
                planetNPCs.Add(spawned);
                currentSpawnCrumbs.Add(waterCrumb);

                if (chosenNPC.isStructure == false)
                {
                    //genM.gravityAffectedObjs.Add(spawned);
                }
                spawned.transform.SetParent(npcHolder.transform);
                StartCoroutine(spawned.GetComponent<NPC_Manager>().SetDisabled());

                spawned.SetActive(true);

                break;

            }
        }
    }
    public void SpawnInSurface()
    {
        //Debug.Log("Count is "+genM.airCrumbs.Count);
        genM.surfaceCrumbs.RemoveAll(item => item == null);
        randomizedList = ShuffleList(genM.surfaceCrumbs);

        foreach (GameObject surfaceCrumb in randomizedList)
        {
            bool canCont = true;

            Vector2 up = ((Vector2)surfaceCrumb.transform.position - (Vector2)genM.rootCrumb.transform.position).normalized;
            Vector2 spawnPos = (Vector2)surfaceCrumb.transform.position + up * chosenNPC.offSet.y;

            if (!surfaceCrumb.GetComponent<Crumb_Manager>().isAir && !surfaceCrumb.GetComponent<Crumb_Manager>().isWater)
            {
                foreach (GameObject currCrumb in currentSpawnCrumbs)
                {
                    if (((Vector2)currCrumb.transform.position - (Vector2)surfaceCrumb.transform.position).sqrMagnitude < chosenNPC.anotherSpawnRoom || currentSpawnCrumbs.Contains(surfaceCrumb))
                    {
                        canCont = false;
                        break;
                    }
                }
            }
            else
            {
                canCont = false;
            }

            if (canCont && !IsCrumbInDistance(spawnPos, false))
            {
                //will need to check for space here
                //Debug.Log("Spawned NPC");
                spawned = Instantiate(chosenNPC.npc, spawnPos, surfaceCrumb.transform.rotation);
                // spawned.GetComponent<NPC_Manager>().enabled = false;
                planetNPCs.Add(spawned);
                currentSpawnCrumbs.Add(surfaceCrumb);
                spawned.transform.SetParent(npcHolder.transform);
                if (spawned.GetComponent<NPC_Manager>())
                {
                    StartCoroutine(spawned.GetComponent<NPC_Manager>().SetDisabled());

                }

                spawned.SetActive(true);

                break;
            }

        }
    }

    void SpawnInSky()
    {
        bool canCont = true;

        for (int i = 0; i < 100; i++)
        {
            float angle = Random.Range(0f, Mathf.PI * 2f);

            float r = Mathf.Sqrt(Random.value) * planetRadius;

            Vector2 offset = new Vector2(
                Mathf.Cos(angle),
                Mathf.Sin(angle)
            ) * r;

            Vector2 spawnPos = (Vector2)genM.rootCrumb.transform.position + offset;
            canCont = false;
            //Check if pos is too close to a previous pos
            foreach (Vector2 curPos in currentSpawnPos)
            {
                if (currentSpawnPos.Contains(spawnPos) || (curPos - spawnPos).sqrMagnitude < chosenNPC.anotherSpawnRoom)
                {
                    canCont = true;
                    break;
                }
            }
            if (!canCont && !IsCrumbInDistance(spawnPos, false))
            {
                //Debug.Log("Spawned Sky NPC");
                spawned = Instantiate(chosenNPC.npc, spawnPos, Quaternion.identity);
                // spawned.GetComponent<NPC_Manager>().enabled = false;
                planetNPCs.Add(spawned);
                currentSpawnPos.Add(spawnPos);

                if (chosenNPC.isStructure == false)
                {
                    //genM.gravityAffectedObjs.Add(spawned);
                }
                spawned.transform.SetParent(npcHolder.transform);
                StartCoroutine(spawned.GetComponent<NPC_Manager>().SetDisabled());

                spawned.SetActive(true);

                break;
            }
        }
        //Debug.Log("Finished 1");
    }
    public List<GameObject> ShuffleList(List<GameObject> unShuffledList)
    {
        List<GameObject> newList = new List<GameObject>(unShuffledList);

        for (int i = 0; i < newList.Count; i++)
        {
            int targetIndex = Random.Range(0,newList.Count);
            int destIndex = Random.Range(0, newList.Count);
            GameObject destObj = newList[destIndex];

            newList[destIndex] = newList[targetIndex];
            newList[targetIndex] = destObj;
        }

        return newList;
    }
    public bool IsCrumbInDistance(Vector2 possibleSpawnPos, bool isWater)
    {
        Collider2D[] hits = Physics2D.OverlapCircleAll(possibleSpawnPos, chosenNPC.neededRoomForSpawning, crumbLayer);

        foreach (Collider2D hit in hits)
        {
            if (isWater)
            {
                if (hit.GetComponent<Crumb_Manager>().isWater == false)
                {
                    return true;
                }
            }
            else if (hit.GetComponent<Crumb_Manager>())
            {
                if (hit.GetComponent<Crumb_Manager>().isAir == false)
                {
                    return true;
                }
            }
            else
            {
                return true;
            }
        }
        return false;
    }
}
