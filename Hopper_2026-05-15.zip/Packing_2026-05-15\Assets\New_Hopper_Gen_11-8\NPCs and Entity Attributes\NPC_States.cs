using System.Collections;
using System.Collections.Generic;
using System.IO.Pipes;
using UnityEditor.Analytics;
using UnityEngine;
public class TestHumanoid : NPCTypeBase
{
    public TestHumanoid(NPC_States npc) : base(npc) { }
    public bool activateMoving;
    public int moveDir;

    public void Idle(bool isPatrolling)
    {
        npc.nm.UpdateAnims(npc.nonStateAnims[0], true);
        npc.currentSpeed = 0;
        npc.savedSpeed = npc.currentSpeed;

    }
    public void Walk(bool isPatrolling)
    {
        npc.nm.UpdateAnims(npc.nonStateAnims[1], true);

        if (Random.value < .5f)
        {
            moveDir = 1;
            npc.currentSpeed = npc.walkSpeed;
            npc.savedSpeed = npc.currentSpeed;

            //Debug.Log("Changing dir to 1");
        }
        else
        {
            moveDir = -1;
            npc.currentSpeed = npc.walkSpeed;
            npc.savedSpeed = npc.currentSpeed;

            //Debug.Log("Changing dir to -1");

        }
    }
    public void Pursue()
    {
        npc.pf.isPathfinding = true;

        SetState(NPCStateNames.Pursue);
        //Debug.Log("I am Pursuing");
        npc.currentSpeed = npc.runSpeed;
        npc.savedSpeed = npc.currentSpeed;
        npc.pf.StartPathfinding();
    }

    public IEnumerator Patrolling()
    {
        //Debug.Log("I am patrolling");
        SetState(NPCStateNames.Patrol);
        while (npc.currentState.name == NPCStateNames.Patrol)
        {
            //Debug.Log("Idle stuffy");
            Idle(true);
            yield return new WaitForSeconds(1);
            if (npc.currentState.name == NPCStateNames.Patrol)
            {
                //Debug.Log("Walking stuffy");
                Walk(true);
            }
            yield return new WaitForSeconds(1);

        }
    }

    public void Fleeing()
    {
        SetState(NPCStateNames.Flee);
        //Debug.Log("I am Pursuing");
        npc.currentSpeed = -npc.runSpeed;
        npc.savedSpeed = npc.currentSpeed;

        npc.pf.StartPathfinding();
    }

    public void Jumping()
    {
        npc.nm.UpdateAnims(npc.nm.jumpingAnim, false);
    }

    public void SetState(NPCStateNames sName)
    {
        //Debug.Log("Called Change state: " + sName);
        foreach (NPCState nState in npc.allStates)
        {
            if (nState.name == sName)
            {
                //Debug.Log("Changed State!!!");
                npc.currentState = new NPCState(nState);
            }
        }
        if (npc.currentState.animClip != null)
        {
            npc.nm.UpdateAnims(npc.currentState.animClip, true);

        }
    }

    public override void UpdateNPC(int npcChangeIndex)
    {
        if (npcChangeIndex == 0)
        {
            //Debug.Log("Default Patrolling!");
            npc.StartCoroutine(Patrolling());
        }

        if (activateMoving)
        {
            //Debug.Log("Should be moving");
            npc.nm.MovementHorizonal(moveDir, npc.currentSpeed);
        }

        if (activateMoving && npc.currentState.name != NPCStateNames.Patrol)
        {
            activateMoving = false;
        }
        if (!activateMoving && (npc.currentState.name == NPCStateNames.Patrol))
        {
            activateMoving = true;
        }

        if (npc.triggeredAttack)
        {
            npc.triggeredAttack = false;
            //Debug.Log("Attacked! Choosing Fight or Flight");
            if (npc.attackChance > Random.value)
            {
                Pursue();
            }
            else
            {
                Fleeing();
            }
        }

        if (npc.pf.isPathfinding == false && (npc.currentState.name == NPCStateNames.Pursue || npc.currentState.name == NPCStateNames.Flee))
        {
            //Debug.Log("Turned off pathfinding!");
            npc.currentState.name = NPCStateNames.Patrol;
            npc.StartCoroutine(Patrolling());
        }

        if (npc.nm.canFlipNPC)
        {
            npc.nm.FlipNPC();
        }

        if (npc.nm.isJumping && npc.nm.currentAnim != npc.nm.jumpingAnim)
        {
            Jumping();
        }
        if (!npc.nm.isJumping && npc.nm.currentAnim != npc.nm.savedAnimIndex && !npc.nm.na.pauseAnim)
        {
            //Debug.Log("Switching to saved anim");
            npc.nm.UpdateAnims(npc.nm.savedAnimIndex, true);
        }
    }
}

public class TestFlying : NPCTypeBase
{
    public TestFlying(NPC_States npc) : base(npc) { }
    public bool activateMoving;
    public int moveDir;

    public void Idle(bool isPatrolling)
    {
        //npc.nm.UpdateAnims(0,true);
        npc.currentSpeed = 0;
        npc.savedSpeed = npc.currentSpeed;

    }
    public void Walk(bool isPatrolling)
    {
        //npc.nm.UpdateAnims(1,true);
        //Debug.Log("Flying Should be roaming");
        npc.flyingVector = new Vector2(npc.transform.position.x + Random.Range(-6, 6), npc.transform.position.y + Random.Range(-6, 6));

        npc.currentSpeed = npc.walkSpeed;
        npc.savedSpeed = npc.currentSpeed;
    }
    public void Run()
    {
        //Debug.Log("I am running");
        npc.currentSpeed = npc.runSpeed;
        npc.savedSpeed = npc.currentSpeed;
    }
    public void Pursue()
    {
        npc.pf.isPathfinding = true;
        SetState(NPCStateNames.Pursue);

        Run();
        npc.pf.StartPathfinding();
    }

    public IEnumerator Patrolling()
    {
        //Debug.Log("I am patrolling");
        SetState(NPCStateNames.Patrol);
        while (npc.currentState.name == NPCStateNames.Patrol)
        {
            Idle(true);
            yield return new WaitForSeconds(1);
            if (npc.currentState.name == NPCStateNames.Patrol)
            {
                Walk(true);
            }
            yield return new WaitForSeconds(1);

        }
    }
    public void SetState(NPCStateNames sName)
    {
        //Debug.Log("Called Change state: " + sName);
        foreach (NPCState nState in npc.allStates)
        {
            if (nState.name == sName)
            {
                //Debug.Log("Changed State!!!");
                npc.currentState = new NPCState(nState);
            }
        }
        if (npc.currentState.animClip != null)
        {
            //Debug.Log("Changing to pursue anim!!!");
            npc.nm.UpdateAnims(npc.currentState.animClip, true);
        }
    }

    public override void UpdateNPC(int npcChangeIndex)
    {
        if (npcChangeIndex == 0)
        {
            npc.StartCoroutine(Patrolling());
        }

        if (activateMoving)
        {
            //Debug.Log("Should be moving");
            npc.nm.MovementFlying(npc.flyingVector, npc.currentSpeed);

        }

        if (activateMoving && npc.currentState.name != NPCStateNames.Patrol)
        {
            activateMoving = false;
        }
        if (!activateMoving && (npc.currentState.name != NPCStateNames.Pursue || npc.currentState.name == NPCStateNames.Patrol))
        {
            activateMoving = true;
        }

        if (npc.triggeredAttack)
        {
            npc.triggeredAttack = false;
            //Debug.Log("Should be Pursuing! Attacked!");
            Pursue();
        }

        if (npc.pf.isPathfinding == false && npc.currentState.name == NPCStateNames.Pursue)
        {
            npc.currentState.name = NPCStateNames.Pursue;
            npc.StartCoroutine(Patrolling());
        }

        if (npc.nm.currentAnim != npc.nm.savedAnimIndex)
        {
            //Debug.Log("Switching to saved anim");
            npc.nm.UpdateAnims(npc.nm.savedAnimIndex, true);
        }

        if (npc.currentState.name == NPCStateNames.Pursue)
        {
            npc.CheckIfTooClose();
        }
    }
}

public class CaveBouncer : NPCTypeBase
{
    public CaveBouncer(NPC_States npc) : base(npc) { }
    public float maxStillness = 2;

    IEnumerator Patrolling()
    {
        yield return null;
        SetState(NPCStateNames.Patrol);
        while (true)
        {
            yield return null;
            if (!npc.nm.isJumping)
            {
                yield return new WaitForSeconds(Random.Range(0, maxStillness));
                npc.nm.Jumping();

            }

        }
    }
    public void SetState(NPCStateNames sName)
    {
        //Debug.Log("Called Change state: " + sName);
        foreach (NPCState nState in npc.allStates)
        {
            if (nState.name == sName)
            {
                //Debug.Log("Changed State!!!");
                npc.currentState = new NPCState(nState);
            }
        }
        if (npc.currentState.animClip != null)
        {
            //Debug.Log("Anim nto null" + " clip name " + npc.currentState.animClip.name);

            npc.nm.UpdateAnims(npc.currentState.animClip, true);
        }
    }

    public override void UpdateNPC(int npcChangeIndex)
    {
        if (npcChangeIndex == 0)
        {
            npc.StartCoroutine(Patrolling());
        }
        if (!npc.nm.isJumping && npc.nm.currentAnim == npc.nm.jumpingAnim)
        {
            //Debug.Log("CURRENT ANIMIDLE");
            npc.nm.UpdateAnims(npc.currentState.animClip, true);
        }
        if (npc.nm.isJumping && npc.nm.currentAnim != npc.nm.jumpingAnim)
        {
            //Debug.Log("JUMONG ANIMMM");

            npc.nm.UpdateAnims(npc.nm.jumpingAnim, false);
        }
    }
}

[System.Serializable]
public enum NPCTypes
{
    TestHumanoid,
    TestingFlying,
    CaveBouncer
}
[System.Serializable]
public enum NPCStateNames
{
    Pursue,
    Patrol,
    Flee,
    Default
}
[System.Serializable]
public class NPCState
{
    public NPCStateNames name;
    public AnimationClip animClip;

    public NPCState() { }

    public NPCState(NPCState other)
    {
        name = other.name;
        animClip = other.animClip;
    }
}
public abstract class NPCTypeBase
{
    protected NPC_States npc;

    public NPCTypeBase(NPC_States npc)
    {
        this.npc = npc;
    }

    public abstract void UpdateNPC(int npcChangeIndex);
}

public class NPC_States : MonoBehaviour
{
    public NPCTypes npcTypes;
    public NPCState currentState;
    public NPCState[] allStates;
    public float walkSpeed;
    public float runSpeed;
    public float currentSpeed;
    public float savedSpeed;
    public float attackChance;
    public float attackMinDist;
    public bool triggeredAttack;
    public AnimationClip[] nonStateAnims;
    public Vector2 flyingVector;

    NPCTypeBase npcBrain;


    public NPC_Manager nm;
    public Pathfinding pf;

    void Start()
    {
        nm = GetComponent<NPC_Manager>();
        pf = GetComponent<Pathfinding>();

        switch (npcTypes)
        {
            case NPCTypes.TestHumanoid:
                npcBrain = new TestHumanoid(this);
                npcBrain.UpdateNPC(0);
                break;
            case NPCTypes.TestingFlying:
                npcBrain = new TestFlying(this);
                npcBrain.UpdateNPC(0);
                break;
            case NPCTypes.CaveBouncer:
                npcBrain = new CaveBouncer(this);
                npcBrain.UpdateNPC(0);
                break;
        }
    }
    private void OnEnable()
    {
        if (npcBrain != null)
        {
            npcBrain.UpdateNPC(0);
        }
    }
    void FixedUpdate()
    {
        npcBrain.UpdateNPC(-1);
    }

    public void CheckIfTooClose()
    {
        if ((transform.position - pf.target.transform.position).sqrMagnitude < attackMinDist)
        {
            currentSpeed = 0;
        }
        else
        {
            currentSpeed = savedSpeed;
        }
    }
}
