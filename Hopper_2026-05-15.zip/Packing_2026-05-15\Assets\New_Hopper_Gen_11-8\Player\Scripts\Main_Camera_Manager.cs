using UnityEngine;

public class Main_Camera_Manager : MonoBehaviour
{
    Camera cam;

    [Header("Zoom Variables")]
    public float currentZoom;
    public float zoomMultiplier;
    public float maxDistanceFromPlanet;
    public float zoomSpeed;
    public float currentDistRatio;
    public float currentDist;
    public Vector2 zoomMaxMin;

    [Header("Look Ahead Variables")]
    public float currentLookahead;
    public float lookAheadMultiplier;
    public float lookAheadSpeed;
    public float lookAheadSprinting;
    public float lookAheadWalking;
    public Vector2 lookMaxMin;
    public float currentLook;
    public float defaultYHeight;

    [Header("Planet Settings")]
    public float defaultChunkEnable;

    public GameObject player;
    public GameObject planet;

    Player_Manager pm;

    void Start()
    {
        player = transform.parent.gameObject;
        cam = GetComponent<Camera>();
        pm = player.GetComponent<Player_Manager>();
    }

    void Update()
    {
        if (maxDistanceFromPlanet != 0)
        {
            PlanetZoom();
            CameraHorizontalMovement();
        }
        else if (planet != null) {
            maxDistanceFromPlanet = (planet.transform.position - player.transform.position).sqrMagnitude;
        }
    }

    public void CameraShake(float timeShake, float shakeAmount)
    {

    }

    void CameraHorizontalMovement()
    {
        if (pm.isMoving)
        {
            if (pm.isSprinting)
            {
                currentLook = lookAheadSprinting * ((lookMaxMin.y - lookMaxMin.x) * currentDistRatio);
                currentLook += lookMaxMin.x;

                if (pm.flipDir == false)
                {
                    currentLook *= -1;
                }

                transform.localPosition = new Vector3(Mathf.Lerp(
                    transform.localPosition.x,
                    currentLook,
                    lookAheadSpeed * Time.deltaTime
                ), transform.localPosition.y, -1);
            }
            else
            {
                currentLook = lookAheadWalking * ((lookMaxMin.y - lookMaxMin.x) * currentDistRatio);
                currentLook += lookMaxMin.x;

                if (pm.flipDir == false)
                {
                    currentLook *= -1;
                }

                transform.localPosition = new Vector3(Mathf.Lerp(
                    transform.localPosition.x,
                    currentLook,
                    lookAheadSpeed * Time.deltaTime
                ), transform.localPosition.y, -1);
            }
        }
        else
        {
            currentLook = (lookMaxMin.x * currentDistRatio);
            currentLook += lookMaxMin.x;

            if (pm.flipDir == false)
            {
                currentLook *= -1;
            }

            transform.localPosition = new Vector3(Mathf.Lerp(
                transform.localPosition.x,
                currentLook,
                lookAheadSpeed * Time.deltaTime
            ), transform.localPosition.y, -1);
        }

        if (pm.isInSpace)
        {
            transform.localPosition = new Vector3(transform.localPosition.x, Mathf.Lerp(
                transform.localPosition.y,
                0,
                lookAheadSpeed * Time.deltaTime
            ), -1);
        }
        else
        {
            transform.localPosition = new Vector3(transform.localPosition.x, Mathf.Lerp(
                transform.localPosition.y,
                defaultYHeight,
                lookAheadSpeed * Time.deltaTime
            ), -1);

        }
    }

    void PlanetZoom()
    {
        currentDist = (planet.transform.position - player.transform.position).sqrMagnitude;
        currentDistRatio = currentDist / maxDistanceFromPlanet;
        currentZoom = zoomMultiplier * ((zoomMaxMin.y - zoomMaxMin.x) * currentDistRatio);
        currentZoom += zoomMaxMin.x;
        if (currentZoom > zoomMaxMin.y)
        {
            currentZoom = zoomMaxMin.y;
        }

        cam.orthographicSize = Mathf.Lerp(
            cam.orthographicSize,
            currentZoom,
            zoomSpeed * Time.deltaTime
        );

        planet.GetComponent<Generation_Manager>().chunkSettingDistance = defaultChunkEnable * (cam.orthographicSize / 10.58f);
    }
}
