using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class ScentNodes
{
    public Vector2 scentPos;
    public GameObject scentTestObj;
    public int step;
    public bool isActive = true;
}
public class Pathfinding : MonoBehaviour
{
    public bool isPathfinding;
    public bool isTesting;
    public bool isDirectPath;

    public GameObject target;
    public Vector2 pointingDirection;
    public List<ScentNodes> targetScents = new List<ScentNodes>();
    public ScentNodes chosenScentNode;
    public ScentNodes latestScentNode;

    public float maxScentPickupDistance;
    public float scentDelay;
    public float scentLifetime;
    public float directSightCheckDelay;
    public float tooCloseToTargetDist;

    [Header("Testing Display Scents")]
    public GameObject scentDisplayObj;
    public Color defaultScentColor;
    public Color chosenScentColor;

    NPC_Manager nm;

    private void Start()
    {
        nm = GetComponent<NPC_Manager>();
    }

    public void StartPathfinding()
    {
        //Debug.Log("Started Pathfinding");
        StartCoroutine(CreateScentTrails());
        StartCoroutine(DirectSight());
    }

    IEnumerator FadeScents(ScentNodes scent)
    {
        yield return new WaitForSeconds(scentLifetime);
        if ((scent == latestScentNode && isDirectPath == false) || target == null)
        {
            latestScentNode.isActive = false;
            isPathfinding = false;
        }
        DestroyScent(scent);
    }

    IEnumerator CreateScentTrails()
    {
        int count = 0;
        GameObject scentDisplay;
        while (isPathfinding && target != null)
        {
            count += 1;

            ScentNodes newNode = new ScentNodes();
            newNode.scentPos = target.transform.position;
            newNode.step = count;

            if (isTesting)
            {
                scentDisplay = Instantiate(scentDisplayObj, newNode.scentPos, Quaternion.identity);
                newNode.scentTestObj = scentDisplay;

            }

            targetScents.Add(newNode);

            StartCoroutine(FadeScents(newNode));

            yield return new WaitForSeconds(scentDelay);

            if (isDirectPath == false)
            {
                float latestScentStep = 0;
                for (int i = 0; i < targetScents.Count; i++)
                {
                    if (isTesting)
                    {
                        targetScents[i].scentTestObj.GetComponent<SpriteRenderer>().color = defaultScentColor;
                    }
                    if (targetScents[i].step > latestScentStep)
                    {
                        if (CheckDistance(targetScents[i].scentPos))
                        {
                            latestScentStep = targetScents[i].step;
                            latestScentNode = targetScents[i];
                        }
                    }
                }
                if (latestScentNode.scentTestObj != null && isTesting)
                {
                    latestScentNode.scentTestObj.GetComponent<SpriteRenderer>().color = chosenScentColor;
                }
            }

        }
    }
    IEnumerator DirectSight()
    {
        while (isPathfinding)
        {
            yield return new WaitForSeconds(directSightCheckDelay);

            if (target != null)
            {
                //Debug.Log("Started checking for direct");
                if (CheckDistance(target.transform.position))
                {
                    //Debug.Log("Sifht Direct");

                    isDirectPath = true;
                    //Debug.DrawRay(transform.position, dirToTarget * dist, Color.red);

                }
                else
                {
                    //Debug.Log("Not direct");

                    isDirectPath = false;
                }
            }
        }
    }

    void DestroyScent(ScentNodes scent)
    {
        if (scent.scentTestObj)
        {
            Destroy(scent.scentTestObj);
            //sDebug.Log("Destroyed Scent");
        }
        targetScents.Remove(scent);
    }

    bool CheckDistance(Vector3 distTarget)
    {
        if (distTarget != null)
        {
            Vector2 dirToTarget = (distTarget - transform.position).normalized;
            float dist = Vector2.Distance(transform.position, distTarget);

            RaycastHit2D[] hits = Physics2D.RaycastAll(transform.position, dirToTarget, dist);
            bool hitRight = true;
            foreach (RaycastHit2D hit in hits)
            {
                if (hit.collider != null)
                {
                    Crumb_Manager crumb = hit.collider.GetComponent<Crumb_Manager>();

                    if (!(hit.collider.CompareTag("Crumb") && crumb != null && crumb.isAir)
                        && !hit.collider.CompareTag("Light")
                        && !hit.collider.CompareTag("Player")
                        && !hit.collider.CompareTag("Attack")
                        && !hit.collider.CompareTag("NPC")
                        && !hit.collider.CompareTag("Planet_Atmosphere")
                        && !hit.collider.CompareTag("PlayerSecondaryColliders"))
                    {
                        hitRight = false;
                    }
                }
            }
            return hitRight;
        }
        else
        {
            return false;
        }
    }
}


