﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

[System.Serializable]
public class PlanetTypes {
    public string planetType;
    public string planetName;
    public string planetNameSuffix;
    public int spawnChance;
    public Vector2Int planetMaxRadiusMinMax;
    public TerrainSettings terrain;
    public int caveAmount;
    public CaveSettings caveSettings;
    public List<LayerSettings> layers = new List<LayerSettings>();
    public List<OreSettings> ores = new List<OreSettings>();
    public List<DecorationSettings> surfaceDecor = new List<DecorationSettings>();
    public float surfaceDecorChance;
    public Color surfaceColor;
    public Sprite surfaceSprite;
    public int gravityMax;
    public float waterGrav;
    public Vector2Int seaLevelMinMax;
    public GameObject planet;
    public Color atmosphereColor;
    public float atmosphereScalar;
    public float atmosphereTransparencyScalar;
    public NPCSpawn[] npcSpawns;
    public Vector2Int npcSpawnsMinMax;

}

public class Game_Manager : MonoBehaviour
{
    public GameObject player;
    public GameObject mainInventory;
    public GameObject debugInventory;
    public GameObject hotbarInventory;
    public GameObject handler;
    public GameObject genManager;
    public GameObject currentPlanet;
    public GameObject objOnHandler;
    public List<GameObject> miningTools = new List<GameObject>();
    public GameObject defaultPlanet;
    public List<PlanetTypes> planetTypes = new List<PlanetTypes>();
    public int planetCount;
    public List<GameObject> planets = new List<GameObject>();
    public List<int> planetWeights = new List<int>();
    public float planetDistanceScalar;
    public float playerLoadPlanetDistance;
    public bool isDoneGeneratingSolarSystem;

    public bool canMine;

    public Canvas mainCanvas;
    public bool buildingOn;
    public bool isInventoryOn;
    public bool isHoveringOverUI;
    public bool isObjOnHanlder;
    public bool isHoverOverController;
    public bool canBuild;
    public Camera mainCamera;

    Player_Manager pm;
    Inventory_Manager imMain;
    Inventory_Manager imHotbar;
    public Generation_Manager gm;
    Building_Manager bm;
    public GameObject menuManager;
    Game_Menu_Manager gmm;
    Slot_Manager handlerSM;
    Item_Drops id;

    void Start()
    {
        foreach (PlanetTypes pt in planetTypes)
        {
            planetWeights.Add(pt.spawnChance);
        }
        SpawnPlanets();
        gmm = menuManager.GetComponent<Game_Menu_Manager>();
        pm = player.GetComponent<Player_Manager>();
        imMain = mainInventory.GetComponent<Inventory_Manager>();
        imHotbar = hotbarInventory.GetComponent<Inventory_Manager>();
        bm = GetComponent<Building_Manager>();
        handlerSM = handler.GetComponent<Slot_Manager>();
        id = GetComponent<Item_Drops>();
    }

    private void Update()
    {
        //Planet stuff
        if (isDoneGeneratingSolarSystem)
        {
            EnablePlanet();
        }

        //Menu Stuff

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            gmm.ToggleMenus(0, 2);
            gmm.ToggleMenus(1, 2);
        }

        //Game Stuff

        if (handler.activeInHierarchy == true)
        {
            //Mouse postition for handler.
            Vector2 pos;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                mainCanvas.transform as RectTransform,
                Input.mousePosition,
                mainCanvas.worldCamera,
                out pos
            );

            handler.GetComponent<RectTransform>().localPosition = pos;
        }

        //Inventory Toggle
        if (Input.GetKeyDown(KeyCode.E))
        {
            bm.anchorObjs.RemoveAll(obj => obj == null);
            gmm.ToggleMenus(1, 3);
            gmm.ToggleMenus(0, 2);

            if (gmm.menus[1].isActive == false)
            {
                isInventoryOn = false;
                if (buildingOn)
                {
                    handlerSM.HandlerSwitchViews(true);
                }
            }
            else
            {
                isInventoryOn = true;
                SetBuildingModeOff();
            }
        }

        if (Input.GetKeyDown(KeyCode.F) && !handlerSM.isHandlerFree && !buildingOn)
        {
            id.SpawnItem(handlerSM.slotInfo.curItem.uID, (Vector2)bm.buildingTool.transform.position, bm.buildingTool.transform.rotation,false);
            handlerSM.DecreaseSlotAmount(1);
        }

        //Build mode toggle
        if (Input.GetKeyDown(KeyCode.Q) && isInventoryOn == false)
        {
            bm.anchorObjs.RemoveAll(obj => obj == null);
            if (buildingOn == true || canBuild == false)
            {
                SetBuildingModeOff();
            }
            else if (canBuild == true && buildingOn == false)
            {
                SetBuildingModeOn();
            }
        }

        //Controller Unit
        if (Input.GetMouseButtonDown(0) && isInventoryOn == false && pm.controllerInUse != null && isHoverOverController)
        {
            if (pm.isControlled == true)
            {
                pm.ExitController();
            }
            else
            {
                pm.InController();
            }
        }

        //Debug menu toggle
        if (Input.GetKeyDown(KeyCode.T))
        {
            if (debugInventory.activeInHierarchy)
            {
                debugInventory.SetActive(false);
            }
            else
            {
                debugInventory.SetActive(true);
            }
        }

        if (EventSystem.current.IsPointerOverGameObject())
        {
            isHoveringOverUI = true;
            handlerSM.HandlerSwitchViews(false);
            return;
        }
        else
        {
            isHoveringOverUI = false;
        }

        if (!handlerSM.isHandlerFree && handlerSM.slotInfo.curItem.isWeapon)
        {
            if (canBuild != false)
            {
                canBuild = false;
                pm.GetChosenAttack(handlerSM.slotInfo.curItem.uID);

            }
        }
        else if (canBuild == false)
        {
            canBuild = true;
        }
        if (!handlerSM.slotInfo.curItem.isWeapon)
        {
            if (pm.chosenAttack != null)
            {
                if (pm.chosenAttack.armModel != null)
                {
                    pm.chosenAttack.armModel.SetActive(false);
                    pm.chosenAttack = null;
                }

            }
        }

        if (Input.GetMouseButtonDown(0))
        {
            if (handlerSM.isHandlerFree)
            {
                Vector2 mousePos = mainCamera.ScreenToWorldPoint(Input.mousePosition);

                int clickableMask = LayerMask.GetMask("Clickable");

                RaycastHit2D hit = Physics2D.Raycast(
                    mousePos,
                    Vector2.zero,
                    Mathf.Infinity,
                    clickableMask
                );

                if (hit.collider != null && hit.collider.GetComponent<Object_Manager>())
                {
                    hit.collider.GetComponent<Object_Manager>().ClickedObject();

                    //Debug.Log("Clicked: " + hit.collider.name);

                }

            }
            if (isObjOnHanlder && objOnHandler.GetComponent<Object_Manager>().canPlace && !handlerSM.isHandlerFree)
            {
                PlaceObject();
            }
            if (!handlerSM.isHandlerFree && handlerSM.slotInfo.curItem.isWeapon)
            {
                if (pm.isAttacking == false && pm.chosenAttack.isReloading == false)
                {
                    pm.GetChosenAttack(handlerSM.slotInfo.curItem.uID);
                    //Debug.Log("called one time");
                    StartCoroutine(pm.Attacks());
                }
            }
        }
        if (Input.GetMouseButton(0))
        {
            if (!handlerSM.isHandlerFree && handlerSM.slotInfo.curItem.isWeapon)
            {
                if (pm.isAttacking == false && pm.chosenAttack.canBeHeldDown && pm.chosenAttack.isReloading == false)
                {
                    //Debug.Log("called hold time");
                    StartCoroutine(pm.Attacks());
                }
            }
        }
        bm.anchorObjs.RemoveAll(obj => obj == null);

        if (canMine == true && !handlerSM.isHandlerFree)
        {
            canMine = false;
        }
        else if (canMine == false && handlerSM.isHandlerFree) 
        {
            canMine = true;
        }
    }
    private void LateUpdate()
    {
        Vector3 mousePos = Input.mousePosition;
        mousePos.z = -mainCamera.transform.position.z; // distance from camera to 0-plane

        Vector3 worldPos = mainCamera.ScreenToWorldPoint(mousePos);
        worldPos.z = 0;

        miningTools[0].transform.position = worldPos;

    }

    void PlaceObject()
    {
        Object_Manager om = objOnHandler.GetComponent<Object_Manager>();

        if (objOnHandler.GetComponent<Anchor_Manager>() != null)
        {
            om.isAnchor = true;
            bm.anchorObjs.Add(objOnHandler);

            foreach (Transform child in objOnHandler.transform.GetChild(0))
            {
                child.gameObject.GetComponent<SpriteRenderer>().enabled = true;
            }
        }
        else if (!objOnHandler.GetComponent<Object_Manager>().isLoose)
        {
            om.anchorObj.GetComponent<Anchor_Manager>().objsAttached.Add(objOnHandler);
        }

        if (om.isTrigger == false)
        {
            Collider2D[] cols = objOnHandler.GetComponents<Collider2D>();
            if (cols.Length > 1)
            {
                cols[0].isTrigger = false;
            }
        }
        if (om.isDrill)
        {
            if (objOnHandler.GetComponent<Mining>().startOn)
            {
                objOnHandler.GetComponent<Mining>().isOn = true;
            }
        }

        if (om.hasSecondaryAfterPlace)
        {
            om.secondaryForActive.SetActive(true);
            if (om.isHinge)
            {
                Object_Manager secOM = om.secondaryForActive.GetComponent<Object_Manager>();
                secOM.anchorObj = om.anchorObj;
                Destroy(objOnHandler.transform.GetChild(0).transform.GetChild(0).gameObject);
            }
        }
        om.isPlaced = true;
        Rigidbody2D spawnedRB;
        if (objOnHandler.GetComponent<Rigidbody2D>())
        {
            spawnedRB = objOnHandler.GetComponent<Rigidbody2D>();
        }
        else
        {
            spawnedRB = objOnHandler.AddComponent<Rigidbody2D>();
        }
        spawnedRB.gravityScale = 0;
        spawnedRB.bodyType = RigidbodyType2D.Dynamic;
        spawnedRB.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
        spawnedRB.mass = om.rbMass;
        spawnedRB.interpolation = RigidbodyInterpolation2D.Interpolate;

        string curItemCountString = handler.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text;
        int curItemCount = int.Parse(curItemCountString);
        curItemCount -= 1;
        handlerSM.slotInfo.slotCount = curItemCount;
        handler.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = curItemCount.ToString();
        if (handlerSM.slotInfo.slotCount == 0)
        {
            handlerSM.isHandlerFree = true;
        }
        bm.allObjects.Add(objOnHandler);

        if (objOnHandler.GetComponent<Physics_Object_Manager>() != null)
        {
            objOnHandler.GetComponent<Physics_Object_Manager>().enabled = true;
        }

        if (objOnHandler.GetComponent<Object_Manager>().isSnapped)
        {
            foreach (GameObject obj in objOnHandler.GetComponent<Object_Manager>().snappedObj)
            {
                FixedJoint2D joint = objOnHandler.AddComponent<FixedJoint2D>();
                joint.connectedBody = obj.transform.parent.transform.parent.GetComponent<Rigidbody2D>();
                objOnHandler.transform.SetParent(obj.transform);
            }
            objOnHandler.transform.position = objOnHandler.GetComponent<Object_Manager>().snappedObj[0].transform.TransformPoint(new Vector3(0f, 2, 0f));

        }
        if (curItemCount <= 0)
        {
            handlerSM.SetSlotVoid();
            bm.onHandler = null;
            objOnHandler = null;
            isObjOnHanlder = false;
        }
        else
        {
            bm.SetObjOnHandler();
        }
    }

    public void AddToInventory(string objName)
    {
        ItemData iData = GetComponent<Item_Drops>().itemData.Find(item => objName.Contains(item.itemObj.name));

        int amountReturned = 0;
        int amountReturned1 = 0;
        //Debug.Log("Part 3 adding via gm");
        amountReturned = imMain.AddItem(bm.buildingObjs[iData.uID].itemInfo, 1);
        if (amountReturned != -1)
        {
            amountReturned1 = imHotbar.AddItem(bm.buildingObjs[iData.uID].itemInfo, amountReturned);
            if (amountReturned1 != -1)
            {
                Debug.Log("No more room!" + amountReturned1);

            }
        }
    }
    public void SetBuildingModeOn()
    {
        buildingOn = true;
        Time.timeScale = 0.2f;
        Time.fixedDeltaTime = 0.02f * Time.timeScale;
        if (isInventoryOn == false)
        {
            handlerSM.HandlerSwitchViews(true);
        }
        bm.allObjects.RemoveAll(obj => obj == null);

        foreach (GameObject obj in bm.allObjects)
        {
            foreach (Transform child in obj.transform.GetChild(0))
            {
                child.gameObject.GetComponent<SpriteRenderer>().enabled = true;
                //Debug.Log("SHOULD be turning on");
            }
            if (obj.GetComponent<Object_Manager>().isAnchor)
            {
                obj.transform.GetChild(1).gameObject.SetActive(true);

            }
        }
    }

    public void SetBuildingModeOff()
    {
        buildingOn = false;
        Time.timeScale = 1f;
        Time.fixedDeltaTime = 0.02f;
        bm.allObjects.RemoveAll(obj => obj == null);

        foreach (GameObject obj in bm.allObjects)
        {
            foreach (Transform child in obj.transform.GetChild(0))
            {
                child.gameObject.GetComponent<SpriteRenderer>().enabled = false;
            }
            if (obj.GetComponent<Object_Manager>().isAnchor)
            {
                obj.transform.GetChild(1).gameObject.SetActive(false);
            }
        }
        handlerSM.HandlerSwitchViews(false);
    }
    
    public int GetRandomWeightedReturn(List<int> weights)
    {
        int totals = 0;
        foreach (int i in weights)
        {
            totals += i;
        }

        int randChosen = Random.Range(0,totals);

        int tempTotals = 0;

        for (int i = 0; i < weights.Count; i++)
        {
            tempTotals += weights[i];

            if (tempTotals > randChosen)
            {
                return i;
            }
        }
        return -1;
    }

    void SpawnPlanets()
    {
        GameObject spawnedPlanet;

        for (int i = 0; i < planetCount; i++)
        {
            Vector2 spawnPos = new Vector2(0, 0);

            spawnedPlanet = Instantiate(defaultPlanet, spawnPos, Quaternion.identity);
            GameObject planetManager = spawnedPlanet.transform.GetChild(0).gameObject;

            int chosenIndex = 0;
            if (i != 0)
            {
                chosenIndex = GetRandomWeightedReturn(planetWeights);
            }

            Debug.Log("Returned Planet: " + chosenIndex + " " + planetTypes[chosenIndex].planetType);
            PlanetTypes chosenPlanetType = planetTypes[chosenIndex];
            chosenPlanetType.planet = spawnedPlanet;
            chosenPlanetType.planetName = "Test Planet " + i + chosenPlanetType.planetNameSuffix;

            planets.Add(planetManager);

            Generation_Manager pGen = planetManager.GetComponent<Generation_Manager>();
            Spawning_Manager nMan = planetManager.GetComponent<Spawning_Manager>();

            //Sets Radius.
            int planetMaxRadius = Random.Range(chosenPlanetType.planetMaxRadiusMinMax.x, chosenPlanetType.planetMaxRadiusMinMax.y);
            pGen.planetMaxRadius = planetMaxRadius;

            //Sets Cut Off Radius.
            pGen.planetCutOffRadius = Mathf.RoundToInt(0.76f * pGen.planetMaxRadius);

            //Sets sea level.
            if (chosenPlanetType.seaLevelMinMax.y == -1)
            {
                chosenPlanetType.seaLevelMinMax.y = (int)pGen.planetCutOffRadius;
                chosenPlanetType.seaLevelMinMax.x = (int)pGen.planetCutOffRadius - chosenPlanetType.seaLevelMinMax.x;
            }
            int planetSeaLevel = Random.Range(chosenPlanetType.seaLevelMinMax.x, chosenPlanetType.seaLevelMinMax.y);
            pGen.seaLevel = planetSeaLevel;

            //Sets terrain settings
            chosenPlanetType.terrain.maxHeight = pGen.planetCutOffRadius;
            pGen.currentTerrain = chosenPlanetType.terrain;

            //Cave settings
            pGen.caveAmount = chosenPlanetType.caveAmount;
            pGen.currentCave = chosenPlanetType.caveSettings;

            //Layers
            pGen.layers.Clear();
            pGen.layers = chosenPlanetType.layers;

            //Ores
            pGen.ores.Clear();
            pGen.ores = chosenPlanetType.ores;

            //Surface Decor
            pGen.surfaceDecorChance = chosenPlanetType.surfaceDecorChance;
            pGen.surfaceDecor.Clear();
            pGen.surfaceDecor = chosenPlanetType.surfaceDecor;

            //Gravity
            pGen.gravityMax = chosenPlanetType.gravityMax;
            pGen.waterGrav = chosenPlanetType.waterGrav;

            //Sets Atmosphere
            GameObject atmosphere;
            atmosphere = spawnedPlanet.transform.GetChild(1).gameObject;
            atmosphere.transform.localScale = new Vector2(planetMaxRadius * chosenPlanetType.atmosphereScalar, planetMaxRadius * chosenPlanetType.atmosphereScalar);
            SpriteRenderer sr = atmosphere.GetComponent<SpriteRenderer>();
            Color c = chosenPlanetType.atmosphereColor;
            c.a = chosenPlanetType.atmosphereTransparencyScalar;
            sr.color = c;

            //Sets Surface
            pGen.surfaceSprite = chosenPlanetType.surfaceSprite;
            pGen.surfaceSmoothingColor = chosenPlanetType.surfaceColor;

            //NPC Stuff
            nMan.npcSpawns = chosenPlanetType.npcSpawns;
            int maxSpawns = Random.Range(chosenPlanetType.npcSpawnsMinMax.x, chosenPlanetType.npcSpawnsMinMax.y);
            nMan.maxSpawns = maxSpawns;

            //Give info to planet.
            pGen.planetSettings = chosenPlanetType;
        }
        StartCoroutine(InitalizePlanets());
    }
    IEnumerator InitalizePlanets()
    {
        for (int i = 0; i < planets.Count; i++)
        {
            GameObject planet = planets[i];
            yield return null;
            planet.transform.parent.transform.position = new Vector2(150, 0);
            if (i != 0)
            {
                yield return null;
                float planetAtmosphereDiameter = planet.transform.parent.GetChild(1).gameObject.GetComponent<SpriteRenderer>().bounds.size.x;
                float oldPlanetAtmosphereDiameter = planets[i-1].transform.parent.GetChild(1).gameObject.GetComponent<SpriteRenderer>().bounds.size.x;
                Vector2 oldPos = new Vector2(Random.Range(-oldPlanetAtmosphereDiameter * planetDistanceScalar, oldPlanetAtmosphereDiameter * planetDistanceScalar), Random.Range(oldPlanetAtmosphereDiameter, oldPlanetAtmosphereDiameter * planetDistanceScalar));
                Vector2 newPos = new Vector2(Random.Range(-planetAtmosphereDiameter * planetDistanceScalar, planetAtmosphereDiameter * planetDistanceScalar), Random.Range(planetAtmosphereDiameter, planetAtmosphereDiameter * planetDistanceScalar));

                planet.transform.parent.transform.position = (Vector2)planets[i-1].transform.position + newPos + oldPos;
            }

            genManager = planet;
            //currentPlanet = planet;

            planet.transform.parent.gameObject.SetActive(true);
            yield return new WaitUntil(() => planet.GetComponent<Generation_Manager>().isDoneMainPlanet);
            yield return new WaitForSeconds(2);
            planet.transform.gameObject.SetActive(false);
            yield return new WaitForSeconds(.1f);

            planet.transform.gameObject.SetActive(true);

        }

        isDoneGeneratingSolarSystem = true;
    }

    void EnablePlanet()
    {
        foreach (GameObject planet in planets)
        {
            if (planet.GetComponent<Generation_Manager>().isDoneGeneratingPlanet)
            {
                if (planet.activeInHierarchy == false)
                {
                    float planetAtmosphereDiameter = planet.transform.parent.GetChild(1).gameObject.GetComponent<SpriteRenderer>().bounds.size.x;

                    if ((planet.transform.position - player.transform.position).sqrMagnitude < planetAtmosphereDiameter * planetAtmosphereDiameter * playerLoadPlanetDistance)
                    {
                        planet.gameObject.SetActive(true);
                    }
                }
                else
                {
                    float planetAtmosphereDiameter = planet.transform.parent.GetChild(1).gameObject.GetComponent<SpriteRenderer>().bounds.size.x;

                    if ((planet.transform.position - player.transform.position).sqrMagnitude > planetAtmosphereDiameter * planetAtmosphereDiameter * playerLoadPlanetDistance)
                    {
                        planet.gameObject.SetActive(false);
                    }
                }
            }
        }
    }
    public void UpdateWeaponInHand()
    {
        foreach (PlayerAttacks pa in pm.attacks)
        {
            if (pa.armModel != null)
            {
                pa.armModel.SetActive(false);
                pa.displayModel.SetActive(false);
            }
        }
    }
}
