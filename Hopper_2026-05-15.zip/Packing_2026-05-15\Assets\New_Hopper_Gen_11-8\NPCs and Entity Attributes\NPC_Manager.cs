using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;

public class NPC_Manager : MonoBehaviour
{
    public bool isFlying;
    public bool movesHorizontal;
    public bool applyGravityRotationCorrection;
    public bool applyGravity;
    public bool isInSpace;

    public bool isMoving;
    public bool movingRight;
    public bool isJumping;
    public bool canMoveRight;
    public bool canMoveLeft;
    public bool isAgainstWall;
    public bool isAgainstObjFlying;
    public bool canFlipNPC;
    public bool flipDir;
    public bool isMeleeClose;
    public bool shouldStopMoving;

    int prevDir;
    public float testingHorizontalSpeed;
    public float testingFlyingSpeed;
    public float acceleration;
    public float pushBackForce;
    public float closeEnoughToHorizontalThreshold;
    public float closeEnoughToJumpThreshold;
    public float jumpForce;
    public Vector2 jumpAngleOffsetRange;
    public Vector2 jumpTorqueRange;

    public Vector2 ogFlyingPath;
    public Vector2 primaryAxis;
    public Vector2 secondaryAxis;
    public Vector2 newAxis;

    public int ttestingMoveDir;
    public int currentDir;

    public ScentNodes targetScentNode;

    public GameObject planet;
    public GameObject target;
    public GameObject gameManager;
    public GameObject groundedObj;
    public GameObject model;

    public AnimationClip currentAnim;
    public AnimationClip savedAnimIndex;
    public AnimationClip jumpingAnim;

    Rigidbody2D rb;
    Game_Manager gm;
    Pathfinding pf;
    public NPC_States ns;
    Animator anim;
    public Health h;
    public NPC_Attacks na;

    private void Start()
    {
        pf = GetComponent<Pathfinding>();
        rb = GetComponent<Rigidbody2D>();
        ns = GetComponent<NPC_States>();
        na = GetComponent<NPC_Attacks>();
        h = GetComponent<Health>();
        if (model != null)
        {
            anim = model.GetComponent<Animator>();
        }

        if (gameManager != null)
        {
            gm = GetComponent<Game_Manager>();
        }
    }
    private void Update()
    {
        if (isInSpace == false)
        {
            h.CheckFallDamage();
            //Debug.Log("checking fall damage");
        }
    }
    private void FixedUpdate()
    {
        if (planet != null)
        {
            if (applyGravityRotationCorrection)
            {
                ApplyGravityRotation();
            }
        }
        if ((movesHorizontal || isFlying) && pf.isPathfinding == true)
        {
            MoveTowardsTarget(ns.currentSpeed);
        }
    }

    public void MovementHorizonal(int movementDir, float moveSpeed)
    {
        if (!isInSpace && ((movementDir == 1 && canMoveRight) || (movementDir == -1 && canMoveLeft)))
        {
            //Debug.Log("Should be horizontal");
            isMoving = true;
            currentDir = movementDir;
            Vector2 directionToPlanet = (planet.transform.position - transform.position).normalized;
            Vector2 platformVelocity = Vector2.zero;

            if (groundedObj != null)
            {
                Rigidbody2D platRb = groundedObj.GetComponent<Rigidbody2D>();
                if (platRb != null)
                    platformVelocity = platRb.linearVelocity;
            }

            Vector2 tangent = new Vector2(-directionToPlanet.y, directionToPlanet.x);

            // Current velocity RELATIVE to platform
            Vector2 relativeVelocity = rb.linearVelocity - platformVelocity;
            // Extract current tangent component
            float currentTangentSpeed = Vector2.Dot(relativeVelocity, tangent);
            // Desired tangent speed
            float desiredTangentSpeed = movementDir * moveSpeed;
            // Compute delta only on tangent axis
            float deltaTangentSpeed = desiredTangentSpeed - currentTangentSpeed;
            // Apply force ONLY along tangent
            Vector2 force = tangent * deltaTangentSpeed * rb.mass / Time.fixedDeltaTime;
            float TANGENT_EPSILON = 0.1f;

            if (Mathf.Abs(deltaTangentSpeed) > TANGENT_EPSILON)
            {
                force = tangent * deltaTangentSpeed * rb.mass / Time.fixedDeltaTime;
                rb.AddForce(force);
            }
            prevDir = movementDir;
            
        }
        else
        {
            if (isMoving == true)
            {
                isMoving = false;
                //Debug.Log("Against wall, not moving");
                currentDir = 0;
            }

            if ((movementDir == 1 && !canMoveRight) || (movementDir == -1 && !canMoveLeft))
            {
                Jumping();
            }
        }
    }

    public void MovementFlying(Vector2 targetVector,float moveSpeed)
    {
        Vector2 dirToTarget = (targetVector - (Vector2)transform.position).normalized;
        Vector2 force = dirToTarget * moveSpeed;
        Vector2 velChange = force - rb.linearVelocity;
        Vector2 appliedForce = velChange * acceleration;

        ogFlyingPath = appliedForce;
        
        if (rb.linearVelocity.magnitude < 0.5f)
        {
            float absX = Mathf.Abs(force.x);
            float absY = Mathf.Abs(force.y);


            if (absX > absY)
            {
                primaryAxis = new Vector2(Mathf.Sign(force.x), 0);
                secondaryAxis = new Vector2(0, Mathf.Sign(force.y));
                newAxis = new Vector2(appliedForce.x, appliedForce.y*pushBackForce);
                //Debug.Log("primary force x");
            }
            else
            {
                primaryAxis = new Vector2(0, Mathf.Sign(force.y));
                secondaryAxis = new Vector2(Mathf.Sign(force.x), 0);
                newAxis = new Vector2(appliedForce.x*pushBackForce, appliedForce.y);
                //Debug.Log("primary force y");
            }

            rb.AddForce(-appliedForce);
            appliedForce = newAxis;
        }
        //Debug.Log(targetVector+ " - target vector     "+ moveSpeed + " - MoveSpeed");
        //Debug.Log("Should be applying the force");
        rb.AddForce(appliedForce);
    }

    public void Jumping()
    {
        if (isJumping == false && groundedObj != null && planet != null && !na.chosenAttack)
        {
            //Debug.Log("Should be jumping");
            isJumping = true;
            float offSet = Random.Range(jumpAngleOffsetRange.x,jumpAngleOffsetRange.y);
            float jumpTorque = Random.Range(jumpAngleOffsetRange.x, jumpAngleOffsetRange.y);

            Vector2 dirToPlanet = (transform.position - planet.transform.position).normalized;
            Vector2 offsetDir = Quaternion.Euler(0, 0, offSet) * dirToPlanet;

            rb.AddForce(offsetDir * jumpForce, ForceMode2D.Impulse);
            //rb.AddTorque(jumpTorque, ForceMode2D.Impulse);
            UpdateAnims(jumpingAnim,false);
        }
    }

    void ApplyGravityRotation()
    {
        Vector2 directionToPlanet = (Vector2)planet.transform.position - rb.position;
        float angle = Mathf.Atan2(directionToPlanet.y, directionToPlanet.x) * Mathf.Rad2Deg - 90f + 180f;
        rb.MoveRotation(angle);
    }

    public void MoveTowardsTarget(float pfSpeed)
    {
        Vector2 targetLocation;

        if (pf.isDirectPath && pf.target != null)
        {
            targetLocation = pf.target.transform.position;
        }
        else
        {
            targetLocation = pf.latestScentNode.scentPos;
        }
        
        if (movesHorizontal)
        {
            Vector2 localPos = transform.InverseTransformPoint(targetLocation);

            if (localPos.x > closeEnoughToHorizontalThreshold)
            {
                //Debug.Log("is facing right");
                MovementHorizonal(1, pfSpeed);
            }
            else if (localPos.x < -closeEnoughToHorizontalThreshold)
            {
                //Debug.Log("is facing left");
                MovementHorizonal(-1, pfSpeed);
            }
            if (localPos.y > closeEnoughToJumpThreshold)
            {
                Jumping();
            }
        }
        else if (isFlying)
        {
            //Debug.Log("pfspeed : "+pfSpeed + " targetlocation : " + targetLocation);
            MovementFlying(targetLocation, pfSpeed);
        }
    }

    public void FlipNPC()
    {
        if (currentDir*(int)Mathf.Sign(ns.currentSpeed) == 1)
        {
            flipDir = false;
            //Debug.Log("MOVING Right");
            Vector3 scale = model.transform.localScale;
            scale.x = Mathf.Abs(scale.x);
            model.transform.localScale = scale;
        }
        else if (flipDir == false && currentDir * (int)Mathf.Sign(ns.currentSpeed) == -1)
        {
            flipDir = true;
            //Debug.Log("MOVING Left");

            Vector3 scale = model.transform.localScale;
            scale.x = -Mathf.Abs(scale.x);
            model.transform.localScale = scale;
        }
    }

    public void UpdateAnims(AnimationClip animIndex,bool setIndex)
    {
        //Debug.Log("Changed Anim");
        if (anim != null)
        {
            //Debug.Log("Passed anim check");
            if (animIndex == jumpingAnim)
            {
                //Jump is being called multiple times sometines. not good.
                //Debug.Log("should be ju,ping anim");
            }
            if (setIndex)
            {
                //Debug.Log("Saved Anim");
                savedAnimIndex = animIndex;
            }
            currentAnim = animIndex;
            anim.CrossFade(animIndex.name, 0.08f);
        }
    }

    public void FightFlight(GameObject hitTarget)
    {
        pf.target = hitTarget;
        target = hitTarget;
        ns.triggeredAttack = true;
    }

    public void SetDeath()
    {
        //Debug.Log("Set npc to dead!");
        foreach (ScentNodes pFTestingObj in pf.targetScents)
        {
            if (pFTestingObj.scentTestObj)
            {
                Destroy(pFTestingObj.scentTestObj);
            }
        }
        Destroy(gameObject);
    }

    public IEnumerator SetDisabled()
    {
        yield return null;
        //Debug.Log("fwpoejfpwefpwjp");
        pf.isPathfinding = false;
        pf.isDirectPath = false;
        isMoving = false;

        // Disable physics & collisions
        rb.simulated = false;
        GetComponent<Collider2D>().enabled = false;

        // Disable NPC logic (this script)
        na.enabled = false;
        ns.enabled = false;
        pf.enabled = false;

        this.enabled = false;
    }
    public void SetEnabled()
    {
        rb.simulated = true;
        GetComponent<Collider2D>().enabled = true;

        na.enabled = true;
        ns.enabled = true;
        pf.enabled = true;
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Planet_Atmosphere"))
        {
            planet = other.transform.parent.GetChild(0).gameObject;
            isInSpace = false;

        }
    }
}
