using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Slot_Manager : MonoBehaviour, IPointerClickHandler
{
    public Slot slotInfo;
    public bool isHandler;
    public GameObject handler;
    public GameObject gameManager;
    public Slot defaultSlot;
    public GameObject inventory;
    public bool handlerViewMode;
    public bool isHandlerFree;
    Inventory_Manager im;
    Building_Manager bm;
    Game_Manager gm;
    private void Start()
    {
        gm = gameManager.GetComponent<Game_Manager>();
        bm = gameManager.GetComponent<Building_Manager>();
        im = inventory.GetComponent<Inventory_Manager>();
        defaultSlot.slotObj = gameObject;
        slotInfo.slotObj = gameObject;
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public void OnPointerClick(PointerEventData eventData)
    {
        gm.SetBuildingModeOff();

        Slot_Manager sm = handler.GetComponent<Slot_Manager>();
        if (sm.slotInfo.curItem.uID == -1)
        {
            sm.isHandlerFree = true;
        }
        else
        {
            sm.isHandlerFree = false;
        }
        if (eventData.button == PointerEventData.InputButton.Left && isHandler == false)
        {
            if (sm.slotInfo.curItem.uID != slotInfo.curItem.uID && slotInfo.curItem.isWeapon && sm.slotInfo.curItem.isWeapon)
            {
                gm.UpdateWeaponInHand();
            }
            //Handler empty but slot filled
            if (sm.isHandlerFree && slotInfo.curItem.uID != -1)
            {
                //Debug.Log("type1");
                sm.slotInfo = slotInfo;
                slotInfo = defaultSlot;
                slotInfo.slotObj = gameObject;
            }
            else if (slotInfo.curItem.uID == -1 && !sm.isHandlerFree)
            {
                //Debug.Log("type2");

                slotInfo = sm.slotInfo;
                sm.slotInfo = sm.defaultSlot;
                slotInfo.slotObj = gameObject;
            }
            else if (slotInfo.curItem.uID == sm.slotInfo.curItem.uID)
            {
                //Debug.Log("type3 " + slotInfo.slotCount + sm.slotInfo.slotCount);

                if (slotInfo.slotCount + sm.slotInfo.slotCount > slotInfo.maxCount)
                {
                    sm.slotInfo.slotCount = (slotInfo.slotCount + sm.slotInfo.slotCount) - slotInfo.maxCount;

                    slotInfo.slotCount = slotInfo.maxCount;
                }
                else if (slotInfo.slotCount + sm.slotInfo.slotCount <= slotInfo.maxCount)
                {
                    slotInfo.slotCount += sm.slotInfo.slotCount;
                    sm.slotInfo = sm.defaultSlot;
                }

            }
            else if (slotInfo.curItem.uID != sm.slotInfo.curItem.uID & !sm.isHandlerFree)
            {
                //Debug.Log("type4");
                Slot savedSlot = sm.slotInfo;

                sm.slotInfo = slotInfo;
                slotInfo = savedSlot;
                slotInfo.slotObj = gameObject;
            }
            UpdateHandlerDisplay(sm);
            UpdateSlotDisplay();
            im.UpdateSlotsList();
            
        }
        if (sm.slotInfo.curItem.uID == -1)
        {
            sm.isHandlerFree = true;
        }
        else
        {
            sm.isHandlerFree = false;
        }
    }

    public void UpdateHandlerDisplay(Slot_Manager sm)
    {
        //Debug.Log("turned on: " + sm.slotInfo.curItem.uID);
        gm.player.GetComponent<Player_Manager>().GetChosenAttack(sm.slotInfo.curItem.uID);
        handler.GetComponent<Image>().sprite = sm.slotInfo.curItem.itemSprite;
        handler.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = sm.slotInfo.slotCount.ToString();
        if (sm.slotInfo.slotCount == 0)
        {
            handler.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = "";
        }
    }

    public void UpdateSlotDisplay()
    {
        if (!isHandler)
        {
            transform.GetChild(0).GetComponent<Image>().sprite = slotInfo.curItem.itemSprite;
            transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = slotInfo.slotCount.ToString();
        }
        else
        {
            GetComponent<Image>().sprite = slotInfo.curItem.itemSprite;
            transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = slotInfo.slotCount.ToString();
        }
        //Debug.Log(slotInfo.slotCount.ToString());
    }

    public void HandlerSwitchViews(bool viewMode)
    {
        if (slotInfo.curItem.isItem == false && slotInfo.curItem.uID != -1)
        {
            handlerViewMode = viewMode;
            if (viewMode == true)
            {
                bm.SetObjOnHandler();
            }
            else
            {
                bm.SetObjOffHandlerFromView();
            }
        }
    }

    public void SetSlotVoid()
    {
        Slot temp = new Slot();
        temp.slotObj = slotInfo.slotObj;
        temp.curItem = defaultSlot.curItem;
        temp.maxCount = 5;
        slotInfo = temp;
        GetComponent<Image>().enabled = true;
        GetComponent<Image>().sprite = slotInfo.curItem.itemSprite;
        transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = "";
    }
    public void DecreaseSlotAmount(int amount)
    {
        if (slotInfo.slotCount - amount <= 0)
        {
            slotInfo = defaultSlot;
            if (isHandler)
            {
                isHandlerFree = true;
            }
            UpdateSlotDisplay();
            im.UpdateSlotsList();
        }
        else
        {
            slotInfo.slotCount -= amount;

            UpdateSlotDisplay();
            im.UpdateSlotsList();
        }
    }
}
