
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using System.IO;
#if UNITY_EDITOR

using UnityEditor.SearchService;
#endif
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Slider = UnityEngine.UI.Slider;
using UnityEngine.Video;

[System.Serializable]
public class KeyBinding
{
    public GameObject action;
    public KeyCode key;
}
public class Menus_OLD : MonoBehaviour
{
    [Header("Refernced Objects")]
    public GameObject mainPanel;
    public GameObject settingsPanel;
    public GameObject controlsPanel;
    public GameObject creditsPanel;
    public GameObject pausePanel;
    public GameObject backToMainButton;
    public GameObject volumeObj;
    public GameObject brightnessObj;
    public GameObject splashScreen;
    public GameObject fadeScreen;
    public GameObject menuHolder;
    public GameObject inventoryCanvas;
    public GameObject bugReportScreen;
    public GameObject bugReportTextbox;
    public GameObject versionText;
    public GameObject mainGame;
    public VideoPlayer videoPlayer;

    [Header("Bools and Numerical Variables")]
    private bool canRebind;
    public float volume;
    public float brightness;
    public string targetScene;
    public string menuScene;
    public float fadeSpeed;
    public float fadeTime;
    public float fadeLowerY;
    public float fadeLowerSpeed;
    public bool togglePause;
    public bool inGame;
    private string filePath;

    [Header("Lists and Dictionaries")]
    public List<KeyBinding> bindingsList;  // Editable in Inspector
    public Dictionary<GameObject, KeyCode> keyBindings = new Dictionary<GameObject, KeyCode>();

    void Start()
    {
        //Keeps this object active all the time.
        DontDestroyOnLoad(this.transform.parent.gameObject);

        filePath = Path.Combine(Application.persistentDataPath, "bug_reports.txt");
        Debug.Log("Bug report file at: " + filePath);

        videoPlayer.loopPointReached += SplashScreen;

        //Binds the action to the key.
        foreach (var binding in bindingsList)
        {
            keyBindings[binding.action] = binding.key;
        }
    }
    private void Update()
    {
        //Checks for the pause button being pressed.
        if (Input.GetKeyDown(KeyCode.Escape) && inGame)
        {
            if (togglePause == true)
            {
                togglePause = false;
                PressedUnPause();
            }
            else
            {
                togglePause = true;
                PressedPause();
            }
        }
    }

    public void SplashScreen(VideoPlayer vp)
    {
        //Runs if the intro anim is finished.
        Debug.Log("Video Finished");
        StartCoroutine(SplashFade());
    }
    IEnumerator SplashFade()
    {
        //Fades the splash screen.

        while (fadeTime < .99f)
        {
            fadeTime += fadeSpeed;
            fadeScreen.GetComponent<RawImage>().color = new Color(0, 0, 0, fadeTime);
            yield return null;
        }
        splashScreen.SetActive(false);
        yield return new WaitForSeconds(1);
        while (fadeScreen.GetComponent<RectTransform>().position.y > fadeLowerY)
        {
            fadeScreen.GetComponent<RectTransform>().localPosition = new Vector2(0, fadeScreen.GetComponent<RectTransform>().localPosition.y - fadeLowerSpeed);
            yield return null;
        }
        fadeScreen.SetActive(false);
    }
    public void CallChange(GameObject mainButton)
    {
        StartCoroutine(ChangeKeyBind(mainButton));
    }

    public void PressedPlay()
    {
        //Play Button Pressed.

        SceneManager.LoadScene(targetScene);
        menuHolder.GetComponent<Camera>().enabled = false;
        //mainGame.SetActive(true);
        Debug.Log("Loaded " + targetScene);
        inGame = true;

        mainPanel.SetActive(false);
        creditsPanel.SetActive(false);
        controlsPanel.SetActive(false);
        settingsPanel.SetActive(false);
        backToMainButton.SetActive(false);
        pausePanel.SetActive(false);
    }
    public void PressedSettings()
    {
        //Settings pressed.

        mainPanel.SetActive(false);
        creditsPanel.SetActive(false);
        controlsPanel.SetActive(false);
        settingsPanel.SetActive(true);
        backToMainButton.SetActive(true);
        pausePanel.SetActive(false);

    }
    public void PressedCredits()
    {
        //Credits pressed.

        mainPanel.SetActive(false);
        creditsPanel.SetActive(true);
        controlsPanel.SetActive(false);
        settingsPanel.SetActive(false);
        backToMainButton.SetActive(true);
        pausePanel.SetActive(false);

    }
    public void PressedControls()
    {
        //Controls pressed.

        mainPanel.SetActive(false);
        creditsPanel.SetActive(false);
        controlsPanel.SetActive(true);
        settingsPanel.SetActive(false);
        backToMainButton.SetActive(true);
        pausePanel.SetActive(false);

    }
    public void PressedQuit()
    {
        //Quit Pressed.

        Debug.Log("Quit game.");
    }
    public void PressedMain()
    {
        //Main pressed.

        if (inGame == false)
        {
            pausePanel.SetActive(false);
            mainPanel.SetActive(true);
            creditsPanel.SetActive(false);
            controlsPanel.SetActive(false);
            settingsPanel.SetActive(false);
            backToMainButton.SetActive(false);
        }
        else
        {
            PressedPause();
        }
    }
    public void PressedMainPauseMenu()
    {
        //Loads the Main Menu fronm pause screen.

        inGame = false;
        SceneManager.LoadScene(menuScene);
        menuHolder.GetComponent<Camera>().enabled = true;

    }
    public void PressedUnPause()
    {
        //Unpauses.

        pausePanel.SetActive(false);
        mainPanel.SetActive(false);
        creditsPanel.SetActive(false);
        controlsPanel.SetActive(false);
        settingsPanel.SetActive(false);
        backToMainButton.SetActive(false);
        Debug.Log("should be on");
        inventoryCanvas.SetActive(true);
        togglePause = false;

    }
    public void PressedPause()
    {
        //Pauses.

        pausePanel.SetActive(true);
        mainPanel.SetActive(false);
        creditsPanel.SetActive(false);
        controlsPanel.SetActive(false);
        settingsPanel.SetActive(false);
        backToMainButton.SetActive(false);
        if (inventoryCanvas == null)
        {
            inventoryCanvas = GameObject.Find("Inventory");
        }
        inventoryCanvas.SetActive(false);
        togglePause = true;

    }
    public void SetVolume()
    {
        //Volume controls. *WIP*

        volume = volumeObj.GetComponent<Slider>().value;
    }
    public void SetBrightness()
    {
        //Brightness controls. *WIP*

        brightness = brightnessObj.GetComponent<Slider>().value;
    }

    public void PressedBug()
    {
        //Sets the bug screen to active.

        bugReportScreen.SetActive(true);
    }

    public void SendBugReport()
    {
        //Sets and saves the bug report submitted.

        string report = "===========================================================\n" +
            $"*[{System.DateTime.Now}]\n" +
            $"*Version: {versionText.GetComponent<TextMeshProUGUI>().text}\n" +
            $"*Scene:{SceneManager.GetActiveScene().name}\n\n" +
            $"*Message:\n{bugReportTextbox.GetComponent<TMP_InputField>().text}\n\n";
        File.AppendAllText(filePath, report);
        Debug.Log("Bug report saved.");
        bugReportScreen.SetActive(false);
    }

    IEnumerator ChangeKeyBind(GameObject mainButton)
    {
        //Rebinds keys.

        canRebind = true;
        yield return null;
        while (canRebind == true)
        {
            foreach (KeyCode key in Enum.GetValues(typeof(KeyCode)))
            {
                if (Input.GetKeyDown(key))
                {
                    canRebind = false;
                    keyBindings[mainButton] = key;
                    mainButton.transform.GetChild(0).GetChild(0).GetComponent<TextMeshProUGUI>().text = key.ToString();

                    Debug.Log("Rebinded " + mainButton + " to " + key);

                    break;
                }
            }
            yield return null;

        }
    }
}
