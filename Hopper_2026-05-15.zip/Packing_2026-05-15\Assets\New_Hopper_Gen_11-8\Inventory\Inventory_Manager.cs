using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;
using TMPro;
using Unity.VisualScripting;

[System.Serializable]
public struct Item
{
    public GameObject itemObj;
    public Sprite itemSprite;
    public int maxCount;
    public int uID;
    public bool isItem;
    public bool isWeapon;

}
[System.Serializable]
public struct Slot
{
    public GameObject slotObj;
    public Item curItem;
    public int slotCount;
    public int maxCount;
    public bool isFull;
}
public class Inventory_Manager : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    /*
     * Plan!
     * 1. Have the inventory grid layed out and customizable.
     * 2. Have it easuly Queryable
     * 3. Have each slot be its own thing.
     * 4. Have a handler with a single slot.
     * 5. have it be able to add, drop, switch, split, etc.
     * 
     */

    public List<Slot> slots = new List<Slot>();
    public List<GameObject> slotObjs = new List<GameObject>();
    public int slotCount;
    public bool isHotBar;
    public GameObject slotObj;
    private GameObject spawned;
    public Item nullItem;
    public bool isDebug;
    public GameObject gameManager;
    Building_Manager bm;
    void Start()
    {
        if (isDebug)
        {
            bm = gameManager.GetComponent<Building_Manager>();
        }
        CreateInventory(slotCount);
        if (isHotBar == false)
        {
            gameObject.SetActive(false);

        }
    }

    void CreateInventory(int count)
    {
        for (int i = 0; i < count; i++)
        {
            spawned = Instantiate(slotObj, transform);
            slotObjs.Add(spawned);

            if (!isDebug)
            {
                Slot temp = new Slot();
                temp.slotObj = spawned;
                temp.curItem = nullItem;
                temp.maxCount = 5;
                spawned.SetActive(true);
                slots.Add(temp);
            }
            else
            {
                Slot temp = new Slot();
                temp.slotObj = spawned;
                temp.curItem = nullItem;
                temp.maxCount = 50;
                temp.slotCount = 50;
                temp.curItem.uID = i;
                foreach (BuildingInfo s in bm.buildingObjs)
                {
                    if (s.itemInfo.uID == i)
                    {
                        temp.curItem = s.itemInfo;
                    }
                }
                spawned.SetActive(true);
                slots.Add(temp);
                temp.slotObj.GetComponent<Slot_Manager>().slotInfo.curItem = temp.curItem;
                temp.slotObj.GetComponent<Slot_Manager>().slotInfo.maxCount = 50;
                temp.slotObj.GetComponent<Slot_Manager>().slotInfo.slotCount = 50;
                CheckSlotCount(temp);
                UpdateSlotDisplay();
            }

        }
    }
    public int AddItem(Item itemToAdd, int count)
    {
        int countLeft = count;
        //Debug.Log("part 4 actually addinf item");
        for (int i = 0; i < slots.Count; i++)
        {
            Slot slot = slots[i];
            if (countLeft > 0)
            {
                if (slot.isFull == false && (slot.curItem.uID == itemToAdd.uID))
                {
                    if (slot.slotCount + countLeft > slot.maxCount)
                    {
                        countLeft = (slot.slotCount + countLeft) - slot.maxCount;
                        slot.slotCount = slot.maxCount;

                    }
                    else
                    {
                        slot.slotCount += countLeft;
                        countLeft = 0;
                    }

                    if (slot.curItem.uID == nullItem.uID)
                    {
                        slot.curItem = itemToAdd;
                    }
                    slot.slotObj.GetComponent<Slot_Manager>().slotInfo = slot;
                    slots[i] = slot;
                    CheckSlotCount(slot);
                    UpdateSlotDisplay();
                }
            }
            else
            {
                break;
            }
        }
        for (int i = 0; i < slots.Count; i++)
        {
            Slot slot = slots[i];
            if (countLeft > 0)
            {

                if (slot.isFull == false && (slot.curItem.uID == nullItem.uID || slot.curItem.uID == itemToAdd.uID))
                {

                    if (slot.slotCount + countLeft > slot.maxCount)
                    {
                        countLeft = (slot.slotCount + countLeft) - slot.maxCount;
                        slot.slotCount = slot.maxCount;

                    }
                    else
                    {
                        slot.slotCount += countLeft;
                        countLeft = 0;
                    }

                    if (slot.curItem.uID == nullItem.uID)
                    {
                        slot.curItem = itemToAdd;
                    }
                    slot.slotObj.GetComponent<Slot_Manager>().slotInfo = slot;
                    slots[i] = slot;
                    CheckSlotCount(slot);
                    UpdateSlotDisplay();
                }
            }
            else
            {
                break;
            }
        }
        
        if (countLeft != 0)
        {
            return countLeft;
        }
        return -1;
    }
    public void CheckSlotCount(Slot slot)
    {
        if (slot.slotCount == slot.maxCount)
        {
            slot.isFull = true;
        }
        else
        {
            slot.isFull = false;
        }
    }

    public void UpdateSlotDisplay()
    {
        //Debug.Log("=======================================================");
        for (int i = 0; i < slots.Count; i++)
        {
            
            slots[i].slotObj.transform.GetChild(0).GetComponent<Image>().sprite = slots[i].curItem.itemSprite;
            slots[i].slotObj.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = slots[i].slotCount.ToString();
        }
    }
    public void UpdateSlotsList()
    {
        for (int i = 0; i < slots.Count; i++)
        {

            slots[i] = slotObjs[i].GetComponent<Slot_Manager>().slotInfo;
        }
    }

    public bool GetInventoryCounts(CraftingItem ci)
    {
        int foundItemCount = 0;

        foreach (Slot slot in slots)
        {
            if (slot.curItem.uID == ci.itemInfo.uID)
            {
                foundItemCount += slot.slotCount;
            }
        }

        if (foundItemCount >= ci.neededCount)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public void DecreaseSlots(int uID, int amount)
    {
        int amount2 = amount;

        while (amount2 > 0)
        {
            for (int i =0; i < slots.Count; i++)
            {
                Slot slot = slots[i];
                if (slot.curItem.uID == uID)
                {
                    if (amount2 >= slot.slotCount)
                    {
                        slot.slotObj.GetComponent<Slot_Manager>().DecreaseSlotAmount(slot.slotCount);
                        amount2 -= slot.slotCount;
                    }
                    else
                    {
                        slot.slotObj.GetComponent<Slot_Manager>().DecreaseSlotAmount(amount2);
                        amount2 = 0;
                    }
                }
            }
        }
    }
}
