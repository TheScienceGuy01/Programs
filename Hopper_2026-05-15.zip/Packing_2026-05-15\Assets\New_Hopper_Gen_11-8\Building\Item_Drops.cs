using UnityEngine;
using System.Collections.Generic;

[System.Serializable]

public class ItemData
{
    public GameObject itemObj;
    public float itemSpin;
    public float itemJumpForce;
    public int uID;
}

public class Item_Drops : MonoBehaviour
{
    public List<ItemData> itemData = new List<ItemData>();
    GameObject spawned;
    Game_Manager gm;
    Building_Manager bm;

    private void Start()
    {
        gm = GetComponent<Game_Manager>();
        bm = GetComponent<Building_Manager>();
    }
    public void SpawnItem(int uID, Vector2 spawnLocation, Quaternion spawnRot, bool addSpin)
    {
        ItemData item = itemData.Find(i => i.uID == uID);

        if (item != null)
        {
            spawned = Instantiate(item.itemObj, spawnLocation, spawnRot);
            Rigidbody2D rb = spawned.AddComponent<Rigidbody2D>();
            rb.gravityScale = 0;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            if (addSpin)
            {
                rb.AddTorque(item.itemSpin, ForceMode2D.Impulse);
                rb.AddForce(spawned.transform.up * item.itemJumpForce, ForceMode2D.Impulse);
            }

        }
    }
}
