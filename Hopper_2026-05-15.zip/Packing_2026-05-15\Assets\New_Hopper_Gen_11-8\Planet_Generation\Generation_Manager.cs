using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class TerrainSettings 
{
    public string tname;
    public float maxHeight;
    public float minHeight;
    public float dirChangeChance;
    public bool dir;
    public float slopeChangeChance;
    public float slopeMax;
    public float slopeMin;
    public float slope;
}
[System.Serializable]

public class CaveSettings
{
    public string cName;
    public GameObject caveDigger;
    public float widthMax;
    public float widthMin;
    public float dirChangeChance;
    public float dirChangeAmount;
    public float maxLength;
    public float minLength;
    public float caveMoveAmount;
    public float waterChance;
}

[System.Serializable]

public class LayerSettings
{
    public string lName;
    public float maxHeight;
    public float minHeight;
    public Sprite layerSprite;
    public float blendPercentage;
    public int layer;
    public float hardness;
    public Color smoothingColor;
}
[System.Serializable]

public class OreSettings
{
    public string oName;
    public float spreadChance;
    public float spreadRate;
    public Sprite oreSprite;
    public int layer;
    public int rarity;
    public float hardness;
    public int itemDropID;
}

[System.Serializable]

public class DecorationSettings
{
    public string dName;
    public GameObject decorObj;
    public bool isSurface;
    public bool isCave;
    public bool isWater;
    public bool isGroup;
    public float rarity;
    public float isolationRadius;
    public Vector3 decorCenter;
    public Vector3 pos;
}

public class Generation_Manager : MonoBehaviour
{
    [Header("Planet Settings")]
    public PlanetTypes planetSettings;
    public int planetMaxRadius;
    public float planetCutOffRadius;
    public int seaLevel;
    public GameObject[] planetConnectedObjects;
    public float waterToSolidRatio;
    public float airToOtherRatio;
    public string planetType;
    public bool isDoneNPCSpawn;
    public bool isDoneMainPlanet;
    public bool isDoneGeneratingPlanet;
    public bool isCorrupted;
    public int enableCount;

    [Header("Crumb Holders")]
    public GameObject lastStem;
    public GameObject rootCrumb;
    public GameObject stemCrumb;
    public List<GameObject> crumbs = new List<GameObject>();
    public List<GameObject> airCrumbs = new List<GameObject>();
    public List<GameObject> waterCrumbs = new List<GameObject>();
    public List<GameObject> surfaceCrumbs = new List<GameObject>();
    private GameObject spawned;
    public List<GameObject> targetObjs = new List<GameObject>();
    public List<GameObject> coreCrumbs = new List<GameObject>();
    public int activeCoreCrumbs;
    public Dictionary<Vector2, GameObject> crumbMap = new Dictionary<Vector2, GameObject>();


    [Header("Chunk Settings")]
    public float chunkSettingDistance;
    public GameObject chunk;
    public List<GameObject> chunks = new List<GameObject>();
    public GameObject chunkHolder;

    [Header("Terrain Settings")]
    public List<float> carveDistance = new List<float>();
    public TerrainSettings currentTerrain;
    public List<TerrainSettings> biomes = new List<TerrainSettings>();
    public int caveAmount;
    public CaveSettings currentCave;
    public List<CaveSettings> caves = new List<CaveSettings>();
    public List<LayerSettings> layers = new List<LayerSettings>();
    public float oreSpawnRate;
    public List<OreSettings> ores = new List<OreSettings>();
    List<int> oreRarities = new List<int>();
    public List<DecorationSettings> surfaceDecor = new List<DecorationSettings>();
    public List<DecorationSettings> surfaceDecorObjs = new List<DecorationSettings>();
    public float surfaceDecorChance;
    GameObject decorHolder;
    public float corruptionChance;
    public float destructionChance;
    public Sprite corruptionSprite;
    public float corruptionSpeed;
    public Sprite waterSprite;
    public Sprite surfaceSprite;
    public Color surfaceSmoothingColor;

    [Header("Gravity")]
    public bool dynamicGrav;
    public float gravityMax;
    public float gravityDropOff;
    public List<GameObject> gravityAffectedObjs = new List<GameObject>();
    public float waterGrav;

    [Header("Misc Variables")]
    public GameObject player;
    public GameObject gameManager;

    Game_Manager gm;
    Player_Manager pm;
    Spawning_Manager sm;

    private void Start()
    {
        //FIX BIOME HEIGHTS NEED TO REFLECT PLANET RADII
        //FIX PLANET WRAAPPING TO BE SMOOTH.
        gm = gameManager.GetComponent<Game_Manager>();
        foreach (OreSettings ore in ores)
        {
            oreRarities.Add(ore.rarity);
            //Debug.Log("added " + ore.oName);
        }
        decorHolder = transform.parent.GetChild(4).gameObject;
        sm = GetComponent<Spawning_Manager>();
        pm = player.GetComponent<Player_Manager>();
        crumbs.Add(rootCrumb);
        CarveTerrian();
        StartCoroutine(InitializeStemCrumbs());
    }

    IEnumerator InitializeStemCrumbs()
    {
        foreach (Transform child in rootCrumb.transform)
        {
            yield return null;
            spawned = Instantiate(stemCrumb, child.transform.position, child.transform.rotation);
            spawned.GetComponent<Crumb_Manager>().index = 1;
            spawned.GetComponent<Crumb_Manager>().radius = planetMaxRadius;
            spawned.GetComponent<Crumb_Manager>().enabled = true;
            spawned.GetComponent<Crumb_Manager>().isCoreCrumb = true;
            //Debug.Log("from stem stuff");
            //crumbs.Add(spawned);
            coreCrumbs.Add(spawned);
            activeCoreCrumbs += 1;
        }
        InitializeChunks();

        StartCoroutine(CheckCrumbGen());
    }
    private void FixedUpdate()
    {
        targetObjs.RemoveAll(item => item == null);
        gravityAffectedObjs.RemoveAll(item => item == null);
        sm.planetNPCs.RemoveAll(item => item == null);

        if (isDoneNPCSpawn)
        {
            if (sm.stillSpawningStructures == 0)
            {
                isDoneGeneratingPlanet = true;
            }
        }

        //Chunks
        if (chunks.Count != 0 && isDoneGeneratingPlanet)
        {
            for (int i = 0; i < chunks.Count; i++)
            {
                if ((chunks[i].transform.position - pm.cameraObj.transform.position).sqrMagnitude < chunkSettingDistance && chunks[i].GetComponent<Chunk_Manager>().crumbHolder.activeInHierarchy == false)
                {
                    chunks[i].GetComponent<Chunk_Manager>().crumbHolder.SetActive(true);
                }
                else if ((chunks[i].transform.position - pm.cameraObj.transform.position).sqrMagnitude > chunkSettingDistance && chunks[i].GetComponent<Chunk_Manager>().crumbHolder.activeInHierarchy == true)
                {
                    chunks[i].GetComponent<Chunk_Manager>().crumbHolder.SetActive(false);
                }
            }
        }

        Gravity();
    }
    IEnumerator CheckCrumbGen()
    {
        int tempCount = 0;
        yield return new WaitForSeconds(0.5f);

        while (tempCount != crumbs.Count)
        {
            tempCount = crumbs.Count;
            yield return new WaitForSeconds(0.5f);
        }
        //Debug.Log("Done With Crumbs!");
        crumbs.RemoveAll(item => item == null);

        SetPlanetSections();
    }
    void CarveTerrian()
    {
        for (int i = 0; i < 360; i++)
        {
            carveDistance.Add(seaLevel);
        }

        for (int i = 0; i < carveDistance.Count; i++)
        {

            if (i == 0)
            {
                carveDistance[i] = Random.Range(currentTerrain.minHeight, currentTerrain.maxHeight);
            }
            else
            {
                if (Random.value < currentTerrain.slopeChangeChance)
                {
                    currentTerrain.slope = Random.Range(currentTerrain.slopeMin, currentTerrain.slopeMax);
                }
                if (Random.value < currentTerrain.dirChangeChance)
                {
                    if (currentTerrain.dir == true)
                    {
                        currentTerrain.dir = false;
                    }
                    else
                    {
                        currentTerrain.dir = true;

                    }
                }

                if (currentTerrain.dir == true)
                {
                    if (carveDistance[i - 1] >= currentTerrain.maxHeight)
                    {
                        carveDistance[i] = carveDistance[i - 1];
                    }
                    else
                    {
                        carveDistance[i] = currentTerrain.slope * Random.value + carveDistance[i - 1];
                    }
                }
                else
                {
                    if (carveDistance[i - 1] <= currentTerrain.minHeight)
                    {
                        carveDistance[i] = carveDistance[i - 1];
                    }
                    else
                    {
                        carveDistance[i] =  carveDistance[i - 1] - currentTerrain.slope * Random.value;
                    }
                }
            }
        }

        //Debug.Log("Done Setting Terrian...");
    }
    void SetPlanetSections()
    {
        
        float farthestCrumbDist = 0;
        GameObject farthestCrumb = null;

        for (int i = 0; i < surfaceCrumbs.Count; i++)
        {
            GameObject crumb = surfaceCrumbs[i];
            if (crumb != null)
            {
                if (Mathf.Abs(crumb.transform.position.x - transform.position.x) > farthestCrumbDist)
                {
                    farthestCrumbDist = Mathf.Abs(crumb.transform.position.x - transform.position.x);
                    farthestCrumb = crumb;
                }
            }
        }

        //Debug.Log("Farthest crumb is "+farthestCrumbDist);

        if (farthestCrumb != null)
        {
            SetGeneration();
        }
        else
        {
            //Debug.Log("Null set for farthest crumb.");
        }

    }

    void SetGeneration()
    {
        //Sets Layers and starts neighbors
        foreach (GameObject crumb in crumbs)
        {
            Crumb_Manager cm = crumb.GetComponent<Crumb_Manager>();
            SpriteRenderer sr = crumb.GetComponent<SpriteRenderer>();
            if (cm.isAir == false)
            {

                //Layers
                for (int k = 0; k < layers.Count; k++)
                {
                    if (cm.dist / cm.indexheight < layers[k].maxHeight && cm.dist / cm.indexheight >= layers[k].minHeight && cm.isWater == false && cm.isSurface == false)
                    {
                        cm.layer = layers[k].layer;
                        sr.sprite = layers[k].layerSprite;
                        cm.hardness = layers[k].hardness;
                        cm.smoothingObjColor = layers[k].smoothingColor;
                        float blendHeight = (((layers[k].maxHeight - layers[k].minHeight) * 100) * layers[k].blendPercentage);
                        float maxBlend = cm.indexheight - blendHeight;
                        if (cm.dist > maxBlend && layers[k].blendPercentage != 0)
                        {
                            if ((cm.dist - maxBlend) / blendHeight > Random.value)
                            {
                                sr.sprite = layers[k + 1].layerSprite;
                                cm.hardness = layers[k + 1].hardness;
                                cm.smoothingObjColor = layers[k + 1].smoothingColor;

                            }
                        }
                        cm.SetBackgroundSprite(sr.sprite);

                    }
                    if (cm.isSurface == true && cm.isWater == false)
                    {
                        cm.layer = -1;
                    }
                }


                //Ore setting
                if (cm.isSurface == false && cm.isWater == false && ores.Count != 0)
                {
                    if (Random.value < oreSpawnRate)
                    {
                        int oreIndex = gm.GetRandomWeightedReturn(oreRarities);
                        //Debug.Log("Chosen ore: "+ ores[oreIndex].oName);
                        cm.ore = ores[oreIndex];
                    }
                }

                //Sets neighbor checking
                StartCoroutine(cm.GetNeighbors());
            }
            Vector2Int key = new Vector2Int(
                Mathf.RoundToInt(crumb.transform.position.x * 2f),
                Mathf.RoundToInt(crumb.transform.position.y * 2f)
            );
            crumbMap[key] = crumb;
            StartCoroutine(cm.FindChunk());
            if (cm.isSurfaceWater || cm.isSurface)
            {
                cm.InitSetLighting();
            }
        }
        //Caves
        for (int j = 0; j < caveAmount; j++)
        {
            int caveStart = Random.Range(0, crumbs.Count);
            float caveLength = Random.Range(currentCave.minLength, currentCave.maxLength);
            spawned = Instantiate(currentCave.caveDigger, crumbs[caveStart].transform.position, Quaternion.Euler(0f, 0f, Random.Range(0, 360)));

            for (int i = 0; i < caveLength; i++)
            {
                float caveWidth = Random.Range(currentCave.widthMin, currentCave.widthMax);


                Collider2D[] hits = Physics2D.OverlapCircleAll(spawned.transform.position, caveWidth);

                foreach (Collider2D hit in hits)
                {
                    if (hit.GetComponent<Crumb_Manager>() != null)
                    {
                        Crumb_Manager cm = hit.GetComponent<Crumb_Manager>();
                        SpriteRenderer sr = hit.GetComponent<SpriteRenderer>();

                        if (cm.isAir == false && cm.isRoot == false)
                        {
                            if (Vector2.Distance(hit.transform.position, spawned.transform.position) < caveWidth -1
                                && cm.isRoot == false && cm.isCoreCrumb == false
                                && cm.layer != 0)
                            {
                                cm.SetAir();
                            }
                            if (Vector2.Distance(hit.transform.position, spawned.transform.position) < caveWidth && cm.isAir == false)
                            {
                                cm.SetCave();
                            }
                        }
                    }
                }

                spawned.transform.position += spawned.transform.right * currentCave.caveMoveAmount;

                if (currentCave.dirChangeChance > Random.value)
                {
                    spawned.transform.eulerAngles += new Vector3(0, 0, Random.Range(-currentCave.dirChangeAmount, currentCave.dirChangeAmount));
                    //Debug.Log("changed direction " + spawned.transform.rotation.z);
                }
            }
            Destroy(spawned);
            //Debug.Log("Done With Cave Gen...");
        }
        //Debug.Log("Done setting generation...");

        StartCoroutine(DecorationSpawns());
        StartCoroutine(EnableInitialObjects());
    }

    IEnumerator DecorationSpawns()
    {
        yield return new WaitForSeconds(2);

        foreach (GameObject crumb in surfaceCrumbs)
        {
            
            if (crumb != null)
            {
                Crumb_Manager cm = crumb.GetComponent<Crumb_Manager>();
                float randVal = Random.value;
                if (randVal < surfaceDecorChance && cm.isAir == false && cm.isFurthestExposed == true && cm.isWater == false)
                {
                    //Debug.Log("Instantiateing Tree!");

                    bool found = false;
                    while (found == false)
                    {
                        int indexRand = Random.Range(0, surfaceDecor.Count);

                        if (Random.value < surfaceDecor[indexRand].rarity)
                        {
                            yield return null;
                            //Debug.Log("Instantiateing Tree!");
                            spawned = Instantiate(surfaceDecor[indexRand].decorObj, crumb.transform.position, Quaternion.identity);
                            SetOrientation(spawned);

                            bool found2 = false;
                            foreach (var x in surfaceDecorObjs)
                            {
                                if ((Vector2.Distance(x.pos+x.decorCenter, spawned.transform.localPosition + surfaceDecor[indexRand].decorCenter) < surfaceDecor[indexRand].isolationRadius) || (Vector2.Distance(x.pos + x.decorCenter, spawned.transform.localPosition + surfaceDecor[indexRand].decorCenter) < x.isolationRadius))
                                {
                                    Destroy(spawned);
                                    found2 = true;
                                    //Debug.Log("too close");
                                    break;
                                }
                            }

                            if (found2 == false)
                            {
                                DecorationSettings d = new DecorationSettings
                                {
                                    dName = "Tree",
                                    decorObj = null,
                                    isSurface = true,
                                    isCave = false,
                                    isWater = false,
                                    isGroup = false,
                                    rarity = surfaceDecor[indexRand].rarity,
                                    isolationRadius = surfaceDecor[indexRand].isolationRadius,
                                    decorCenter = surfaceDecor[indexRand].decorCenter,
                                    pos = spawned.transform.position
                                };

                                surfaceDecorObjs.Add(d);
                            }
                            spawned.transform.SetParent(decorHolder.transform);
                            found = true;
                            break;
                        }
                    }
                }
                else
                {
                    //Debug.Log(randVal+" isAir: "+cm.isAir+" isExposed: "+cm.isFurthestExposed + " Water: "+cm.isWater);
                }
            }
        }
        //Debug.Log("Done with decoration...");
    }


    void InitializeChunks()
    {
        GameObject chunkSpawned;
        GameObject chunkSpawned1;

        Vector2 chunkGrid = new Vector2((planetMaxRadius*3)/(int)chunk.GetComponent<SpriteRenderer>().bounds.size.x, (int)(planetMaxRadius * 3) / (int)chunk.GetComponent<SpriteRenderer>().bounds.size.y);
        Vector3 startOffset = new Vector3(transform.position.x - (chunkGrid.x* (int)chunk.GetComponent<SpriteRenderer>().bounds.size.x)/2+ (int)chunk.GetComponent<SpriteRenderer>().bounds.size.x/2, transform.position.y - (chunkGrid.y * (int)chunk.GetComponent<SpriteRenderer>().bounds.size.y) / 2 + (int)chunk.GetComponent<SpriteRenderer>().bounds.size.x / 2, 0);
        //Debug.Log(startOffset);
        for (int i = 0; i < chunkGrid.x; i++)
        {
            chunkSpawned = Instantiate(chunk,startOffset,Quaternion.identity);
            chunkSpawned.transform.SetParent(chunkHolder.transform);

            chunks.Add(chunkSpawned);
            chunkSpawned.transform.position += new Vector3(i * (int)chunk.GetComponent<SpriteRenderer>().bounds.size.x, 0, 0);
            for (int j = 1; j < chunkGrid.y; j++)
            {
                chunkSpawned1 = Instantiate(chunk, chunkSpawned.transform.position, Quaternion.identity);
                chunkSpawned1.transform.SetParent(chunkHolder.transform);

                chunks.Add(chunkSpawned1);
                chunkSpawned1.transform.position += new Vector3(0, j * (int)chunk.GetComponent<SpriteRenderer>().bounds.size.y, 0);
            }

        }
    }


    public void SetOrientation(GameObject obj)
    {
        Vector2 directionToPlanet = transform.position - obj.transform.position;
        float angle = Mathf.Atan2(directionToPlanet.y, directionToPlanet.x) * Mathf.Rad2Deg - 90f+180;
        Quaternion targetRotation = Quaternion.Euler(0, 0, angle);
        obj.transform.rotation = targetRotation;
    }

    public void Gravity()
    {
        if (dynamicGrav == true)
        {
            foreach (GameObject obj in gravityAffectedObjs)
            {
                Rigidbody2D rb = obj.GetComponent<Rigidbody2D>();
                Vector2 objPos = obj.transform.position;
                Vector2 diff = ((Vector2)transform.position - objPos).normalized;

                float curDist = ((Vector2)transform.position - objPos).sqrMagnitude;
                float curGrav = gravityMax / (curDist * gravityDropOff);

                rb.AddForce(diff * curGrav);
                //Debug.Log(curGrav);
            }
        }
        else
        {
            foreach (GameObject obj in gravityAffectedObjs)
            {
                Rigidbody2D rb = obj.GetComponent<Rigidbody2D>();

                if (rb != null)
                {
                    Vector2 objPos = obj.transform.position;
                    Vector2 diff = -(rb.position - (Vector2)transform.position).normalized;
                    float waterForce = 1;
                    float waterBouancy = 1;
                    Object_Manager om = obj.GetComponent<Object_Manager>();
                    if (om != null)
                    {
                        if (om.noGravity == false)
                        {
                            if (om.inWater)
                            {
                                if (om.waterBouancy < 0)
                                {
                                    waterBouancy = om.waterBouancy;

                                }
                                waterForce = om.waterGravity;
                                if (obj.GetComponent<Player_Manager>() == null)
                                {
                                    rb.angularDamping = .9f;
                                }
                                rb.linearDamping = waterForce;
                            }
                            else
                            {
                                rb.angularDamping = .05f;

                                rb.linearDamping = 0;
                            }
                            rb.AddForce(diff * gravityMax * waterBouancy);
                            if (obj.CompareTag("Item"))
                            {
                                if ((player.transform.position - obj.transform.position).sqrMagnitude < pm.itemSuckDistance)
                                {
                                    Vector2 playerDir = (player.transform.position - obj.transform.position).normalized;
                                    rb.AddForce(playerDir * pm.itemSuckForce);
                                }
                            }
                        }
                    }
                    else
                    {
                        rb.angularDamping = .05f;

                        rb.linearDamping = 0;

                        rb.AddForce(diff * gravityMax * waterBouancy);
                    }
                }

            }
        }
    }

    public IEnumerator CoreBroken()
    {
        if (activeCoreCrumbs == 0)
        {
            //Debug.Log("Core Broken!!!");

            foreach (GameObject crumb in crumbs)
            {
                yield return new WaitForSeconds(corruptionSpeed);

                SpriteRenderer csr = crumb.GetComponent<SpriteRenderer>();
                Crumb_Manager cm = crumb.GetComponent<Crumb_Manager>();
                cm.isCorrupted = true;

                if (cm.isWater)
                {
                    //Debug.Log("Evaported Crumb!!!");

                    cm.isCorrupted = true;
                    cm.DestroyCrumb();

                }
                else if (cm.isAir == false)
                {
                    if (Random.value < corruptionChance)
                    {
                        if (Random.value < destructionChance)
                        {
                            cm.DestroyCrumb();
                            Debug.Log("Destroyed Crumb!!!");
                        }
                        else
                        {
                            csr.sprite = corruptionSprite;
                            cm.SetBackgroundSprite(corruptionSprite);

                            Debug.Log("Corrupted Crumb!!!");

                        }
                    }
                }
            }
            Debug.Log("Planet fully corrupted!!!");
            isCorrupted = true;
        }
    }

    IEnumerator EnableInitialObjects()
    {
        yield return new WaitForSeconds(2);
        SetPlanetType();
        foreach (GameObject obj in targetObjs)
        {
            obj.SetActive(true);
        }
        Debug.Log("Done Generating Planet!");
        isDoneMainPlanet = true;
        //Debug.Log("Done enabling initial objects.");
    }
    public void SetPlanetType()
    {
        waterToSolidRatio = (float)waterCrumbs.Count / (crumbs.Count-airCrumbs.Count-waterCrumbs.Count);
        if (waterToSolidRatio > 1)
        {
            planetType = "Water World";
        } 
        else if (waterToSolidRatio < .3f)
        {
            planetType = "Arid";
        }
        else if (waterToSolidRatio == 0)
        {
            planetType = "Barren";
        }
        else
        {
            planetType = "Forest";
        }
    }
    public void DeactivatePlanet()
    {
        foreach (GameObject obj in planetConnectedObjects)
        {
            if (obj.activeInHierarchy == true)
            {
                obj.SetActive(false);
            }
        }
    }

    /*
    void ActivatePlanet()
    {
        foreach (GameObject obj in planetConnectedObjects)
        {
            if (obj.activeInHierarchy == false)
            {
                obj.SetActive(true);
            }
        }
    }
    */
    public void SpawnNPCs()
    {

        StartCoroutine(sm.StartSpawning());
    }
    private void OnEnable()
    {
        if (enableCount > 0)
        {
            SpawnNPCs();
        }
        enableCount += 1;
    }
}
