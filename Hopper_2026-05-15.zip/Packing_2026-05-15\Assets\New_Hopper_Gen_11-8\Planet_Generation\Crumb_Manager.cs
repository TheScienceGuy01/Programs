﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;

public class Crumb_Manager : MonoBehaviour
{
    [Header("Gameobject Variables")]
    public GameObject gameManager;
    public GameObject manager;
    public GameObject stemCrumb;
    public GameObject crumb;
    private GameObject spawned;
    public GameObject chunk;
    public GameObject testWaterFlow;
    public GameObject spawnedTest;
    public GameObject smoothingObj;
    public GameObject breakingObj;
    public GameObject backgroundObj;
    public GameObject crumbHolder;

    [Header("State Variables")]
    public bool isSurfaceWater;
    public bool isSurface;
    public bool isWater;
    public bool isCave;
    public bool isAir;
    public bool isOre;
    public bool isStem;
    public bool canMine;
    public bool isCoreCrumb;
    public bool isCorrupted;
    public bool isMining;
    public bool isRoot;
    public bool isFurthestExposed;
    public bool isClosestExposed;
    public bool waterOn;
    public bool threwDist;
    public bool threwDict;
    public bool isExposed;
    public bool watercanMove;
    public bool hasWaterfallingPotential;
    public bool calledWater;

    [Header("Numerical Variables")]
    public int radius;
    public int index;
    public float dist;
    public float indexheight;
    public float waterdisthuh;
    public int layer;
    public float hardness;
    public float waterStartDist;

    [Header("List and Settings Variables")]
    public List<GameObject> neighbors = new List<GameObject>();
    public List<GameObject> smoothingObjs = new List<GameObject>();
    public Vector2[] sensorCoords;
    public List<int> neighborPos = new List<int>();
    public List<float> neighborRot = new List<float>();
    public Vector2 chosenWater;
    public Vector2 removedVector;
    public List<float> waterDistVectors = new List<float>();
    public List<Vector2> openNeighborPos = new List<Vector2>();
    public Vector2 closestVector;
    public Vector2 furthestVector;
    public Sprite[] miningSprites;
    public Color smoothingObjColor;
    public OreSettings ore;
    public Sprite waterLoggedSprite;


    [Header("Lighting")]
    public int lightSources;
    public float currentDarkness;
    public float defaultDarkness;
    public GameObject lightingObj;
    public float surfaceLightSpread;
    public LayerMask crumbMask;
    public float backgroundDarkness;    

    [Header("Testing")]
    public bool waterSetVia1;
    public bool waterSetVia2;

    Game_Manager gameM;
    private Generation_Manager gm;
    SpriteRenderer sp;


    private void Start()
    {
        StartCoroutine(StartSpawning());
    }
    IEnumerator StartSpawning()
    {
        transform.SetParent(crumbHolder.transform);
        gameM = gameManager.GetComponent<Game_Manager>();
        if (isRoot == false)
        {
            backgroundObj = transform.GetChild(1).gameObject;
            breakingObj = transform.GetChild(0).gameObject;
            //Debug.Log($"Crumb_Manager Start() running on thread: {System.Threading.Thread.CurrentThread.ManagedThreadId}");
            dist = Vector2.Distance(transform.position, manager.transform.position);
            gm = manager.GetComponent<Generation_Manager>();
            sp = GetComponent<SpriteRenderer>();
            //sp.color = new Color(currentLighting.x,currentLighting.y,currentLighting.y,1f);
            if (isStem)
            {
                yield return null;
                int newIndex = 0;
                if (index < radius)
                {
                    SpawnCrumbs(sensorCoords[0], stemCrumb);
                    Crumb_Manager cm = spawned.GetComponent<Crumb_Manager>();
                    cm.index = index + 1;
                    newIndex = cm.index;
                }
                else
                {
                    newIndex = radius + 1;
                }

                if (index > 1)
                {
                    SpawnCrumbs(sensorCoords[2], crumb);
                    Crumb_Manager cm1 = spawned.GetComponent<Crumb_Manager>();
                    cm1.index = newIndex - 2;
                }
            }
            else if (index > 1)
            {
                yield return null;
                index -= 1;
                Vector2 spawnPos = transform.TransformPoint(sensorCoords[2]);
                isCoreCrumb = false;
                Instantiate(gameObject, spawnPos, transform.rotation);
                //Debug.Log("crumb spawning crumb");
            }
            if (dist > gm.planetCutOffRadius)
            {
                Destroy(gameObject);
                if (isAir)
                {
                    //Debug.Log("air Obj destroyed");
                }
                yield break;
            }
            else
            {
                gm.crumbs.Add(gameObject);

            }

            //===========ONLY CONTININUES OF THE OBJECT IS NOT DESTROYED=======================================

            if (isStem && gm.lastStem == null)
            {
                gm.lastStem = gameObject;
                //Debug.Log("last crumb set");
            }
            GetAngle();
        }
    }

    void GetAngle()
    {
        Vector2 dir = transform.position - manager.transform.position;
        int numAngles = 360; // 1° per step
        float angle = Mathf.Atan2(dir.y, dir.x); // -π to π
        float normalized = (angle + Mathf.PI) / (2f * Mathf.PI); // 0..1
        int index = Mathf.RoundToInt(normalized * numAngles) % numAngles;
        indexheight = gm.carveDistance[index];
        if (gm.carveDistance[index] < dist)
        {
            if (dist > gm.seaLevel)
            {
                Destroy(gameObject);
            }
            else
            {
                SetWater();
            }
        }
        if (gm.carveDistance[index] - 2f < dist && isWater == false)
        {
            SetSurface();
        }
        if (gm.carveDistance[index] - 2f < dist && isWater == true)
        {
            isSurfaceWater = true ;
        }
    }
    void SpawnCrumbs(Vector2 child, GameObject crumbToSpawn)
    {
        Vector2 spawnPos = transform.TransformPoint(child);
        //Debug.Log("still_Spawning");
        spawned = Instantiate(crumbToSpawn, spawnPos, transform.rotation);

        Crumb_Manager cm = spawned.GetComponent<Crumb_Manager>();
        cm.radius = radius;
        cm.enabled = true;
        cm.isSurface = isSurface;
        cm.isCoreCrumb = false;
    }
    public void SetChunk(GameObject chunkObj)
    {
        chunk = chunkObj;
        transform.SetParent(chunk.transform);
    }

    public void SetSurface()
    {
        isSurface = true;
        gm.surfaceCrumbs.Add(gameObject);
        SetBackgroundSprite(gm.surfaceSprite);

    }
    public void SetWater()
    {
        if (!gm.waterCrumbs.Find(item => item.gameObject == gameObject))
        {
            gm.waterCrumbs.Add(gameObject);
        }
        if (gm.airCrumbs.Find(item => item.gameObject == gameObject))
        {
            gm.airCrumbs.Remove(gameObject);
        }
        isWater = true;
        isSurface = false;
        sp.sprite = gm.waterSprite;
        if (isAir == false)
        {
            sp.enabled = true;

            sp.sortingOrder = 1;
        }
        if (GetComponent<Collider2D>() != null)
        {
            Collider2D[] cols = GetComponents<Collider2D>();

            foreach (Collider2D col in cols)
            {
                if (col.isTrigger == false)
                {
                    Destroy(col);
                }
            }
        }
        if (GetComponent<PolygonCollider2D>() == null)
        {
            Collider2D pc = gameObject.AddComponent<PolygonCollider2D>();
            pc.isTrigger = true;
        }
    }
    public void SetCave()
    {
        isCave = true;
        //GetComponent<SpriteRenderer>().color = Color.lightGray;
    }
    public void SetAir()
    {
        isAir = true;
        sp.enabled = false;
        sp.sortingOrder = -1;

        if (!gm.airCrumbs.Find(item => item.gameObject == gameObject))
        {
            gm.airCrumbs.Add(gameObject);
        }
        if (gm.waterCrumbs.Find(item => item.gameObject == gameObject))
        {
            gm.waterCrumbs.Remove(gameObject);
        }
        if (GetComponent<Collider2D>() != null)
        {
            Collider2D[] cols = GetComponents<Collider2D>();

            foreach (Collider2D col in cols)
            {
                if (col.isTrigger == false)
                {
                    Destroy(col);
                }
            }
        }
    }
    public IEnumerator GetNeighbors()
    {
        openNeighborPos.Clear();
        neighbors.Clear();
        yield return new WaitForSeconds(.5f);
        for (int i = 0; i < sensorCoords.Length; i++)
        {
            Vector2 spawnPos = transform.TransformPoint(sensorCoords[i]);

            Vector2Int childPos = new Vector2Int(
                Mathf.RoundToInt(spawnPos.x * 2f),
                Mathf.RoundToInt(spawnPos.y * 2f)
            );

            if (gm.crumbMap.TryGetValue(childPos, out GameObject foundCrumb))
            {
                if (foundCrumb.GetComponent<Crumb_Manager>().isAir == false)
                {
                    neighbors.Add(foundCrumb);
                }
                else
                {
                    openNeighborPos.Add(sensorCoords[i]);

                }
            }
            else
            {
                openNeighborPos.Add(sensorCoords[i]);
            }
        }
        //Debug.Log("Is Exposed!");
        SetClosestFurthest();
        if (neighbors.Count != 6)
        {
            isExposed = true;
        }

        if (ore.oName != "")
        {
            StartCoroutine(SetOre());
        }
        yield return null;
        if (isExposed == false && isSurface)
        {
            gm.surfaceCrumbs.Remove(gameObject);
            isSurface = false;
            layer = gm.layers[gm.layers.Count - 1].layer;
            hardness = gm.layers[gm.layers.Count - 1].hardness;
            //Debug.Log("removed false surface crumbs");
            sp.sprite = gm.layers[gm.layers.Count-1].layerSprite;
        }
        if (isSurface)
        {
            sp.sprite = gm.surfaceSprite;
        }

        SetSmoothing();
        //StartCoroutine(SetLighting());
        if (isSurface && isExposed == false)
        {
            isSurface = false;
        }
    }
    public void GetNeighborsInstant()
    {
        openNeighborPos.Clear();
        neighbors.Clear();
        for (int i = 0; i < sensorCoords.Length; i++)
        {
            Vector2 spawnPos = transform.TransformPoint(sensorCoords[i]);

            Vector2Int childPos = new Vector2Int(
                Mathf.RoundToInt(spawnPos.x * 2f),
                Mathf.RoundToInt(spawnPos.y * 2f)
            );

            if (gm.crumbMap.TryGetValue(childPos, out GameObject foundCrumb))
            {
                if (foundCrumb.GetComponent<Crumb_Manager>().isAir == false)
                {
                    neighbors.Add(foundCrumb);
                }
                else
                {
                    openNeighborPos.Add(sensorCoords[i]);

                }
            }
            else
            {
                openNeighborPos.Add(sensorCoords[i]);
            }
        }
        //Debug.Log("Is Exposed!");

        if (neighbors.Count != 6)
        {
            isExposed = true;

        }
        SetClosestFurthest();
        //StartCoroutine(SetLighting());
        if (isSurface && isExposed == false)
        {
            isSurface = false;
        }
    }

    public void SetSmoothing()
    {
        if (isWater == false)
        {
            if (smoothingObjs.Count != 0)
            {
                foreach (GameObject x in smoothingObjs)
                {
                    Destroy(x);
                }
                smoothingObjs.Clear();
            }
            if (isAir == false)
            {
                for (int i = 0; i < sensorCoords.Length; i++)
                {
                    if (openNeighborPos.Contains(sensorCoords[i]))
                    {
                        // ex found that 4th is the empty one. so now 5 and 1 need to be checked.
                        //Debug.Log(neighborPos[i]);
                        if (neighborPos.IndexOf(i) != 0 && neighborPos.IndexOf(i) != neighborPos.Count - 1)
                        {
                            if (!openNeighborPos.Contains(sensorCoords[i + 1]) && smoothingObjColor != Color.black)
                            {
                                float rot = neighborRot[i];
                                rot = (rot % 360 + 360) % 360;
                                //Debug.Log(neighborRot[neighborPos[i]]);
                                spawned = Instantiate(smoothingObj, transform.position, Quaternion.identity, transform.parent);
                                spawned.transform.SetParent(transform, true); // makes it world space
                                spawned.transform.localRotation = Quaternion.Euler(0, 180, rot);
                                spawned.transform.localRotation = Quaternion.Euler(spawned.transform.localRotation.x, spawned.transform.localRotation.y + 180, -rot);
                                spawned.transform.localScale = new Vector3(1, 1, 1);
                                spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = smoothingObjColor;
                                spawned.transform.GetChild(1).GetComponent<SpriteRenderer>().color = new Color(0,0,0,defaultDarkness);
                                smoothingObjs.Add(spawned);
                                if (isSurface)
                                {
                                    spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = gm.surfaceSmoothingColor;
                                }
                            }
                            if (!openNeighborPos.Contains(sensorCoords[i - 1]) && smoothingObjColor != Color.black)
                            {
                                float rot = neighborRot[i];
                                rot = (rot % 360 + 360) % 360;
                                //Debug.Log(rot);
                                spawned = Instantiate(smoothingObj, transform.position, Quaternion.identity, transform.parent);
                                spawned.transform.SetParent(transform, true); // makes it world space
                                spawned.transform.localRotation = Quaternion.Euler(0, 0, rot);
                                spawned.transform.localScale = new Vector3(1, 1, 1);
                                spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = smoothingObjColor;
                                spawned.transform.GetChild(1).GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, defaultDarkness);

                                if (isSurface)
                                {
                                    spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = gm.surfaceSmoothingColor;
                                }
                                smoothingObjs.Add(spawned);
                            }
                        }
                        else if (neighborPos[i] == 0)
                        {
                            if (!openNeighborPos.Contains(sensorCoords[i + 1]) && smoothingObjColor != Color.black)
                            {
                                float rot = neighborRot[i];
                                rot = (rot % 360 + 360) % 360;
                                //Debug.Log(neighborRot[neighborPos[i]]);
                                spawned = Instantiate(smoothingObj, transform.position, Quaternion.identity, transform.parent);
                                spawned.transform.SetParent(transform, true); // makes it world space
                                spawned.transform.localRotation = Quaternion.Euler(0, 180, rot);
                                spawned.transform.localRotation = Quaternion.Euler(spawned.transform.localRotation.x, spawned.transform.localRotation.y + 180, -rot);
                                spawned.transform.localScale = new Vector3(1, 1, 1);
                                spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = smoothingObjColor;
                                spawned.transform.GetChild(1).GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, defaultDarkness);

                                if (isSurface)
                                {
                                    spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = gm.surfaceSmoothingColor;
                                }
                                smoothingObjs.Add(spawned);
                            }
                            if (!openNeighborPos.Contains(sensorCoords[5]) && smoothingObjColor != Color.black)
                            {
                                float rot = neighborRot[i];
                                rot = (rot % 360 + 360) % 360;
                                //Debug.Log(rot);
                                spawned = Instantiate(smoothingObj, transform.position, Quaternion.identity, transform.parent);
                                spawned.transform.SetParent(transform, true); // makes it world space
                                spawned.transform.localRotation = Quaternion.Euler(0, 0, rot);
                                spawned.transform.localScale = new Vector3(1, 1, 1);
                                spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = smoothingObjColor;
                                spawned.transform.GetChild(1).GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, defaultDarkness);

                                if (isSurface)
                                {
                                    spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = gm.surfaceSmoothingColor;
                                }
                                smoothingObjs.Add(spawned);
                            }
                        }
                        else if (neighborPos[i] == 5)
                        {
                            if (!openNeighborPos.Contains(sensorCoords[0]) && smoothingObjColor != Color.black)
                            {
                                float rot = neighborRot[i];

                                rot = (rot % 360 + 360) % 360;
                                //Debug.Log(neighborRot[neighborPos[i]]);
                                spawned = Instantiate(smoothingObj, transform.position, Quaternion.identity, transform.parent);
                                spawned.transform.SetParent(transform, true); // makes it world space
                                spawned.transform.localRotation = Quaternion.Euler(0, 180, rot);
                                spawned.transform.localRotation = Quaternion.Euler(spawned.transform.localRotation.x, spawned.transform.localRotation.y + 180, -rot);
                                spawned.transform.localScale = new Vector3(1, 1, 1);
                                spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = smoothingObjColor;
                                spawned.transform.GetChild(1).GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, defaultDarkness);

                                if (isSurface)
                                {
                                    spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = gm.surfaceSmoothingColor;
                                }
                                smoothingObjs.Add(spawned);
                            }
                            if (!openNeighborPos.Contains(sensorCoords[i - 1]) && smoothingObjColor != Color.black)
                            {
                                float rot = neighborRot[i];
                                rot = (rot % 360 + 360) % 360;
                                //Debug.Log(rot);
                                spawned = Instantiate(smoothingObj, transform.position, Quaternion.identity, transform.parent);
                                spawned.transform.SetParent(transform, true); // makes it world space
                                spawned.transform.localRotation = Quaternion.Euler(0, 0, rot);
                                spawned.transform.localScale = new Vector3(1, 1, 1);
                                spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = smoothingObjColor;
                                spawned.transform.GetChild(1).GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, defaultDarkness);

                                if (isSurface)
                                {
                                    spawned.transform.GetChild(0).GetComponent<SpriteRenderer>().color = gm.surfaceSmoothingColor;
                                }
                                smoothingObjs.Add(spawned);
                            }
                        }
                    }
                }
            }
        }
    }
    /*
    public IEnumerator StartWater()
    {
        //spawnedTest = Instantiate(testWaterFlow, transform.position, transform.rotation);
        //Debug.Log("water called!");
        if (isWater && isCorrupted == false && isExposed)
        {
            //(gm.player.transform.position - transform.position).sqrMagnitude < waterStartDist * waterStartDist
            if (calledWater)
            {
                waterOn = true;
                yield return null;
                foreach (GameObject surfaceNeighbor in neighbors)
                {
                    if (Vector2.Distance(surfaceNeighbor.transform.position, manager.transform.position) < Vector2.Distance(transform.position, manager.transform.position) && surfaceNeighbor.GetComponent<Crumb_Manager>().isSurface)
                    {
                        //Debug.Log("SHould be changing grass to red!!!!");
                        surfaceNeighbor.GetComponent<Crumb_Manager>().isSurface = false;
                        surfaceNeighbor.GetComponent<SpriteRenderer>().sprite = waterLoggedSprite;
                        gm.surfaceCrumbs.Remove(surfaceNeighbor);
                    }
                }
                if (isExposed)
                {

                    watercanMove = true;
                    yield return new WaitForSeconds(.01f);
                    threwDict = false;
                    threwDist = false;
                    float closestDist = -1;
                    Vector2 closest = new Vector2(0, 0);
                    GetNeighborsInstant();
                    waterDistVectors.Clear();

                    for (int j = 0; j < openNeighborPos.Count; j++)
                    {
                        Vector2 pos = openNeighborPos[j];
                        yield return null;

                        Vector2 spawnPos1 = transform.TransformPoint(pos);
                        Vector2Int childPos1 = new Vector2Int(
                            Mathf.RoundToInt(spawnPos1.x * 2f),
                            Mathf.RoundToInt(spawnPos1.y * 2f)
                        );
                        if (Vector2.Distance(spawnPos1, manager.transform.position) < Vector2.Distance(transform.position, manager.transform.position) && gm.crumbMap.TryGetValue(childPos1, out GameObject foundCrumb))
                        {
                            if (closestDist == -1)
                            {
                                closest = pos;
                                closestDist = Vector2.Distance(spawnPos1, manager.transform.position);

                            }
                            else if (Vector2.Distance(spawnPos1, manager.transform.position) < closestDist)
                            {
                                closestDist = Vector2.Distance(spawnPos1, manager.transform.position);
                                closest = pos;
                            }
                        }
                        waterDistVectors.Add(closestDist);
                    }
                    Vector2 spawnPos = transform.TransformPoint(closest);
                    Vector2Int childPos = new Vector2Int(
                        Mathf.RoundToInt(spawnPos.x * 2f),
                        Mathf.RoundToInt(spawnPos.y * 2f)
                    ); chosenWater = closest;
                    waterdisthuh = closestDist;
                    if (closestDist != -1)
                    {
                        threwDist = true;
                        if (gm.crumbMap.TryGetValue(childPos, out GameObject foundCrumb))
                        {
                            threwDict = true;
                            if (foundCrumb.GetComponent<Crumb_Manager>().isAir == true && foundCrumb.GetComponent<Crumb_Manager>().isCorrupted == false)
                            {
                                //spawnedTest.GetComponent<SpriteRenderer>().color = Color.lightGreen;
                                //spawnedTest.transform.position = spawnPos;

                                gm.crumbMap[childPos].GetComponent<Crumb_Manager>().isAir = false;
                                gm.crumbMap[childPos].GetComponent<Crumb_Manager>().SetWater();

                                SetAir();
                                isWater = false;
                                gm.crumbMap[childPos].GetComponent<Crumb_Manager>().GetNeighborsInstant();

                                //StartCoroutine(gm.crumbMap[childPos].GetComponent<Crumb_Manager>().StartWater());
                                for (int i = 0; i < neighbors.Count; i++)
                                {
                                    if (neighbors[i] != null)
                                    {
                                        GameObject neighbor = neighbors[i];

                                        StartCoroutine(neighbor.GetComponent<Crumb_Manager>().GetNeighbors());
                                        yield return new WaitForSeconds(.6f);
                                        StartCoroutine(neighbor.GetComponent<Crumb_Manager>().StartWater());
                                    }
                                }
                            }
                            else if (foundCrumb.GetComponent<Crumb_Manager>().isCorrupted == true)
                            {
                                DestroyCrumb();
                                SetAir();
                                isWater = false;
                            }

                        }
                    }
                }
                else
                {
                    yield return null;
                    GetNeighborsInstant();
                }
            }
            else
            {
                yield return new WaitForSeconds(1);
            }
        }
        waterOn = false;
        if (GetComponent<Collider2D>() != null && isAir)
        {
            Collider2D[] cols = GetComponents<Collider2D>();

            foreach (Collider2D col in cols)
            {
                Destroy(col);
            }
        }
    }
    */
    IEnumerator SetOre()
    {
        if (ore.layer == layer && isAir == false && isWater == false)
        {

            GetComponent<SpriteRenderer>().sprite = ore.oreSprite;
            SetBackgroundSprite(ore.oreSprite);
            isOre = true;
            hardness = ore.hardness;

            for (int i = 0; i < neighbors.Count; i++) 
            {
                GameObject neighbor = neighbors[i];
                yield return null;
                if (Random.value < ore.spreadChance && neighbor.GetComponent<Crumb_Manager>().isAir == false && neighbor.GetComponent<Crumb_Manager>().isWater == false)
                {
                    //Debug.Log("should be spreading");
                    neighbor.GetComponent<Crumb_Manager>().ore = ore;
                    neighbor.GetComponent<Crumb_Manager>().DecreaseOre();
                    StartCoroutine(neighbor.GetComponent<Crumb_Manager>().SetOre());
                }
            }
        }
        else
        {
            //Debug.Log("wrong color");
        }
    }

    void DecreaseOre()
    {
        ore.spreadChance /= ore.spreadRate;
    }

    void SetClosestFurthest()
    {
        Vector2 clostestV = new Vector2(0,0);
        float closestDist = 999999;
        Vector2 furthestV = new Vector2(0, 0);
        float furthestDist = -1;
        isClosestExposed = false;
        isFurthestExposed = false;

        foreach (Vector2 pos in sensorCoords)
        {
            Vector2 spawnPos = transform.TransformPoint(pos);

            if (Vector2.Distance(spawnPos, gm.rootCrumb.transform.position) < closestDist)
            {
                closestDist = Vector2.Distance(spawnPos, gm.rootCrumb.transform.position);
                clostestV = spawnPos;
                closestVector = pos;

            }
        }
        foreach (Vector2 pos in openNeighborPos)
        {
            Vector2 spawnPos = transform.TransformPoint(pos);

            if (spawnPos == clostestV)
            {
                isClosestExposed = true;
                break;
            }
        }

        //

        foreach (Vector2 pos in sensorCoords)
        {
            Vector2 spawnPos = transform.TransformPoint(pos);

            if (Vector2.Distance(spawnPos, gm.rootCrumb.transform.position) > furthestDist)
            {
                furthestDist = Vector2.Distance(spawnPos, gm.rootCrumb.transform.position);
                furthestV = spawnPos;
                furthestVector = pos;

            }
        }
        foreach (Vector2 pos in openNeighborPos)
        {
            Vector2 spawnPos = transform.TransformPoint(pos);

            if (spawnPos == furthestV)
            {
                isFurthestExposed = true;
                break;
            }
        }
    }

    public IEnumerator MineCrumb(float mineSpeed)
    {
        if (canMine)
        {
            for (int i = 0; i < miningSprites.Length; i++)
            {

                if (isMining)
                {
                    breakingObj.GetComponent<SpriteRenderer>().sprite = miningSprites[i];
                }
                else
                {
                    break;
                }
                yield return new WaitForSeconds(mineSpeed * hardness);


            }
            breakingObj.GetComponent<SpriteRenderer>().sprite = null;

            if (isMining)
            {
                DestroyCrumb();
                yield return null;
            }
            if (isCoreCrumb)
            {
                //Debug.Log("Core crumb broken!!!");
                gm.activeCoreCrumbs -= 1;
                gm.coreCrumbs.Remove(gameObject);
                StartCoroutine(gm.CoreBroken());
            }
        }
    }

    public void DestroySmoothing()
    {
        if (smoothingObjs.Count != 0)
        {
            foreach (GameObject x in smoothingObjs)
            {
                Destroy(x);
            }
            smoothingObjs.Clear();
        }
    }

    public void DestroyCrumb()
    {
        gameM.player.GetComponent<Player_Manager>().groundTrigger.GetComponent<Ground_Trigger_v2>().RemoveGoneCrumbsManually(gameObject);
        gameM.player.GetComponent<Player_Manager>().wallTrigger.GetComponent<Ground_Trigger_v2>().RemoveGoneCrumbsManually(gameObject);

        SetAir();
        DestroySmoothing();
        GetNeighborsInstant();
        for (int i = 0; i < neighbors.Count; i++)
        {
            if (neighbors[i] != null)
            {
                GameObject neighbor = neighbors[i];
                neighbor.GetComponent<Crumb_Manager>().GetNeighborsInstant();
            }
        }
        if (isOre)
        {
            gameManager.GetComponent<Item_Drops>().SpawnItem(ore.itemDropID, transform.position, transform.rotation,true);
        }
        gameM.player.GetComponent<Player_Manager>().groundTrigger.GetComponent<Ground_Trigger_v2>().RemoveGoneCrumbsManually(gameObject);
        gameM.player.GetComponent<Player_Manager>().wallTrigger.GetComponent<Ground_Trigger_v2>().RemoveGoneCrumbsManually(gameObject);

        //gm.InstantColliderCheck();
    }
    public void SetBackgroundSprite(Sprite bgSprite)
    {
        SpriteRenderer sr;
        sr = backgroundObj.GetComponent<SpriteRenderer>();
        sr.color = new Color(backgroundDarkness, backgroundDarkness, backgroundDarkness, 1f);
        sr.sprite = bgSprite;

    }
    public IEnumerator FindChunk()
    {
        yield return new WaitForSeconds(1);
        if (gm != null)
        {
            foreach (GameObject chunk in gm.chunks)
            {
                if (chunk != null)
                {
                    if (GetComponent<SpriteRenderer>().bounds.Intersects(chunk.GetComponent<SpriteRenderer>().bounds))
                    {
                        transform.SetParent(chunk.GetComponent<Chunk_Manager>().crumbHolder.transform);
                    }
                }
            }
        }
    }

    public void InitSetLighting()
    {
        if (isSurface)
        {
            defaultDarkness = 0f;
            currentDarkness = defaultDarkness;
            Vector2 directionToPlanet = ((Vector2)manager.transform.position - (Vector2)transform.position).normalized;
            Vector2 boxSize = new Vector2(surfaceLightSpread,1f);
            float angle = Mathf.Atan2(directionToPlanet.y, directionToPlanet.x) * Mathf.Rad2Deg;

            Collider2D[] hits = Physics2D.OverlapBoxAll(
                transform.position, 
                boxSize,
                angle,
                crumbMask);
            /*
            // Draw the box
            Vector3 center = (Vector2)transform.position + directionToPlanet * (surfaceLightSpread / 2f); // move center along the direction
            Quaternion rotation = Quaternion.Euler(0f, 0f, angle);

            Vector3 right = rotation * Vector3.right * (boxSize.x / 2f);
            Vector3 up = rotation * Vector3.up * (boxSize.y / 2f);

            // Draw rectangle edges
            Debug.DrawLine(center - right - up, center + right - up, Color.yellow);
            Debug.DrawLine(center + right - up, center + right + up, Color.yellow);
            Debug.DrawLine(center + right + up, center - right + up, Color.yellow);
            Debug.DrawLine(center - right + up, center - right - up, Color.yellow);
            */

            foreach (Collider2D hit in hits)
            {
                if (hit.gameObject == gameObject || hit.GetComponent<Crumb_Manager>().isSurface == true)
                    continue;
                if (hit.isTrigger == true)
                {
                    Crumb_Manager cm = hit.GetComponent<Crumb_Manager>();
                    float projectedDist = Vector2.Dot((hit.transform.position - transform.position), directionToPlanet);

                    cm.defaultDarkness =Mathf.Clamp01(projectedDist / (surfaceLightSpread/2));
                    cm.currentDarkness = cm.defaultDarkness;

                    cm.InitSetLighting();
                }
            }
        }

        if (lightingObj != null)
        {
            lightingObj.GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, currentDarkness);
            foreach (GameObject sObj in smoothingObjs)
            {
                sObj.transform.GetChild(1).GetComponent<SpriteRenderer>().color = new Color(0,0,0,currentDarkness);
            }
        }
    }
    public void SetLighting()
    {
        if (lightingObj != null)
        {
            lightingObj.GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, currentDarkness);
            foreach (GameObject sObj in smoothingObjs)
            {
                sObj.transform.GetChild(1).GetComponent<SpriteRenderer>().color = new Color(0, 0, 0, currentDarkness);
            }
        }
    }
}
