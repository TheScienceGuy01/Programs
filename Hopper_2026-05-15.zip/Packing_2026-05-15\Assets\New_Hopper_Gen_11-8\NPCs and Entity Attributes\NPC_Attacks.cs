using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class Attacks {
    public string attackName;
    public bool canMoveWhileAttacking;
    public float attackDistance;
    public bool isRanged;
    public AnimationClip animClip;
    public GameObject gunArm;
    public GameObject gun;
    public float armRotOffset;
    public GameObject meleeCollider;
}

public class NPC_Attacks : MonoBehaviour
{
    public int nPCType;
    public Attacks[] meleeAttacks;
    public Attacks[] rangedAttacks;
    public List<Attacks> allAttacks = new List<Attacks>();
    public Attacks attackChosen;
    public Attacks prevAttack;
    public bool chosenAttack;
    public bool pauseAnim;
    public float attackLength;
    public float targetDist;
    public GameObject normalArm;

    NPC_States ns;
    NPC_Manager nm;
    Pathfinding pf;

    void Start()
    {
        ns = GetComponent<NPC_States>();
        nm = GetComponent<NPC_Manager>();
        pf = GetComponent<Pathfinding>();

        foreach (Attacks a in meleeAttacks)
        {
            allAttacks.Add(a);
        }
        foreach (Attacks a in rangedAttacks)
        {
            allAttacks.Add(a);
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (pf.target != null)
        {
            targetDist = (transform.position - pf.target.transform.position).sqrMagnitude;
        }
        if (ns.currentState.name == NPCStateNames.Pursue && chosenAttack == false && pf.isDirectPath)
        {
            switch (nPCType)
            {
                case 0:
                    //Debug.Log("Should be continueing attacks");
                    StartCoroutine(TestingNPCAttacks());
                    break;
            }
        }
        else if (ns.currentState.name != NPCStateNames.Pursue || !pf.isDirectPath)
        {
            if (attackChosen.gunArm != null && normalArm != null)
            {
                attackChosen.gunArm.SetActive(false);
                attackChosen.gun.SetActive(false);
                normalArm.SetActive(true);
            }
        }
        if (chosenAttack)
        {
            if (attackChosen.gunArm != null && pf.target != null)
            {
                Vector3 targetPos = pf.target.transform.position;

                Vector2 dirToTarget = (Vector2)targetPos - (Vector2)transform.position;

                float angle = Mathf.Atan2(dirToTarget.y, dirToTarget.x) * Mathf.Rad2Deg;

                attackChosen.gunArm.transform.rotation = Quaternion.Euler(0f, 0f, angle + 90 + attackChosen.armRotOffset);

                attackChosen.gun.GetComponent<Ranged_Weapons_Manager>().ShootGun();
            }
        }
    }

    IEnumerator TestingNPCAttacks()
    {
        chosenAttack = true;
        bool didChoose = false;

        while (!didChoose)
        {
            yield return null;

            Attacks tempAttack = allAttacks[Random.Range(0, allAttacks.Count)];
            prevAttack = attackChosen;
            if (tempAttack.isRanged)
            {
                if (targetDist > tempAttack.attackDistance)
                {
                    attackChosen = tempAttack;
                    didChoose = true;
                }
            }
            else
            {
                if (targetDist < tempAttack.attackDistance)
                {
                    attackChosen = tempAttack;
                    didChoose = true;
                }
            }
        }

        //Debug.Log("Should have chosen an attack");
        if (attackChosen.animClip)
        {
            if (attackChosen != prevAttack)
            {
                if (prevAttack.gunArm != null)
                {
                    prevAttack.gunArm.SetActive(false);
                    prevAttack.gun.SetActive(false);

                    normalArm.SetActive(true);

                }
            }
            pauseAnim = true;
            attackChosen.meleeCollider.GetComponent<Melee_Triggers>().hasHit = false;
            nm.UpdateAnims(attackChosen.animClip, false);
            yield return new WaitForSeconds(attackChosen.animClip.length);
        }
        else
        {
            if (attackChosen != prevAttack && prevAttack.gunArm != null)
            {
                prevAttack.gunArm.SetActive(false);
                prevAttack.gun.SetActive(false);

            }
            //Debug.Log("ranged!");
            attackChosen.gunArm.SetActive(true);
            attackChosen.gun.SetActive(true);
            if (nm.flipDir == true)
            {
                attackChosen.gun.GetComponent<Ranged_Weapons_Manager>().firePoint.transform.localRotation = Quaternion.Euler(0, 0, 180);

            }
            else
            {
                attackChosen.gun.GetComponent<Ranged_Weapons_Manager>().firePoint.transform.localRotation = Quaternion.Euler(0, 0,0);

            }
            if (normalArm != null)
            {
                normalArm.SetActive(false);

            }
            yield return new WaitForSeconds(attackLength);
        }
        pauseAnim = false;
        chosenAttack = false;
    }
}
