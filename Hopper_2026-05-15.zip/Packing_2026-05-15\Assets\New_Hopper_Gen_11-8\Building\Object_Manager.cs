using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System.Xml;

public class Object_Manager : MonoBehaviour
{
    public BuildingInfo objInfo;
    public bool canPlace;
    public bool canDisconnect;
    public Color invalidColor;
    public Color defaultColor;
    public Color canSnapColor;
    public Color canSnapSensorColor;
    public Color sensorDefault;
    public Color validSelectionColor;
    public bool isSnapped;
    public bool snappedToAnchor;
    public GameObject anchorObj;
    public List<GameObject> snappedObj = new List<GameObject>();
    public List<Transform> nodes = new List<Transform>();
    public int triggerCount;
    SpriteRenderer sr;
    public bool isPlaced;
    public bool isController;
    public bool isTrigger;
    public bool isAnchor;
    public bool isLoose;
    public bool isHinge;
    public GameObject hingeParent;
    public bool hasSecondaryAfterPlace;
    public GameObject secondaryForActive;
    public GameObject gameManager;
    public GameObject secondaryObject;
    Game_Manager gm;
    Building_Manager bm;
    Item_Drops itemD;
    public bool inWater;
    public float waterGravity;
    public float waterBouancy;
    public bool isDrill;
    public bool cannotPickUpObj;
    public bool isWheel;
    public int collisionCount;
    public int rbMass;
    public bool isItem;
    public bool isCraftingCenter;
    public float accessRange;
    public bool isCraftingOn;
    public GameObject player;
    public GameObject menuManager;
    Game_Menu_Manager gmm;
    public Camera mainCam;
    public bool isNPC;
    public bool isPlayer;
    public int waterCrumbs;
    public bool isItemProcessing;
    public bool noGravity;
    public bool isActive;

    Health h;

    private void Start()
    {
        if (GetComponent<Health>())
        {
            h = GetComponent<Health>();
        }
        gm = gameManager.GetComponent<Game_Manager>();
        if (menuManager != null)
        {
            gmm = menuManager.GetComponent<Game_Menu_Manager>();
        }
        if (isItem == false && isPlayer == false && isNPC == false)
        {
            sr = GetComponent<SpriteRenderer>();
            bm = gameManager.GetComponent<Building_Manager>();
            itemD = gameManager.GetComponent<Item_Drops>();
        }

        if (isHinge)
        {
            bm.sensorsInScene.Add(secondaryObject);
        }
    }

    public void ClickedObject()
    {

        if (gm.buildingOn && !cannotPickUpObj)
        {
            bm.canDisconnect = true;
            bm.objToDisconnect = gameObject;
        }
        if (GetComponent<Physics_Object_Manager>() != null)
        {
            if (GetComponent<Physics_Object_Manager>().canTurnOn == false)
            {
                GetComponent<Physics_Object_Manager>().canTurnOn = true;
            }
            else
            {
                GetComponent<Physics_Object_Manager>().TurnOff();
            }
        }

        if (isCraftingCenter)
        {
            if ((player.transform.position - transform.position).sqrMagnitude < accessRange && gmm.menus[0].isActive == false)
            {
                //Debug.Log("Turning On Menu");

                isCraftingOn = true;
                gmm.ClickedCrafting();
            }
            else if (isCraftingOn == true)
            {
                //Debug.Log("Turning Off Menu");

                isCraftingOn = false;
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isPlayer == false && isNPC == false)
        {
            if (!other.CompareTag("MiningTool") && !other.CompareTag("BuildTool"))
            {
                if (isItem == false)
                {
                    if (isPlaced == false && !other.CompareTag("Planet_Atmosphere"))
                    {
                        if (other.GetComponent<Crumb_Manager>() == true)
                        {
                            if (other.GetComponent<Crumb_Manager>().isAir == false)
                            {
                                triggerCount += 1;
                                //Debug.Log("Hit: " + other.gameObject);
                                CannotPlace();
                            }
                        }
                        else
                        {
                            triggerCount += 1;
                            //Debug.Log("Hit: " + other.gameObject);
                            CannotPlace();
                        }
                    }
                    else
                    {
                        if (isController && other.gameObject.CompareTag("Player"))
                        {
                            sr.color = validSelectionColor;
                            other.GetComponent<Player_Manager>().controllerInUse = gameObject;
                        }
                    }
                }
                else
                {
                    if (other.CompareTag("Player") && isItemProcessing == false)
                    {
                        isItemProcessing = true;
                        //Debug.Log("Part1 entered trigger");
                        ItemProcessing();
                    }
                }
            }
        }
        if (other.GetComponent<Crumb_Manager>() != null)
        {
            if (other.GetComponent<Crumb_Manager>().isWater)
            {
                inWater = true;
                waterCrumbs ++;
                if (GetComponent<Player_Manager>() != null)
                {
                    GetComponent<Player_Manager>().inWater = true;
                }
            }
        }
        if (other.GetComponent<Melee_Triggers>() && h != null)
        {
            if (other.GetComponent<Melee_Triggers>().parent != gameObject && other.GetComponent<Melee_Triggers>().hasHit == false)
            {
                //Debug.Log("Ouch!" + gameObject.name);
                other.GetComponent<Melee_Triggers>().hasHit = true;
                if (GetComponent<NPC_Manager>())
                {
                    GetComponent<NPC_Manager>().FightFlight(other.GetComponent<Melee_Triggers>().parent);
                }

                h.ChangeHealth(other.GetComponent<Melee_Triggers>().damage);
            }
        }

        if (other.CompareTag("Planet_Atmosphere") && !GetComponent<Physics_Object_Manager>())
        {
            if (!other.transform.parent.GetChild(0).GetComponent<Generation_Manager>().gravityAffectedObjs.Contains(gameObject))
            {
                if (GetComponent<NPC_Manager>())
                {
                    if (GetComponent<NPC_Manager>().applyGravity)
                    {
                        Debug.Log("Added npc with gravity enabled");
                        other.transform.parent.GetChild(0).GetComponent<Generation_Manager>().gravityAffectedObjs.Add(gameObject);
                    }
                }
                else
                {
                    Debug.Log("Added non npc");
                    other.transform.parent.GetChild(0).GetComponent<Generation_Manager>().gravityAffectedObjs.Add(gameObject);
                }

            }
        }
        if (other.CompareTag("BuildTool") && isController)
        {
            //Debug.Log("detecting build tool");
            gm.isHoverOverController = true;
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (isPlayer == false && isNPC == false)
        {
            if (isItem == false && !other.CompareTag("MiningTool") && !other.CompareTag("BuildTool"))
            {
                if (isPlaced == false && !other.CompareTag("Planet_Atmosphere"))
                {
                    if (other.GetComponent<Crumb_Manager>())
                    {
                        if (other.GetComponent<Crumb_Manager>().isAir == false)
                        {
                            triggerCount -= 1;
                            if (triggerCount <= 0 && (GetComponent<Anchor_Manager>() != null || snappedToAnchor || isLoose))
                            {
                                triggerCount = 0;
                                CanPlace();
                            }
                        }
                    }
                    else
                    {
                        triggerCount -= 1;
                        if (triggerCount <= 0 && (GetComponent<Anchor_Manager>() != null || snappedToAnchor || isLoose))
                        {
                            triggerCount = 0;
                            CanPlace();
                        }
                    }
                }
                else
                {
                    if (isController && other.gameObject.CompareTag("Player") && other.GetComponent<Player_Manager>().isControlled == false)
                    {
                        sr.color = defaultColor;
                        if (other.GetComponent<Player_Manager>().controllerInUse == gameObject)
                        {
                            other.GetComponent<Player_Manager>().controllerInUse = null;
                            other.GetComponent<Player_Manager>().isControlled = false;
                            Debug.Log("Should be setting iscontrolled to false");
                        }
                    }

                    if (other.gameObject.CompareTag("BuildTool"))
                    {
                        if (gm.buildingOn)
                        {
                            bm.canDisconnect = false;
                        }
                        if (bm.objToDisconnect == gameObject)
                        {
                            bm.objToDisconnect = null;

                        }
                    }
                }
            }
        }
        if (other.GetComponent<Crumb_Manager>() != null)
        {
            if (other.GetComponent<Crumb_Manager>().isWater)
            {
                waterCrumbs--;
                if (waterCrumbs <= 0)
                {
                    inWater = false;
                    waterCrumbs = 0;
                    if (GetComponent<Player_Manager>() != null)
                    {
                        GetComponent<Player_Manager>().inWater = false;
                    }
                }
            }
        }
        if (other.CompareTag("Planet_Atmosphere") && !GetComponent<Physics_Object_Manager>())
        {
            other.transform.parent.GetChild(0).GetComponent<Generation_Manager>().gravityAffectedObjs.Remove(gameObject);
        }
        if (other.CompareTag("BuildTool") && isController)
        {
            //Debug.Log("detecting build tool");
            gm.isHoverOverController = false;
        }
    }
    public void CanPlace()
    {
        if (triggerCount <= 0 && (GetComponent<Anchor_Manager>() != null || snappedToAnchor || isLoose) && isPlaced == false)
        {
            //Debug.Log("Can Place!");
            triggerCount = 0;
            canPlace = true;
            sr.color = defaultColor;
        }
    }

    public void CannotPlace()
    {
        if (isPlaced == false)
        {
            canPlace = false;
            if (sr != null)
            {
                sr.color = invalidColor;
            }
        }
    }

    public IEnumerator DestroyChain()
    {
        //Debug.Log("Should be calling function");

        yield return new WaitForSeconds(.2f);

        foreach (Transform node in nodes)
        {
            if (node != null)
            {
                if (node.childCount > 0)
                {
                    //Debug.Log("Should have deleted obj" + node.name);
                    if (node.GetChild(0).GetComponent<Physics_Object_Manager>())
                    {
                        if (node.GetChild(0).GetComponent<Physics_Object_Manager>().destroyImmediatelyWhenUnLinked)
                        {
                            Destroy(node.GetChild(0).GetComponent<Physics_Object_Manager>().mainBody);

                            node.GetChild(0).GetComponent<Physics_Object_Manager>().isOn = false;
                            itemD.SpawnItem(node.GetChild(0).GetComponent<Object_Manager>().objInfo.itemInfo.uID, node.GetChild(0).transform.position, node.GetChild(0).transform.rotation, true);
                            Destroy(node.GetChild(0).gameObject);
                        }
                        else
                        {
                            node.GetChild(0).GetComponent<Object_Manager>().StartCoroutine(node.GetChild(0).GetComponent<Object_Manager>().DestroyChain());
                            node.GetChild(0).SetParent(null);
                        }
                    }
                    else
                    {
                        node.GetChild(0).GetComponent<Object_Manager>().StartCoroutine(node.GetChild(0).GetComponent<Object_Manager>().DestroyChain());
                        node.GetChild(0).SetParent(null);
                    }

                }
            }
        }
        yield return new WaitForSeconds(.4f);
        //Debug.Log("Should be spawning "+ GetComponent<Object_Manager>().objInfo.itemInfo.uID);
        itemD.SpawnItem(GetComponent<Object_Manager>().objInfo.itemInfo.uID, transform.position, transform.rotation,true);
        if (GetComponent<Object_Manager>().anchorObj)
        {
            GetComponent<Object_Manager>().anchorObj.GetComponent<Anchor_Manager>().objsAttached.Remove(gameObject);
        }
        Destroy(gameObject);
    }

    public void DestroyObj(bool spawnItem)
    {
        foreach (Transform node in nodes)
        {
            if (node != null)
            {
                if (node.childCount > 0)
                {
                    if (node.GetChild(0).GetComponent<Physics_Object_Manager>())
                    {
                        if (node.GetChild(0).GetComponent<Physics_Object_Manager>().destroyImmediatelyWhenUnLinked)
                        {
                            Destroy(node.GetChild(0).GetComponent<Physics_Object_Manager>().mainBody);
                            node.GetChild(0).GetComponent<Physics_Object_Manager>().isOn = false;
                            itemD.SpawnItem(node.GetChild(0).GetComponent<Object_Manager>().objInfo.itemInfo.uID, node.GetChild(0).transform.position, node.GetChild(0).transform.rotation, true);
                            Destroy(node.GetChild(0).gameObject);
                        }
                        else
                        {
                            node.GetChild(0).GetComponent<Object_Manager>().StartCoroutine(node.GetChild(0).GetComponent<Object_Manager>().DestroyChain());
                            node.GetChild(0).SetParent(null);
                        }
                    }
                    else
                    {
                        node.GetChild(0).GetComponent<Object_Manager>().StartCoroutine(node.GetChild(0).GetComponent<Object_Manager>().DestroyChain());
                        node.GetChild(0).SetParent(null);
                    }

                }
            }
        }
        if (spawnItem)
        {
            itemD.SpawnItem(GetComponent<Object_Manager>().objInfo.itemInfo.uID, transform.position, transform.rotation, true);

        }
        anchorObj.GetComponent<Anchor_Manager>().objsAttached.Remove(gameObject);
        Destroy(gameObject);

    }

    void ItemProcessing()
    {
        //Debug.Log("Part 2 adding to inventory");
        gm.AddToInventory(gameObject.name);
        Destroy(gameObject);
    }
}
