using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;

public class Ranged_Weapons_Manager : MonoBehaviour
{
    public int magSize;
    public int currentMagCount;
    public float reloadSpeed;
    public float fireRate;
    public bool didFire;
    public bool isReloading;
    public GameObject firePoint;
    public GameObject projectile;
    public GameObject parentObj;
    private void Start()
    {
        currentMagCount = magSize;

    }
    public void ShootGun()
    {
        if (didFire == false && !isReloading)
        {
            didFire = true;
            //Debug.Log("did fire gun");
            StartCoroutine(FireGun());
        }
    }
    IEnumerator FireGun()
    {

        if (currentMagCount != 0)
        {
            //Debug.Log("fired gun");
            GameObject proj = Instantiate(projectile, firePoint.transform.position, firePoint.transform.rotation);
            proj.GetOrAddComponent<Projectiles>().parentObj = parentObj;
            proj.SetActive(true);
            currentMagCount -= 1;
            yield return new WaitForSeconds(fireRate);
        }
        else
        {
            //Debug.Log("need reloading");
            isReloading = true;
            StartCoroutine(Reload());
        }
        didFire = false;

    }

    IEnumerator Reload()
    {
        yield return new WaitForSeconds(reloadSpeed);
        currentMagCount = magSize;
        isReloading = false;
    }
    private void OnEnable()
    {
        if (!isReloading)
        {
            didFire = false;
        }
        else
        {
            StartCoroutine(Reload());
        }
    }
}
