using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Water_Manager : MonoBehaviour
{

    public int maxWaterStepsPerTick = 200;
    Generation_Manager gm;
    public List<GameObject> activeCrumbs = new List<GameObject>();
    private void Start()
    {
        gm = GetComponent<Generation_Manager>();
        for (int i = 0; i < gm.waterCrumbs.Count; i++)
        {
            Crumb_Manager cm = gm.waterCrumbs[i].GetComponent<Crumb_Manager>();
            if (cm.isExposed && cm.isWater)
            {
                activeCrumbs.Add(gm.waterCrumbs[i]);
            }
        }
    }
    IEnumerator Water()
    {
        while (true)
        {
            Debug.Log("Runnnign Couroutine");
            for (int i = 0; i < activeCrumbs.Count; i++)
            {
                yield return null;

                if ((gm.player.transform.position - activeCrumbs[i].transform.position).sqrMagnitude < 20*20)
                {
                    Crumb_Manager cm = activeCrumbs[i].GetComponent<Crumb_Manager>();

                }
            }
            yield return null;

        }
    }
    private void OnEnable()
    {
        StartCoroutine(Water());

    }
}
