using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class Melee_Triggers : MonoBehaviour
{
    public GameObject target;
    public bool isPlayer;
    public int damage;
    public GameObject parent;
    public bool hasHit;
    public float attackDelay;
    public bool hasDelay;
    private void OnDisable()
    {
        hasHit = false;
    }
}
