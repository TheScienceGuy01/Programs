using UnityEngine;

[System.Serializable]
public class Menus
{
    public int menuID;
    public GameObject menuObj;
    public bool isActive;
    public bool canBeOn;
}

public class Game_Menu_Manager : MonoBehaviour
{
    public Menus[] menus;
    public GameObject craftingManager;
    Crafting_Manager cm;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        cm = craftingManager.GetComponent<Crafting_Manager>();   
    }

    public void ToggleMenus(int menuID, int toggleTo)
    {
        foreach (Menus m in menus)
        {
            if (m.isActive)
            {
                toggleTo = 2;
                break;
            }
        }
        if (toggleTo == 3)
        {
            if (menus[menuID].canBeOn == true)
            {
                if (menus[menuID].isActive == true)
                {
                    menus[menuID].isActive = false;
                    menus[menuID].menuObj.SetActive(false);
                }
                else
                {
                    menus[menuID].isActive = true;
                    menus[menuID].menuObj.SetActive(true);
                }
            }
        }
        else if (toggleTo == 2)
        {
            if (menus[menuID].canBeOn == true)
            {
                if (menus[menuID].isActive == true)
                {
                    menus[menuID].isActive = false;
                    menus[menuID].menuObj.SetActive(false);
                }
            }
        }
        else if (toggleTo == 1)
        {
            if (menus[menuID].canBeOn == true)
            {
                if (menus[menuID].isActive == false)
                {
                    menus[menuID].isActive = true;
                    menus[menuID].menuObj.SetActive(true);
                }
            }
        }
    }

    public void ClickedCrafting()
    {
        Debug.Log("Should be togglin");
        ToggleMenus(0,3);
        cm.GetAllValidRecipes();
    }
}
