using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Loading_UnlLoading : MonoBehaviour
{
    public bool isAnchor;
    public bool isNPC;
    public bool isItem;
    public bool isLoaded;
    public bool didInitialize;
    public bool isOn;
    void OnBecameVisible()
    {
        //Debug.Log("I am Visible!!!");
        if (isAnchor)
        {
            Anchor_Manager am = transform.parent.GetComponent<Anchor_Manager>();
            am.InRange();
        }
        else if (isNPC)
        {
            GetComponent<NPC_Manager>().enabled = true;
            GetComponent<NPC_Manager>().SetEnabled();
            isLoaded = true;
            didInitialize = true;
        }
        else if (isItem)
        {
            isOn = true;
            GetComponent<Object_Manager>().enabled = true;
            if (GetComponent<Rigidbody2D>())
            {
                GetComponent<Rigidbody2D>().simulated = true;

            }
        }
    }

    void OnBecameInvisible()
    {
        //Debug.Log("I am Invisible!!!");
        if (isAnchor)
        {
            Anchor_Manager am = transform.parent.GetComponent<Anchor_Manager>();
            am.OutOfRange();
        }
        else if (isNPC)
        {
            isLoaded = false;
            if (gameObject.activeInHierarchy)
            {
                StartCoroutine(GetComponent<NPC_Manager>().SetDisabled());

            }
            didInitialize = true;
        }
        else if (isItem)
        {
            //Debug.Log("Should be off");
            isOn = false;
            GetComponent<Object_Manager>().enabled = false;
            if (GetComponent<Rigidbody2D>())
            {
                GetComponent<Rigidbody2D>().simulated = false;

            }
        }
    }
}
