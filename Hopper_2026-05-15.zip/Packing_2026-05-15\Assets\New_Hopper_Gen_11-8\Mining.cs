using System.Collections.Generic;
using UnityEngine;

public class Mining : MonoBehaviour
{
    public GameObject player;
    public GameObject gameManager;
    public float miningRange;
    public float miningSpeed;
    public LayerMask crumbLayer;
    Game_Manager gm;
    public bool isDrill;
    public bool startOn;
    public bool isOn;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        gm = gameManager.GetComponent<Game_Manager>();
    }
    private void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Crumb") && isOn)
        {
            if (isDrill)
            {
                if (other.GetComponent<Crumb_Manager>() != null)
                {
                    SetMining(other.GetComponent<Crumb_Manager>());
                }
                else if (other.transform.parent.transform.parent.GetComponent<Crumb_Manager>())
                {
                    Crumb_Manager cParent = other.transform.parent.transform.parent.GetComponent<Crumb_Manager>();

                    SetMining(cParent);
                }
            }
            else
            {
                if (Input.GetMouseButton(0) && gm.canMine && (transform.position - player.transform.position).sqrMagnitude < miningRange)
                {
                    if (other.GetComponent<Crumb_Manager>() != null)
                    {
                        SetMining(other.GetComponent<Crumb_Manager>());
                    }
                    else if (other.transform.parent.transform.parent.GetComponent<Crumb_Manager>())
                    {
                        Crumb_Manager cParent = other.transform.parent.transform.parent.GetComponent<Crumb_Manager>();

                        SetMining(cParent);
                    }
                }

            }
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.GetComponent<Crumb_Manager>() && isOn)
        {
            if (other.GetComponent<Crumb_Manager>().isMining == true)
            {
                //Debug.Log("Out of range of crumbs!");
                other.GetComponent<Crumb_Manager>().isMining = false;
                other.GetComponent<Crumb_Manager>().breakingObj.GetComponent<SpriteRenderer>().sprite = null;
            }
        }
        else if (other.transform.parent)
        {
            if (other.transform.parent.transform.parent)
            {
                if (other.transform.parent.transform.parent.GetComponent<Crumb_Manager>() && isOn)
                {
                    if (other.transform.parent.transform.parent.GetComponent<Crumb_Manager>().isMining == true)
                    {
                        //Debug.Log("Out of range of crumbs!");
                        other.transform.parent.transform.parent.GetComponent<Crumb_Manager>().isMining = false;
                        other.transform.parent.transform.parent.GetComponent<Crumb_Manager>().breakingObj.GetComponent<SpriteRenderer>().sprite = null;
                    }
                }
            }
        }  

    }

    void SetMining(Crumb_Manager cm)
    {
        if (cm.isMining == false && cm.isWater == false && cm.isAir == false)
        {
            cm.isMining = true;
            StartCoroutine(cm.MineCrumb(miningSpeed));
        }
    }
}
