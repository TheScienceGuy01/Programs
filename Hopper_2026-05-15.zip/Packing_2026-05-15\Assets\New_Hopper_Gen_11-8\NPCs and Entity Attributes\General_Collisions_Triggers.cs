using System.Collections.Generic;
using UnityEngine;

public class General_Collisions_Triggers : MonoBehaviour
{
    public int collisionsCount;
    public int triggerCount;
    public GameObject parentObj;
    public bool isGroundCollider;
    public bool isWallCollider;
    public List<GameObject> wallsAgainstNPC = new List<GameObject>();

    NPC_Manager nm;
    private void Start()
    {
        parentObj = transform.parent.gameObject;
        nm = parentObj.GetComponent<NPC_Manager>();
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("MiningTool") && !other.CompareTag("BuildTool"))
        {
            if (isGroundCollider)
            {
                if (!other.CompareTag("NPC") && !other.CompareTag("Attack") && !other.CompareTag("Planet_Atmosphere"))
                {
                    if (other.CompareTag("Crumb"))
                    {
                        if (other.GetComponent<Crumb_Manager>())
                        {
                            if (!other.GetComponent<Crumb_Manager>().isAir)
                            {
                                collisionsCount += 1;
                                nm.isJumping = false;
                                //Debug.Log("off jumping 1");
                                nm.groundedObj = other.gameObject;
                            }
                        }
                        else
                        {
                            collisionsCount += 1;

                            //Debug.Log("off jumping 2");

                            nm.isJumping = false;
                            nm.groundedObj = other.gameObject;
                        }
                    }
                    else
                    {
                        nm.isJumping = false;
                        nm.groundedObj = other.gameObject;

                        collisionsCount += 1;
                    }
                    //Debug.Log("off jumping 3");


                }
            }
            if (isWallCollider)
            {
                if (!other.CompareTag("NPC"))
                {
                    if (!other.CompareTag("Planet_Atmosphere") && other.GetComponent<Crumb_Manager>() == null && !other.CompareTag("MiningTool"))
                    {
                        nm.isAgainstWall = true;
                        wallsAgainstNPC.Add(other.gameObject);
                        collisionsCount += 1;
                        CheckValidSides();
                    }
                }
            }
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (!other.CompareTag("MiningTool") && !other.CompareTag("BuildTool"))
        {
            if (isGroundCollider)
            {
                if (!other.CompareTag("NPC") && !other.CompareTag("Attack") && !other.CompareTag("Planet_Atmosphere"))
                {
                    if (other.CompareTag("Crumb"))
                    {
                        if (other.GetComponent<Crumb_Manager>())
                        {
                            if (!other.GetComponent<Crumb_Manager>().isAir)
                            {
                                collisionsCount -= 1;

                                if (collisionsCount == 0)
                                {
                                    nm.isJumping = true;

                                }
                            }
                        }
                        else
                        {
                            collisionsCount -= 1;

                            if (collisionsCount == 0)
                            {
                                nm.isJumping = true;

                            }
                        }
                    }
                    else if (other.CompareTag("Planet_Atmosphere"))
                    {
                        //debug.Log("Setting In Space" + other.name);
                        nm.isInSpace = true;

                    }
                    else if (!other.CompareTag("Planet_Atmosphere"))
                    {
                        collisionsCount -= 1;

                        if (collisionsCount == 0)
                        {
                            nm.isJumping = true;
                            nm.Jumping();
                        }
                    }
                }
            }

            if (isWallCollider)
            {
                if (!other.CompareTag("NPC"))
                {
                    wallsAgainstNPC.Remove(other.gameObject);

                    collisionsCount -= 1;
                    if (collisionsCount == 0)
                    {
                        nm.isAgainstWall = false;
                    }
                    if (other.CompareTag("Player"))
                    {
                        //nm.isAgainstPlayer = false;
                    }
                    CheckValidSides();
                }
            }
        }
    }

    void CheckValidSides()
    {
        nm.canMoveLeft = true;
        nm.canMoveRight = true;
        foreach (GameObject obj in wallsAgainstNPC)
        {
            Vector2 localPos = transform.InverseTransformPoint(obj.transform.position);

            if (localPos.x > 0)
            {
                nm.canMoveRight = false;
            }
            else
            {
                nm.canMoveLeft = false;

            }
        }
    }
}
