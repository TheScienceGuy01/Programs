using UnityEngine;
using System.Collections.Generic;

public class Anchor_Manager : MonoBehaviour
{
    public List<GameObject> objsAttached = new List<GameObject>();
    public float attachRange;
    public int upgradeLevel;
    public GameObject rangeVisual;
    public bool isInRange;
    public bool isRangeObj;

    private void Start()
    {
        if (!isRangeObj)
        {
            isInRange = true;
            rangeVisual = transform.GetChild(1).gameObject;
            float diameter = attachRange * 2f;
            rangeVisual.transform.localScale = new Vector3(diameter, diameter, 1f);
        }
    }

    private void Update()
    {
        for (int i = 0; i < objsAttached.Count; i++)
        {
            GameObject obj = objsAttached[i];
            if (!obj.GetComponent<FixedJoint2D>())
            {
                if (obj.GetComponent<Loading_UnlLoading>())
                {
                    obj.GetComponent<Object_Manager>().DestroyObj(true);
                }
            }
        }
    }

    public bool CheckIfInRangeBool(GameObject obj)
    {
        //Debug.Log("Testing the range bool");
        float attachRange1 = attachRange * attachRange;
        if ((obj.transform.position - transform.position).sqrMagnitude < attachRange1)
        {
            return true;
        }
        else
        {
           //Debug.Log("Failed due to "+ CheckIfInRangeFloat(obj));
           return false;
        }
    }
    public float CheckIfInRangeFloat(GameObject obj)
    {
        return (obj.transform.position - transform.position).sqrMagnitude;
    }
    public void OutOfRange()
    {
        isInRange = false;
        GetComponent<Rigidbody2D>().simulated = false;
        foreach (GameObject obj in objsAttached)
        {
            if (obj.GetComponent<Rigidbody2D>())
            {
                obj.GetComponent<Object_Manager>().isActive = false;
                Rigidbody2D rb = obj.GetComponent<Rigidbody2D>();
                rb.simulated = false;
            }
        }
        //Debug.Log("disabled anchor");

    }
    public void InRange()
    {
        GetComponent<Rigidbody2D>().simulated = true;
        isInRange = true;

        foreach (GameObject obj in objsAttached)
        {
            if (obj.GetComponent<Rigidbody2D>() != null)
            {
                obj.GetComponent<Object_Manager>().isActive = true;

                Rigidbody2D rb = obj.GetComponent<Rigidbody2D>();
                rb.simulated = true;
            }
        }
        //Debug.Log("enabled anchor");

    }
}
