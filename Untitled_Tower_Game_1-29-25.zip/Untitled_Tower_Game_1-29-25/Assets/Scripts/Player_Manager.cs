using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Manager : MonoBehaviour
{
    private Animator animator;
    private Rigidbody2D rb;
    public float maxWalkSpeed;
    public float maxRunSpeed;
    public float maxJumpSpeed;
    public float accelRate;
    public float jumpHeight;
    public float currentSpeed;
    private bool isRunning;
    public int groundCount;
    public GameObject surfaceLevel;
    public bool isAffectedByGravity;
    public float lastDistFromPlanet;
    public float firstDistFromPlanet;
    public bool isJumping;
    public bool isFalling;
    public int touchingCrumbs;
    public Camera camera;
    public float cameraZoomSpeed;
    public float cameraZoomAmount;
    public GameObject drill;
    public bool isDrillActive;

    void Start()
    {
        animator = transform.GetChild(0).GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        firstDistFromPlanet = Vector2.Distance(transform.position, surfaceLevel.transform.position);
        //drill = transform.Find("Drill_Arm").gameObject;
        //mouseCursor = transform.Find("Mouse_Cursor").gameObject;
    }
    // Update is called once per frame
    void Update()
    {
        float distFromPlanet = Vector2.Distance(transform.position, surfaceLevel.transform.position);

        Vector2 localVelocity = transform.GetChild(0).InverseTransformDirection(rb.linearVelocity); // Convert velocity to local space


        if (isDrillActive == true)
        {
            Vector3 mousePosition = Input.mousePosition;
            mousePosition.z = Mathf.Abs(camera.transform.position.z - drill.transform.position.z);
            Vector3 worldMousePosition = camera.ScreenToWorldPoint(mousePosition);
            Vector3 direction = worldMousePosition - drill.transform.position;
            direction.z = 0;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            drill.transform.rotation = Quaternion.Euler(0f, 0f, angle + 90);


        }

        if (Input.GetKey(KeyCode.D))
        {
            localVelocity.x = currentSpeed; // Set the local x-axis velocity
            currentSpeed = maxWalkSpeed;
            if (isJumping == false)
            {
                animator.SetBool("isWalking", true);
            }

            if (Input.GetKeyDown(KeyCode.LeftShift) || isRunning == true)
            {
                if (isJumping == false)
                {
                    animator.SetBool("isRunning", true);
                    animator.SetBool("isWalking", false);
                }
                isRunning = true;
                currentSpeed = maxRunSpeed; // Adjust this value for running speed
            }
            else
            {
                animator.SetBool("isRunning", false);
            }

            if (isJumping == true || isFalling == true)
            {
                currentSpeed = currentSpeed / maxJumpSpeed;
            }

            if ((touchingCrumbs != 0 && groundCount == 0))
            {
                currentSpeed = 0;
                localVelocity.x = currentSpeed;
            }
            rb.linearVelocity = transform.GetChild(0).TransformDirection(localVelocity);
            // Convert back to world space
            // Set the localScale using a Vector2
            Vector2 newScale = transform.GetChild(0).localScale;
            newScale.x = 1;
            transform.GetChild(0).localScale = newScale;
        }

        if (Input.GetKey(KeyCode.A))
        {
            localVelocity.x = -currentSpeed; // Set the local x-axis velocity
            currentSpeed = maxWalkSpeed;
            if (isJumping == false)
            {
                animator.SetBool("isWalking", true);
            }

            if (Input.GetKeyDown(KeyCode.LeftShift) || isRunning == true)
            {
                if (isJumping == false)
                {
                    animator.SetBool("isRunning", true);
                    animator.SetBool("isWalking", false);
                }
                isRunning = true;
                currentSpeed = maxRunSpeed; // Adjust this value for running speed
            }
            else
            {
                animator.SetBool("isRunning", false);
            }

            if (isJumping == true || isFalling == true)
            {
                currentSpeed = currentSpeed / maxJumpSpeed;
            }

            if ((touchingCrumbs != 0 && groundCount == 0))
            {
                currentSpeed = 0;
                localVelocity.x = currentSpeed;
            }
            rb.linearVelocity = transform.GetChild(0).TransformDirection(localVelocity);

            Vector2 newScale = transform.GetChild(0).localScale;
            newScale.x = -1;
            transform.GetChild(0).localScale = newScale;
        }

        if ((!Input.GetKey(KeyCode.D) && !Input.GetKey(KeyCode.A)))
        {
            isRunning = false;
            animator.SetBool("isRunning", false);
            animator.SetBool("isWalking", false);
        }

        if (Input.GetKeyDown(KeyCode.Space) && groundCount != 0 && isJumping == false)
        {
            Vector2 jumpDirection = transform.up;
            isJumping = true;
            Vector2 currentVerticalVelocity = (Vector2)(Vector3.Project(rb.linearVelocity, jumpDirection));
            rb.linearVelocity = rb.linearVelocity - currentVerticalVelocity + (jumpDirection * jumpHeight);
            animator.SetBool("isJumping", true);
            animator.SetBool("isRunning", false);
            animator.SetBool("isWalking", false);
        }

        if (!Input.GetKeyDown(KeyCode.Space) && groundCount == 0 && isJumping == false)
        {
            animator.SetBool("isRunning", false);
            isFalling = true;
            animator.SetBool("isWalking", false);
            animator.SetBool("isJumping", true);
            animator.SetInteger("JumpStage", 2);
        }

        if (animator.GetBool("isJumping") == true && isJumping == true)
        {

            lastDistFromPlanet = Vector2.Distance(transform.position, surfaceLevel.transform.position);

            if (firstDistFromPlanet < lastDistFromPlanet)
            {
                animator.SetInteger("JumpStage", 1);
            }
            else if (firstDistFromPlanet > lastDistFromPlanet)
            {
                animator.SetInteger("JumpStage", 2);
            }
            firstDistFromPlanet = lastDistFromPlanet;
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Ground") && transform.name != "Collider" && other.isTrigger != true)
        {
            groundCount += 1;
            animator.SetInteger("JumpStage", 0);
            animator.SetBool("isJumping", false);
            isJumping = false;
            isFalling = false;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Ground") && transform.name != "Collider" && other.isTrigger != true)
        {
            groundCount -= 1;
        }
    }
}