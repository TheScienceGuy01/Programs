using Unity.VisualScripting;
using UnityEngine;

public class Cursor : MonoBehaviour
{
    private int sensorCount = 0;
    public bool stateCondition = true;
    public Sprite stateTrueSprite;
    public Sprite stateFalseSprite;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Sensor"))
        {
            sensorCount++;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Sensor"))
        {
            sensorCount--;
        }
    }

    private void Update()
    {
        if (sensorCount > 0)
        {
            stateCondition = false;
            transform.GetComponent<SpriteRenderer>().sprite = stateFalseSprite;
        }
        else
        {
            stateCondition = true;
            transform.GetComponent<SpriteRenderer>().sprite = stateTrueSprite;
        }
    }
}
