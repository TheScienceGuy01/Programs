using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;


[System.Serializable]
public class SpawnableObject
{
    public GameObject solidObject;  // The GameObject to spawn
    public int spawnRate;        // The spawn rate for this GameObject
}
public class Object_Spawner : MonoBehaviour
{
    public List<SpawnableObject> objects;
    public int randObjectNumber;
    public int weightCount;
    public GameObject chosenObject;
    public GameObject mainCamera;
    public float rotRate;
    public GameObject ghostSpawner;
    public GameObject objectHolder;
    public float secondsDelay;
    public bool isClicked;
    public bool nullSlots;
    public GameObject canvas;
    public GameObject nullSlotGameobject;
    public GameObject savedObject;
    public bool saveNext;
    public bool changeToSaved;
    public float objectMaxSpeed;

    public List<SpawnableObject> trashPool;
    public List<SpawnableObject> bronzePool;
    public List<SpawnableObject> silverPool;
    public List<SpawnableObject> goldPool;

    public List<SpawnableObject> guaranteedPool;

    public GameObject[] meterLevels;
    public int meterCounter = 0;
    public int meterGoal = 28;
    public int meterLevel = 0;
    public TextMeshProUGUI counterText;
    public TextMeshProUGUI counterGoal;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

        Vector3 mouseScreenPosition = Input.mousePosition;

        // Convert the screen position to world position
        Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(mouseScreenPosition);

        // Adjust for the z-axis to match your 2D plane
        mouseWorldPosition.z = 0;

        int initCountTrash = 1;
        int initCountBronze = 3;
        int initCountGold = 0;

        while (objects.Count < initCountTrash) // Ensure unique additions
        {
            int rand = Random.Range(0, trashPool.Count);
            var selectedObject = trashPool[rand];

            if (!objects.Contains(selectedObject))
            {
                objects.Add(selectedObject);
            }
        }

        while (objects.Count < initCountBronze) // Ensure unique additions
        {
            int rand = Random.Range(0, bronzePool.Count);
            var selectedObject = bronzePool[rand];

            if (!objects.Contains(selectedObject))
            {
                objects.Add(selectedObject);
            }
        }

        while (objects.Count < initCountGold) // Ensure unique additions
        {
            int rand = Random.Range(0, goldPool.Count);
            var selectedObject = goldPool[rand];

            if (!objects.Contains(selectedObject))
            {
                objects.Add(selectedObject);
            }
        }

        foreach (SpawnableObject obj in guaranteedPool)
        {
            objects.Add(obj);
        }

        ghostSpawner.transform.position = mouseWorldPosition;
        chosenObject = objects[0].solidObject;
        ghostSpawner = Instantiate(chosenObject, mouseWorldPosition, ghostSpawner.transform.rotation);

        foreach (SpawnableObject x in objects)
        {
            weightCount += x.spawnRate;
        }

        counterGoal.text = "Items Needed: " + meterGoal;
        meterLevel = meterGoal / 28;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 mouseScreenPosition = Input.mousePosition;

        // Convert the screen position to world position
        Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(mouseScreenPosition);

        // Adjust for the z-axis to match your 2D plane
        mouseWorldPosition.z = 0;

        ghostSpawner.transform.position = mouseWorldPosition;
        nullSlotGameobject.transform.position = mouseWorldPosition;


        if (((Input.GetMouseButtonDown(0) && ghostSpawner.GetComponent<Object_Manager>().IsTriggerEmpty() == true) || isClicked == true) && nullSlots == false)
        {
            if (isClicked == false)
            {
                if (canvas.gameObject.GetComponent<Inventory_Manager>().slotSelected == false)
                {
                    canvas.GetComponent<Inventory_Manager>().storageSlot2Item.GetComponent<Image>().sprite = null;
                    nullSlotGameobject.gameObject.SetActive(true);
                    nullSlots = true;
                    changeToSaved = true;
                }
                else
                {
                    saveNext = true;

                }

                if (ghostSpawner.GetComponent<Rigidbody2D>() != null)
                {
                    ghostSpawner.GetComponent<Rigidbody2D>().linearVelocity = Vector2.zero;
                    ghostSpawner.GetComponent<Rigidbody2D>().angularVelocity = 0f;
                    if (ghostSpawner.GetComponent<PowerUps_Update>() != null)
                    {
                        ghostSpawner.GetComponent<PowerUps_Update>().enabled = true;
                    }
                    ghostSpawner.GetComponent<Rigidbody2D>().gravityScale = 1;
                }
                ghostSpawner.GetComponent<Object_Manager>().isGhost = false;
                ghostSpawner.GetComponent<SpriteRenderer>().sprite = ghostSpawner.GetComponent<Object_Manager>().presentedSprite;
                if (ghostSpawner.GetComponent<Animator>() != null)
                {
                    ghostSpawner.GetComponent<Animator>().enabled = true;
                    if (ghostSpawner.gameObject.name.Contains("Balloon"))
                    {
                        Destroy(ghostSpawner.GetComponent<Rigidbody2D>());
                    }
                }
                ghostSpawner.transform.parent = objectHolder.transform;
                if (ghostSpawner.gameObject.name.Contains("UFO"))
                {
                    StartCoroutine(ghostSpawner.GetComponent<PowerUps>().UFO());
                    foreach (Transform beam in ghostSpawner.transform)
                    {
                        beam.gameObject.SetActive(true);
                    }
                }

                if (ghostSpawner.gameObject.name.Contains("Trampoline"))
                {
                    ghostSpawner.transform.GetChild(0).gameObject.SetActive(true);
                }

            }
            else
            {

                isClicked = false;
                Destroy(ghostSpawner.gameObject);
            }


            Collider2D[] colliders = ghostSpawner.GetComponents<Collider2D>();

            foreach (Collider2D col in colliders)
            {
                col.isTrigger = false;
            }

            if (colliders.Length > 0)
            {
                colliders[0].isTrigger = false;
            }

            if (ghostSpawner.GetComponent<PowerUps>() != null)
            {
                ghostSpawner.GetComponent<PowerUps>().enabled = true;
            }


            randObjectNumber = Random.Range(0, weightCount);
            int runningTotal = 0;
            bool canCont = true;

            if (canvas.gameObject.GetComponent<Inventory_Manager>().slotSelected == true || nullSlots == true)
            {
                while (canCont == true)
                {
                    foreach (SpawnableObject x in objects)
                    {
                        runningTotal += x.spawnRate;
                        if (randObjectNumber <= runningTotal)
                        {
                            chosenObject = x.solidObject;
                            canCont = false;
                            break;
                        }
                    }
                }
            }
            else
            {
                chosenObject = canvas.GetComponent<Inventory_Manager>().selectedObject;
            }

            if (saveNext == true)
            {
                saveNext = false;
                savedObject = chosenObject;
            }

            if (changeToSaved == true)
            {
                changeToSaved = false;
                chosenObject = savedObject;
            }

            ghostSpawner = Instantiate(chosenObject, mouseWorldPosition, ghostSpawner.transform.rotation);
            if (ghostSpawner.GetComponent<Rigidbody2D>() != null)
            {
                ghostSpawner.GetComponent<Rigidbody2D>().gravityScale = 0;
            }
            ghostSpawner.GetComponent<Object_Manager>().isGhost = true;

            if (ghostSpawner.gameObject.name.Contains("Trampoline"))
            {
                ghostSpawner.transform.rotation = Quaternion.Euler(0, 0, -90);
            }
            else
            {
                ghostSpawner.transform.rotation = Quaternion.Euler(0, 0, 0);
            }

            if (canvas.gameObject.GetComponent<Inventory_Manager>().slotSelected == false && canvas.GetComponent<Inventory_Manager>().storageSlot2Item.GetComponent<Image>().sprite == null)
            {
                ghostSpawner.gameObject.SetActive(false);
            }
        }
    }

    private void FixedUpdate()
    {
        if (Input.GetMouseButton(1))
        {
            ghostSpawner.transform.Rotate(0, 0, rotRate);
        }
        foreach (Transform obj in objectHolder.transform)
        {
            if (obj.GetComponent<Rigidbody2D>() != null)
            {
                Rigidbody2D rb = obj.GetComponent<Rigidbody2D>();

                if (rb.linearVelocity.magnitude > objectMaxSpeed)
                {
                    rb.linearVelocity = rb.linearVelocity.normalized * objectMaxSpeed;
                }
            }
        }


        if (GetComponent<Rigidbody2D>() != null)
        {
            Rigidbody2D rb = GetComponent<Rigidbody2D>();

            if (rb.linearVelocity.magnitude > objectMaxSpeed)
            {
                rb.linearVelocity = rb.linearVelocity.normalized * objectMaxSpeed;
            }
        }
    }

    public void ObjectPicker(int rarity)
    {
        int rand = -1;
        switch (rarity)
        {
            case 0:
                rand = Random.Range(0,trashPool.Count);
                objects.Add(trashPool[rand]);
                break;
            case 1:
                rand = Random.Range(0, bronzePool.Count);
                objects.Add(bronzePool[rand]);
                break;
            case 2:
                rand = Random.Range(0, silverPool.Count);
                objects.Add(silverPool[rand]);
                break;
            case 3:
                rand = Random.Range(0, goldPool.Count);
                objects.Add(goldPool[rand]);
                break;
        }
    }

    public void MeterChange(bool changeUp)
    {
        if (changeUp == true)
        {
            meterCounter += 1;
        }
        else
        {
            if (meterCounter > 0)
            {
                meterCounter -= 1;
            }
        }
        counterText.text = "Count: " + meterCounter;
        int meterLevelInt = meterGoal / 28;

        foreach (GameObject level in meterLevels)
        {
            if (level.gameObject.activeInHierarchy == true)
            {
                level.gameObject.SetActive(false);
            }
        }
        for (int i = 0; i < meterCounter / meterLevelInt; i++)
        {
            meterLevels[i].gameObject.SetActive(true);
        }
        if (meterCounter == meterGoal)
        {
            meterCounter = 0;
            counterText.text = "Count: " + meterCounter;
            meterGoal += 28;
            counterGoal.text = "Items Needed: " + meterGoal;
            foreach (GameObject level in meterLevels)
            {
                if (level.gameObject.activeInHierarchy == true)
                {
                    level.gameObject.SetActive(false);
                }
            }
        }
    }
}
