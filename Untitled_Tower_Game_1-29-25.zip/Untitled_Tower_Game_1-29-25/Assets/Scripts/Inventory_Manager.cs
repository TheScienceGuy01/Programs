using UnityEngine;
using UnityEngine.UI;

public class Inventory_Manager : MonoBehaviour
{
    public Sprite selectedInventorySprite;
    public Sprite notSelectedInventorySprite;

    public GameObject storageSlot1;
    public GameObject storageSlot2;
    public GameObject storageSlot2Item;
    public GameObject selectedObject;
    public GameObject nullSlotGameobject;

    public GameObject player;
    public GameObject[] powerups;

    public bool slotSelected = true;

    private void Start()
    {
        storageSlot2Item.GetComponent<Image>().sprite = null;
        slotSelected = true;
    }
    // Update is called once per frame
    void Update()
    {
        if (Input.GetAxis("Mouse ScrollWheel") != 0f)
        {
            if (slotSelected == false)
            {
                slotSelected = true;
                nullSlotGameobject.gameObject.SetActive(false);
                if (storageSlot2Item.GetComponent<Image>().sprite != null)
                {
                    player.GetComponent<Object_Spawner>().changeToSaved = true;
                }
                player.GetComponent<Object_Spawner>().ghostSpawner.gameObject.SetActive(true);

                if (storageSlot2Item.GetComponent<Image>().sprite != null)
                {
                    player.GetComponent<Object_Spawner>().isClicked = true;
                }
                player.GetComponent<Object_Spawner>().nullSlots = false;
                storageSlot1.GetComponent<Image>().sprite = selectedInventorySprite;
                storageSlot2.GetComponent<Image>().sprite = notSelectedInventorySprite;

            }
            else
            {
                slotSelected = false;
                if (storageSlot2Item.GetComponent<Image>().sprite == null)
                {
                    player.GetComponent<Object_Spawner>().nullSlots = true;
                    nullSlotGameobject.gameObject.SetActive(true);
                    player.GetComponent<Object_Spawner>().ghostSpawner.gameObject.SetActive(false);
                }
                else
                {
                    player.GetComponent<Object_Spawner>().isClicked = true;
                }
                storageSlot2.GetComponent<Image>().sprite = selectedInventorySprite;
                storageSlot1.GetComponent<Image>().sprite = notSelectedInventorySprite;
            }
        }

        foreach (GameObject x in powerups)
        {
            if (Input.GetKeyDown(KeyCode.E) && player.GetComponent<Object_Spawner>().chosenObject.gameObject == x.gameObject && storageSlot2Item.GetComponent<Image>().sprite != null && slotSelected == true)
            {
                Debug.Log("Slot full!");
            }
            if (Input.GetKeyDown(KeyCode.E) && player.GetComponent<Object_Spawner>().chosenObject.gameObject == x.gameObject && storageSlot2Item.GetComponent<Image>().sprite == null && slotSelected == true)
            {
                selectedObject = x.gameObject;
                storageSlot2Item.GetComponent<Image>().sprite = player.GetComponent<Object_Spawner>().chosenObject.GetComponent<Object_Manager>().presentedSprite;
                player.GetComponent<Object_Spawner>().saveNext = true;
                player.GetComponent<Object_Spawner>().isClicked = true;
                Debug.Log("Saved:" + player.GetComponent<Object_Spawner>().chosenObject.GetComponent<Object_Manager>().presentedSprite.name);
            }
        }
    }
}
