using System.Collections;
using UnityEngine;

public class PowerUps : MonoBehaviour
{
    public bool isFrost;
    public bool isBomb;
    public bool isNuke;
    public bool isUFOLights;
    public bool isUFO;
    public bool isVending;
    public bool isBouncy;

    public float nukeThreshold;
    public float bombForce;
    public float bombRadius;

    public GameObject vendingLocation;
    public GameObject[] vendingObjects;
    public int vendingAmount;

    public Sprite[] ufoLights;
    public float lightsTime;
    public float beamTime;
    public bool startUFO = true;
    public float ufoUpwardForce;
    public float ufoUpwardAmount;
    public float ufoStartDelay;

    public float bounceForce;

    public GameObject objectHolder;

    private Rigidbody2D rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody2D>();

        if (isFrost)
        {
            StartCoroutine(Frost());
        }
        if (isBomb)
        {
            StartCoroutine(Bomb());
        }
        if (isVending)
        {
            StartCoroutine(Vending());
        }
        if (isUFOLights)
        {
            StartCoroutine(UFO());
        }
    }

    IEnumerator Frost()
    {
        yield return new WaitForSeconds(2);

        foreach (Transform x in objectHolder.transform)
        {
            if (x.GetComponent<Object_Manager>() != null && x.GetComponent<Object_Manager>().isGhost == false && x.GetComponent<Rigidbody2D>() != null)
            {
                Destroy(x.GetComponent<Rigidbody2D>());
                x.GetComponent<SpriteRenderer>().sprite = x.GetComponent<Object_Manager>().frostSprite;
                if (x.gameObject.name.Contains("UFO"))
                {
                    foreach (Transform beam in x.transform)
                    {
                        beam.gameObject.SetActive(false);
                    }
                }
            }
            if (x.GetComponent<Rigidbody2D>() == null && x.gameObject.name.Contains("Balloon"))
            {
                Destroy(x.gameObject);
            }
        }
        Destroy(gameObject);
    }

    IEnumerator Bomb()
    {
        yield return new WaitForSeconds(2);


        if (!GetComponent<SpriteRenderer>().sprite.name.Contains("Frost"))
        {
            Debug.Log("BOOOOOMMMM");
            Collider2D[] colliders = Physics2D.OverlapCircleAll(transform.position, bombRadius);
            Collider2D[] collidersDestroy = Physics2D.OverlapCircleAll(transform.position, bombRadius / 2);
            foreach (Collider2D collider in colliders)
            {
                // Apply force to objects with Rigidbody2D
                Rigidbody2D rb = collider.GetComponent<Rigidbody2D>();
                if (rb != null && !rb.gameObject.name.Contains("Surface"))
                {
                    if (rb.gameObject.GetComponent<SpriteRenderer>() != null)
                    {
                        if (!rb.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("outline") && !rb.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("Invalid"))
                        {
                            Vector2 direction = rb.position - (Vector2)transform.position;
                            rb.AddForce(direction.normalized * bombForce);
                        }
                    }
                    else
                    {
                        Vector2 direction = rb.position - (Vector2)transform.position;
                        rb.AddForce(direction.normalized * bombForce);
                    }
                }
            }
            foreach (Collider2D collider in collidersDestroy)
            {
                if (collider.gameObject.GetComponent<Object_Manager>() != null && (collider.gameObject.name != "Player_Universal") && !collider.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("Outline") && !collider.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("Invalid"))
                {
                    if (!collider.gameObject.name.Contains("Nuke"))
                    {
                        Destroy(collider.gameObject);
                    }
                    else
                    {
                        foreach (Transform x in objectHolder.transform)
                        {
                            if (x.gameObject != transform.gameObject)
                            {
                                Destroy(x.gameObject);

                            }
                        }
                        Destroy(collider.gameObject);
                    }
                }
            }
            Destroy(gameObject);
        }
    }

    IEnumerator Vending()
    {
        GameObject vendedItem = null;
        int randNum = Random.Range(0,vendingObjects.Length);

        for (int i = 0; i < vendingAmount; i++)
        {
            yield return new WaitForSeconds(2);

            vendedItem = Instantiate(vendingObjects[randNum], vendingLocation.transform.position, vendingLocation.transform.rotation);
            vendedItem.GetComponent<Rigidbody2D>().gravityScale = 1;
            vendedItem.GetComponent<Object_Manager>().isGhost = false;
            vendedItem.GetComponent<Collider2D>().isTrigger = false;
            yield return new WaitForEndOfFrame();
            vendedItem.GetComponent<SpriteRenderer>().sprite = vendedItem.GetComponent<Object_Manager>().presentedSprite;
            vendedItem.transform.parent = objectHolder.transform;

            randNum = Random.Range(0, vendingObjects.Length);
        }
    }

    public IEnumerator UFO()
    {
        if (isUFOLights)
        {
            while (startUFO == true)
            {
                if (transform.parent.name == "Lights")
                {
                    transform.GetComponent<SpriteRenderer>().enabled = true;
                    transform.GetComponent<SpriteRenderer>().sprite = ufoLights[Random.Range(0, ufoLights.Length)];
                    yield return new WaitForSeconds(Random.Range(.1f, lightsTime));
                    transform.GetComponent<SpriteRenderer>().enabled = false;
                    yield return new WaitForSeconds(Random.Range(.1f, lightsTime));
                }
                else
                {
                    foreach (Transform beam in transform)
                    {
                        if (!beam.name.Contains("Booster"))
                        {
                            beam.transform.GetComponent<SpriteRenderer>().enabled = true;
                            yield return new WaitForSeconds(beamTime);
                            beam.transform.GetComponent<SpriteRenderer>().enabled = false;
                        }
                    }
                }
            }
        }
        else
        {
            yield return new WaitForSeconds(ufoStartDelay);
            float elapsedTime = 0f;

            while (elapsedTime < ufoUpwardAmount)
            {
                // Apply the force
                rb.AddForce(transform.up.normalized * ufoUpwardForce, ForceMode2D.Force);

                // Increment elapsed time
                elapsedTime += Time.deltaTime;

                // Wait for the next frame
                yield return null;
            }
            Destroy(transform.GetComponent<Rigidbody2D>());
        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (isNuke && !GetComponent<SpriteRenderer>().sprite.name.Contains("Frost"))
        {
            Vector3 velocity = collision.relativeVelocity;
            //Vector3 normal = collision.GetContact(0).normal;
            if (velocity.magnitude > nukeThreshold)//impact faster than 2
            {
                foreach (Transform x in objectHolder.transform)
                {
                    if (x.gameObject != transform.gameObject)
                    {
                        Destroy(x.gameObject);

                    }
                }
                Destroy(gameObject);

            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (isBouncy)
        {
            rb = collision.gameObject.GetComponent<Rigidbody2D>();
            if (rb != null && !rb.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("outline") && !rb.gameObject.GetComponent<SpriteRenderer>().sprite.name.Contains("Invalid"))
            {
                // Calculate the normal direction based on the trampoline's orientation
                Vector2 trampolineNormal = -transform.right.normalized;

                if (collision.gameObject.CompareTag("Player"))
                {
                    collision.gameObject.GetComponent<Rigidbody2D>().AddForce(trampolineNormal * bounceForce*2, ForceMode2D.Impulse);
                }
                else
                {
                    collision.gameObject.GetComponent<Rigidbody2D>().AddForce(trampolineNormal * bounceForce, ForceMode2D.Impulse);
                }
            }
        }
    }
    /*
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.G) && isBomb)
        {
            Debug.Log("Bomb triggered");
            StartCoroutine(Bomb());
        }
    }
    */
}
