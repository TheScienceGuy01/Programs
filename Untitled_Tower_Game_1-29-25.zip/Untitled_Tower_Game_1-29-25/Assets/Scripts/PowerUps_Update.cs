using System.Collections;
using UnityEngine;

public class PowerUps_Update : MonoBehaviour
{
    private Rigidbody2D rb;
    private bool isDelayed = true;
    private bool clearToRun = true;
    private Vector3 lastPosition;
    public int waitTime = 2;
    public GameObject player;
    public float transparencySpeed;
    private SpriteRenderer sp;
    public float alphaVal = 1;
    private bool switchTrans;
    private bool corotineOn;
    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        sp = GetComponent<SpriteRenderer>();
        StartCoroutine(DelayedChecking());
    }

    private void FixedUpdate()
    {
        if (rb.linearVelocity.magnitude == 0 && isDelayed == false && clearToRun == true)
        {
            lastPosition = transform.position;
            clearToRun = false;
            corotineOn = true;
            StartCoroutine(IsStable());
        }
        else
        {
            if (corotineOn == true)
            {
                clearToRun = true;
                StopCoroutine(IsStable());
            }
        }

        if (switchTrans == true)
        {
            alphaVal -= transparencySpeed;
        }
        else
        {
            alphaVal += transparencySpeed;
        }

        sp.color = new Color(1f, 1f, 1f, alphaVal);


        if (alphaVal >= 1)
        {
            switchTrans = true;
        }
        if (alphaVal <= 0)
        {
            switchTrans = false;
        }
    }

    IEnumerator DelayedChecking()
    {
        yield return new WaitForSeconds(1);
        isDelayed = false;
    }

    IEnumerator IsStable()
    {
        yield return new WaitForSeconds(waitTime);
        if (transform.position == lastPosition)
        {
            player.GetComponent<Object_Spawner>().MeterChange(true);
            sp.color = new Color(1f, 1f, 1f, 1);
            Destroy(GetComponent<PowerUps_Update>());
        }
        else
        {
            clearToRun = true;
        }
    }

}
