using System.Collections.Generic;
using UnityEngine;

public class Object_Manager : MonoBehaviour
{
    public Sprite frostSprite;
    public Sprite presentedSprite;
    public Sprite outlineSprite;
    public Sprite invalidSprite;
    public bool isGhost;
    public GameObject player;

    // List to track objects in the trigger
    private List<Collider2D> objectsInTrigger = new List<Collider2D>();

    private void Start()
    {
        if (GetComponent<SpriteRenderer>().sprite != outlineSprite && GetComponent<SpriteRenderer>().sprite != invalidSprite)
        {
            presentedSprite = GetComponent<SpriteRenderer>().sprite;
        }
        GetComponent<SpriteRenderer>().sprite = outlineSprite;
    }

    // Called when another collider enters the trigger
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (!objectsInTrigger.Contains(other) && isGhost == true)
        {
            objectsInTrigger.Add(other);
            GetComponent<SpriteRenderer>().sprite = invalidSprite;
        }
        if (other.CompareTag("Lava") && isGhost == false)
        {
            if (gameObject.GetComponent<PowerUps_Update>() == null)
            {
                player.GetComponent<Object_Spawner>().MeterChange(false);
            }
            Destroy(gameObject);
        }
    }

    // Called when another collider exits the trigger
    private void OnTriggerExit2D(Collider2D other)
    {
        if (objectsInTrigger.Contains(other) && isGhost == true)
        {
            objectsInTrigger.Remove(other);
            if (IsTriggerEmpty() == true)
            {
                GetComponent<SpriteRenderer>().sprite = outlineSprite;
            }
        }
    }

    // To check if the trigger is empty
    public bool IsTriggerEmpty()
    {
        return objectsInTrigger.Count == 0;
    }
}
