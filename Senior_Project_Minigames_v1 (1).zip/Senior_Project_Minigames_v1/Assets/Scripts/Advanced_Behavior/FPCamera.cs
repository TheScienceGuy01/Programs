using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FPCamera : MonoBehaviour
{
    public float mouseSensitivity;
    public GameObject player;
    public GameObject cameraHolder;
    public float movementSpeed;

    Vector3 moveDir;
    // Start is called before the first frame update
    void Start()
    {
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;
        float horiz = Input.GetAxisRaw("Horizontal");
        float vert = Input.GetAxisRaw("Vertical");
    }

    // Update is called once per frame
    void LateUpdate()
    {
        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");

        transform.position = cameraHolder.transform.position;

        transform.localEulerAngles += new Vector3(mouseY*mouseSensitivity*-1, mouseX*mouseSensitivity, 0);
        player.transform.localEulerAngles += new Vector3(0, mouseX * mouseSensitivity, 0);

    }
    private void FixedUpdate()
    {
        moveDir = transform.TransformDirection(new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"))) * movementSpeed;
        player.gameObject.GetComponent<Rigidbody>().velocity = new Vector3(moveDir.x, player.gameObject.GetComponent<Rigidbody>().velocity.y, moveDir.z);
    }
}
