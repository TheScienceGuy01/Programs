using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    // Start is called before the first frame update
    public GameObject target;
    public float movementSpeed;
    public bool isActive = true;

    // Update is called once per frame
    void Update()
    {
        transform.LookAt(target.transform);
    }

    // FixedUpdate is called depending on framerate
    private void FixedUpdate()
    {
        if (isActive)
        {
            gameObject.GetComponent<Rigidbody>().velocity = transform.forward * movementSpeed;
        }
    }

    //Called when a collsion occurs
    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            isActive = false;
        }
    }
}
