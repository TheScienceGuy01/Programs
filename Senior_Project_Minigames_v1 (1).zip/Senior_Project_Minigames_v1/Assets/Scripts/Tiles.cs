using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tiles : MonoBehaviour
{
    public GameObject greenCube;
    public GameObject instantiatedCude;
    public bool isNode;
    public bool canStay;
    public bool isBlock;
    public GameObject NPC;


    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player") && !isNode)
        {
            Debug.Log("Should have instantiated");
            instantiatedCude = Instantiate(greenCube, transform.position, transform.rotation);
        }
        if (other.gameObject.CompareTag("Node") && isNode && canStay && other.gameObject.GetComponent<Tiles>().canStay != true)
        {
            for (int i = 0; i < 8; i++)
            {
                if (NPC.GetComponent<NPCManger>().costNodesList[i].gameObject == other.gameObject)
                {
                    NPC.GetComponent<NPCManger>().costForNull[i] = 99;
                }
            }
            Destroy(other.gameObject);
        }
        if (other.gameObject.CompareTag("Node") && isBlock)
        {
            for (int i = 0; i <8; i++)
            {
                if (NPC.GetComponent<NPCManger>().costNodesList[i].gameObject == other.gameObject)
                {
                    NPC.GetComponent<NPCManger>().costForNull[i] = 99;
                }
            }
            Destroy(other.gameObject);
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Destroy(instantiatedCude);
        }
    }
}
