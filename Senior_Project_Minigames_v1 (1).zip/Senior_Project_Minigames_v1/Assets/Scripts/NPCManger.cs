using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using TMPro;

public class NPCManger : MonoBehaviour
{
    public GameObject target;
    public GameObject costNodes;
    public GameObject nextNode;
    public GameObject TnextNode;
    public GameObject currentCostNode;
    public GameObject[] costNodesList;
    public float[] costForNull;
    int listIndex = 0;
    // Start is called before the first frame update
    private void Start()
    {
        nextNode = transform.gameObject;
        Tiles();
    }
    void Tiles()
    {
        if (nextNode != null && Vector2.Distance(target.transform.position, nextNode.transform.position) > .05)
        {
            currentCostNode = Instantiate(costNodes, new Vector2(nextNode.transform.position.x + 1, nextNode.transform.position.y + 1), costNodes.transform.rotation);
            Update_Text();
            currentCostNode = Instantiate(costNodes, new Vector2(nextNode.transform.position.x - 1, nextNode.transform.position.y - 1), costNodes.transform.rotation);
            Update_Text();
            currentCostNode = Instantiate(costNodes, new Vector2(nextNode.transform.position.x - 1, nextNode.transform.position.y + 1), costNodes.transform.rotation);
            Update_Text();
            currentCostNode = Instantiate(costNodes, new Vector2(nextNode.transform.position.x + 1, nextNode.transform.position.y - 1), costNodes.transform.rotation);
            Update_Text();
            currentCostNode = Instantiate(costNodes, new Vector2(nextNode.transform.position.x + 1, nextNode.transform.position.y), costNodes.transform.rotation);
            Update_Text();
            currentCostNode = Instantiate(costNodes, new Vector2(nextNode.transform.position.x, nextNode.transform.position.y + 1), costNodes.transform.rotation);
            Update_Text();
            currentCostNode = Instantiate(costNodes, new Vector2(nextNode.transform.position.x - 1, nextNode.transform.position.y), costNodes.transform.rotation);
            Update_Text();
            currentCostNode = Instantiate(costNodes, new Vector2(nextNode.transform.position.x, nextNode.transform.position.y - 1), costNodes.transform.rotation);
            Update_Text();
            listIndex = 0;

            TnextNode = costNodesList[0];
            for (int i = 0; i < 8; i++)
            {
                if (costNodesList != null)
                {
                    costNodesList[i].GetComponent<BoxCollider2D>().enabled = false;
                    costNodesList[i].GetComponent<BoxCollider2D>().enabled = true;
                    if ((Vector2.Distance(target.transform.position, costNodesList[i].transform.position) + Vector2.Distance(nextNode.transform.position, costNodesList[i].transform.position)) < (Vector2.Distance(target.transform.position, TnextNode.transform.position) + Vector2.Distance(nextNode.transform.position, TnextNode.transform.position)))
                    {
                        TnextNode = costNodesList[i];
                    }
                }
            }
            nextNode = TnextNode;
            nextNode.GetComponent<Tiles>().canStay = true;
        }
        if (nextNode == null)
        {
            float minVal = costForNull.Min();
            for (int i = 0; i < 8; i++)
            {
                if (costForNull[i] == minVal)
                {
                    nextNode = costNodesList[i];
                }
            }
        }
        StartCoroutine(Timer());
    }
    void Update_Text()
    {
        costNodesList[listIndex] = currentCostNode;
        currentCostNode.gameObject.transform.GetChild(0).gameObject.GetComponent<TextMeshPro>().text = (Vector2.Distance(nextNode.transform.position, currentCostNode.transform.position)).ToString("F2");
        currentCostNode.gameObject.transform.GetChild(1).gameObject.GetComponent<TextMeshPro>().text = (Vector2.Distance(target.transform.position, currentCostNode.transform.position)).ToString("F2");
        currentCostNode.gameObject.transform.GetChild(2).gameObject.GetComponent<TextMeshPro>().text = (Vector2.Distance(target.transform.position, currentCostNode.transform.position) + Vector2.Distance(nextNode.transform.position, currentCostNode.transform.position)).ToString("F2");
        costForNull[listIndex] = Vector2.Distance(target.transform.position, currentCostNode.transform.position) + Vector2.Distance(nextNode.transform.position, currentCostNode.transform.position);
        listIndex += 1;
    }
    IEnumerator Timer()
    {
        yield return new WaitForSeconds(1);
        if (nextNode != null)
        {
            for (int i = 0; i < 8; i++)
            {
                if (costNodesList[i] != null)
                {
                    costNodesList[i].GetComponent<Tiles>().canStay = true;
                }
            }
            nextNode.GetComponent<SpriteRenderer>().sortingOrder = 2;
            nextNode.GetComponent<SpriteRenderer>().color = Color.blue;
        }
        Tiles();
    }
}
