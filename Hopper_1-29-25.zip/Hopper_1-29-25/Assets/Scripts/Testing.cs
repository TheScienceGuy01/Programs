using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Testing : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        // Get the SpriteRenderer component
        SpriteRenderer spriteRenderer = GetComponent<SpriteRenderer>();

        if (spriteRenderer != null)
        {
            // Get the sprite's bounds
            Bounds bounds = spriteRenderer.sprite.bounds;

            // Calculate the height of the sprite
            float spriteHeight = bounds.size.y;

            // Log the height to the console
        }
        else
        {
            Debug.LogError("No SpriteRenderer found on this GameObject.");
        }
    }
}
