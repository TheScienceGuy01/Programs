using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Structure_Gen : MonoBehaviour
{
    /*====================================================================================================
     * Date: 7/8/24
     * Author: Israel Irizarry
     * Purpose: This is a multipurpose script that is used for all structure generation. This includes
     *     background filling, skeleton filling, and pole generation.
     * 
     * Updates:
     * 
     * Notes:
     *      1. Make it a choice to use poles or not.
     *      2. Make a better way to do filling. Maybe choose to avoid using collider objects.
     *      3. Make more crumbs be checkers for more crumbs can get out of the way.
     * ====================================================================================================
    */

    public bool isSkeleton;
    public bool foundCrumb;
    public bool hitSkel;
    public bool isPoleSpawner;
    public bool stopPole;
    public bool isBlank;
    public bool isCollisionDetector;
    public bool isCrumb;
    public bool isBackgroundBlank;
    public bool canSpawnCollider;
    public bool isColliderParent;
    public bool isFiller;

    public GameObject closestSensor;
    public GameObject poleCrumb;
    public GameObject spawned1;
    public GameObject centerCrumb;
    public GameObject skelParent;
    public GameObject glossary;
    public GameObject colliderHolder;
    public GameObject parentGameobject;
    public GameObject otherStruct;
    public GameObject backgroundFiller;
    public GameObject collisionFillerChecker;
    public GameObject sensorFIller;


    public int crumbID;
    public float sensorID;
    public int index;

    public List<GameObject> objectsInRange = new List<GameObject>();
    public List<GameObject> fillerInRange = new List<GameObject>();


    private GameObject spawned;
    private bool hasTriggered = false;
    private float minDist = 1000;


    private void Start()
    {
        //If the object is not a crumb and not a collision gameobject...
        if (isCollisionDetector == false && isCrumb == false && isFiller == false)
        {

            if (isBlank == true)
            {
                if (isColliderParent == false)
                {
                    transform.parent.transform.parent.GetComponent<Structure_Skeleton>().canCont = true;
                }
                StartCoroutine(Clean_Up());
            }

            //Spawns blank crumbs.
            if (isPoleSpawner == false && isSkeleton == false && isColliderParent == false && isCollisionDetector == false)
            {
                foundCrumb = false;
                hitSkel = false;
                sensorID = Random.value;
                StartCoroutine(Spawn_Next());
            }

            //Initiates pole generation if needed.
            if (isPoleSpawner == true)
            {
                minDist = 1000;
                objectsInRange.Clear();
                closestSensor = null;
                centerCrumb = transform.parent.transform.parent.GetComponent<Structure_Skeleton>().centerCrumb;
                StartCoroutine(Spawn_Pole());
            }
        }

        if (isCollisionDetector == true)
        {
            sensorID = Random.value;
            canSpawnCollider = true;
            StartCoroutine(Spawn_Next_Filler());
        }

        if (isColliderParent == true)
        {
            foreach (Transform child in transform)
            {
                if (child.name != "Sensor1")
                {
                    child.gameObject.SetActive(true);
                }
            }
            StartCoroutine(Clean_Up_Filler());
        }

        //Starts smoothing process if it is a crumb.
        if (isCrumb == true)
        {
            StartCoroutine(Smoothing(gameObject));
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        //If the pole spawner hits a crumb object, it stops generating the pole.
        if (other.gameObject.CompareTag("Crumb") && isPoleSpawner == true)
        {
            stopPole = true;
        }

        //Destroys crumbs if collision detector object collides.
        if (isCollisionDetector == true && (other.gameObject.CompareTag("HillCrumb") || other.gameObject.CompareTag("Crumb")))
        {
            Destroy(other.gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isFiller == true && other.gameObject.CompareTag("Sensor2"))
        {
            fillerInRange.Add(other.gameObject);
            
            StartCoroutine(Delay());
        }

        //If the collision detector object is triggered by an already spawned dressing object, then it is destroyed.
        if (isColliderParent == true && (other.gameObject.CompareTag("NoOverlap") || other.gameObject.CompareTag("Crumb") || other.CompareTag("HillCrumb")))
        {
            Destroy(other.gameObject);
        }

        if (isCollisionDetector == true && (other.gameObject.CompareTag("Structure_Crumb") || other.gameObject.CompareTag("Structure_Skeleton")))
        {
            canSpawnCollider = false;
        }
        if (isCollisionDetector == true && !other.gameObject.CompareTag("Structure_Crumb") && !other.gameObject.CompareTag("Structure_Skeleton") && other.gameObject.CompareTag("Sensor2"))
        {
            if (other.gameObject.GetComponent<Structure_Gen>().sensorID < sensorID)
            {
                other.gameObject.GetComponent<Structure_Gen>().canSpawnCollider = false;
                other.gameObject.SetActive(false);
            }
        }

        //Performs checks to see if a blank crumb can spawn.
        if (isBlank == false && isSkeleton == false && isCollisionDetector == false && isCrumb == false)
        {

            if (isPoleSpawner == false)
            {
                //If there are 2 sensors in the same position it deletes 1 to avoid duplicate blank crumbs.
                if (!isSkeleton && other.gameObject.CompareTag("Sensor2"))
                {
                    if (sensorID > other.GetComponent<Structure_Gen>().sensorID)
                    {
                        other.gameObject.SetActive(false);
                    }
                }

                //Does not generate a crumb at the sensor's position if hit a crumb.
                if (!isSkeleton && !isColliderParent && !isCollisionDetector && other.gameObject.CompareTag("Structure_Crumb") && other.gameObject != transform.parent.gameObject)
                {
                    foundCrumb = true;
                }

                //Checks if it hit a skeleton object. If so, then it proceeds to the spawning process for blank crumbs.
                if (!isSkeleton && other.gameObject.GetComponent<Structure_Gen>() != null)
                {
                    if (other.CompareTag("Structure_Skeleton") && other.GetComponent<Structure_Gen>().crumbID != 0)
                    {
                        hitSkel = true;
                        otherStruct = other.gameObject;
                    }
                    if (other.CompareTag("Structure_Skeleton") && other.GetComponent<Structure_Gen>().crumbID == 0 && hitSkel == false)
                    {
                        hitSkel = true;
                        otherStruct = other.gameObject;

                    }
                }

                //Allows for the Spawn_Next coroutine to start.
                hasTriggered = true;
            }
            else
            {
                //If the object is a sensor for pole generation, then it checks what objects the next pole crumb can spawn at.
                if ((other.CompareTag("Sensor2") || other.CompareTag("Sensor_Pole")) && stopPole == false)
                {
                    objectsInRange.Add(other.gameObject);
                }

                //Allows for the Spawn_Pole coroutine to start.
                hasTriggered = true;
            }
        }
    }

    IEnumerator Delay()
    {
        float dist = 0;
        if (gameObject.transform.parent.gameObject != null)
        {
            foreach (GameObject x in fillerInRange)
            {
                if (Vector2.Distance(x.transform.position, centerCrumb.transform.position) > dist)
                {
                    dist = Vector2.Distance(x.transform.position, centerCrumb.transform.position);
                    sensorFIller = x;
                }
            }
            spawned = Instantiate(collisionFillerChecker, sensorFIller.transform.position, sensorFIller.transform.rotation);

            yield return new WaitForSeconds(3);
            spawned.transform.gameObject.SetActive(true);
            Destroy(gameObject.transform.parent.gameObject);
        }
    }
    IEnumerator Clean_Up()
    {
        /*
         * Called for blank crumbs to despawn quickly.
        */

        if (isBlank == true)
        {
            yield return new WaitForSeconds(1f);
            yield return new WaitForFixedUpdate();

        }

        Destroy(gameObject);
    }

    IEnumerator Spawn_Pole()
    {
        /*
         * This is used for the continual spawning of blank and pole crumbs.
        */


        yield return new WaitUntil(() => hasTriggered);

        //For poles to check what object is closest to the center of the planet.
        foreach (GameObject obj in objectsInRange)
        {
            if (obj != null)
            {
                float distance = Vector3.Distance(obj.transform.position, transform.position);
                if (distance < minDist)
                {
                    closestSensor = obj.gameObject;
                    minDist = distance;
                }
            }
        }

        //After choosing an object to spawn another pole crumb at it spawns the new pole crumb.
        if (closestSensor != null)
        {
            spawned = Instantiate(poleCrumb, closestSensor.transform.position, closestSensor.transform.rotation);
            StartCoroutine(Smoothing(spawned));
            centerCrumb.GetComponent<Collider_Generator>().initialColliderChecks.Add(spawned);
            spawned.transform.parent = centerCrumb.transform.GetChild(3);
            spawned1 = Instantiate(transform.parent.transform.parent.gameObject, closestSensor.transform.position, closestSensor.transform.rotation);
            spawned1.transform.parent = transform.parent.transform.parent.transform.parent;
            yield return new WaitForSeconds(.5f);
            //centerCrumb.GetComponent<Collider_Generator>().initialColliderChecks.Remove(spawned);
        }
        yield return new WaitForFixedUpdate();

        //Destroys parent object as it is not needed for spawning anymore.
        Destroy(gameObject.transform.parent.transform.parent.gameObject);
    }

    IEnumerator Spawn_Next()
    {
        /*
         * Used for spawning the next blank crumbs for outlines and filling of structures.
        */

        yield return new WaitUntil(() => hasTriggered);

        //If the object is able spawn it, then it will.
        if (foundCrumb == false && hitSkel == true)
        {
            //This is for spawning background crumbs.
            spawned = Instantiate(parentGameobject, transform.position, transform.parent.rotation);
            if (otherStruct.GetComponent<Structure_Gen>().crumbID == 0)
            {
                spawned.GetComponent<Structure_Gen>().isBackgroundBlank = true;
            }
            spawned.transform.parent = transform.parent.transform.parent;

            //Sets all the children to active for the new blank crumb.
            foreach (Transform child in spawned.transform)
            {
                if (child.name != "Sensor1")
                {
                    child.gameObject.SetActive(true);
                }
            }

            //Searches for the correct crumb to spawn in place of the blank crumb using the glossary gameobject.
            for (int i = 0; i < glossary.GetComponent<Structure_Skeleton>().glossary.Length; i++)
            {
                if (otherStruct.GetComponent<Structure_Gen>().crumbID == i)
                {
                    spawned1 = Instantiate(glossary.GetComponent<Structure_Skeleton>().glossary[i], transform.position, transform.rotation);

                    spawned1.transform.parent = transform.parent.transform.parent;

                    spawned1.gameObject.SetActive(true);
                }
            }
        }

        //Destroys skeleton crumbs as the blank crumbs outline the edges of the structure.
        if (otherStruct != null && otherStruct.gameObject.GetComponent<Structure_Gen>() != null)
        {
            if (otherStruct.gameObject.GetComponent<Structure_Gen>().isCollisionDetector == false)
            {
                Destroy(otherStruct.gameObject);
            }
        }
    }
    IEnumerator Smoothing(GameObject obj)
    {
        //Smoothes out the outline crumbs.

        yield return new WaitForSeconds(.5f);
        yield return new WaitForFixedUpdate();
        obj.GetComponent<Planet_Generation>().isBroken = true;
        yield return new WaitForSeconds(.5f);
        yield return new WaitForFixedUpdate();
        Destroy(transform.GetComponent<Structure_Gen>());
    }

    IEnumerator Spawn_Next_Filler()
    {
        yield return new WaitForSeconds(.01f);
        if (canSpawnCollider == true)
        {

            spawned = Instantiate(transform.parent.gameObject, transform.position, transform.rotation);
            Instantiate(backgroundFiller, spawned.transform.position, spawned.transform.rotation);

            yield return new WaitForEndOfFrame();
            //Destroy(gameObject);
        }
        else
        {
            transform.gameObject.SetActive(false);
        }

    }

    IEnumerator Clean_Up_Filler()
    {
        yield return new WaitForSeconds(3f);
        foreach (Transform child in transform)
        {
            if (child.name != "Sensor1")
            {
                Destroy(child.gameObject);
            }
        }
        Destroy(gameObject);
    }

    private void FixedUpdate()
    {
        if (isSkeleton == true && skelParent.GetComponent<Structure_Skeleton>() == null)
        {
            Destroy(gameObject);
        }
    }
}

