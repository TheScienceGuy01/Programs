using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*====================================================================================================
 * Date: 7/12/24
 * Author: Israel Irizarry
 * Purpose: This is a multipurpose script that is used for all structure generation. This includes
 *     background filling, skeleton filling, and pole generation.
 * 
 * Updates:
 * 
 * Notes:
 *      
 * 
 * ====================================================================================================
*/

[System.Serializable]
public class Structure
{
    //Lines properties.

    public bool clearInside;
    public float lineLength;
    public float angle;
    public Vector3 originalSpawn;
    public GameObject dot;
    public float dotSpacing;
}

public class Structure_Skeleton : MonoBehaviour
{

    public List<Structure> line = new List<Structure>();

    public int currentLength;
    public int colliderDistance;

    public GameObject spawner;
    private GameObject spawned;
    private GameObject spawned3;
    public GameObject blankCrumb;
    public GameObject[] glossary;
    public GameObject corner;
    public GameObject centerCrumb;
    public GameObject colliderHolder;
    public GameObject initialCrumb;
    public GameObject distanceChecker;
    public GameObject fillSpawner;

    public bool isGlossary;
    public bool isParent;
    public bool isPole;
    public bool isStationary;
    public bool canCont;
    public bool isDistanceChecked;
    public bool cansSpawnFiller;

    private float angleTemp;
    private bool initialize = false;
    private Vector3 offset;
    private bool isFirst;
    private GameObject spawned1;

    public float ogDistance;

    private void Start()
    {
        //If the transform is not a pole object, then this affects skeleton and glossary objects.
        if (isPole == false)
        {
            //If is the parent, then it sets the location object (first child), enables the second, and starts the checker to see if the structure is done generating.
            if (isParent)
            {
                Vector3 ogPos = transform.position;
                transform.position = transform.parent.transform.parent.transform.position;
                transform.GetChild(0).position = ogPos;
                transform.GetChild(1).gameObject.SetActive(true);
                StartCoroutine(Done_Generating());

            }
            else
            {
                corner = transform.parent.GetChild(3).transform.gameObject;
            }


            if (!isGlossary && !isParent)
            {
                centerCrumb = transform.parent.transform.parent.transform.parent.transform.gameObject;
                initialCrumb = Instantiate(line[0].dot, spawner.transform.GetChild(0).transform.position, spawner.transform.GetChild(0).transform.rotation);
                initialCrumb.GetComponent<Structure_Gen>().skelParent = transform.parent.gameObject;
                bool canContinue = centerCrumb.GetComponent<Structure_Distance_Checker>().Checking(initialCrumb.transform.position);
                if (canContinue == false)
                {
                    Destroy(transform.parent.gameObject);
                    Destroy(gameObject);
                    return;
                }
                else
                {
                    initialCrumb.gameObject.SetActive(true);
                }


                for (int i = 0; i < line.Count; i++)
                {
                    angleTemp = line[i].angle;

                    if (i != 0)
                    {
                        spawner.transform.GetChild(0).transform.position = line[i - 1].originalSpawn;
                    }

                    if (line[i].dotSpacing != 0)
                    {

                        line[i].lineLength *= Vector2.Distance(spawner.transform.position, spawner.transform.GetChild(0).transform.position) / centerCrumb.transform.GetComponent<Planet_Generation>().planetRadius;
                        line[i].dotSpacing /= (Vector2.Distance(spawner.transform.position, spawner.transform.GetChild(0).transform.position) / ogDistance);
                    }

                    cansSpawnFiller = false;
                    int counter = 0;
                    while (currentLength < line[i].lineLength)
                    {
                        counter += 1;
                        if (line[i].dotSpacing == 0)
                        {
                            spawner.transform.Rotate(0, 0, line[i].dotSpacing);
                        }
                        else
                        {
                            spawner.transform.Rotate(0, 0, line[i].dotSpacing);
                        }
                        spawned = Instantiate(line[i].dot, spawner.transform.GetChild(0).transform.position, spawner.transform.GetChild(0).transform.rotation);
                        spawned.GetComponent<Structure_Gen>().skelParent = transform.parent.gameObject;
                        spawned.gameObject.SetActive(true);
                        Vector3 newPosition = offset + spawned.transform.position + spawned.transform.up * angleTemp;
                        if (angleTemp != 0)
                        {
                            angleTemp += line[i].angle;
                        }
                        spawned.transform.position = newPosition;
                        if (currentLength == (int)(line[i].lineLength/2) && cansSpawnFiller == false && line[i].clearInside == true)
                        {
                            cansSpawnFiller = true;
                            spawned3 = Instantiate(fillSpawner, spawned.transform.position, spawned.transform.rotation);
                            spawned3.transform.GetChild(0).GetComponent<Structure_Gen>().centerCrumb = centerCrumb;
                            spawned3.gameObject.SetActive(true);
                        }
                        spawned.GetComponent<Structure_Gen>().index = currentLength;
                        currentLength += 1;

                    }
                    if (i == 0)
                    {
                        spawned1 = Instantiate(corner.gameObject, spawned.transform.position, corner.transform.rotation);
                        spawned1.GetComponent<Structure_Skeleton>().centerCrumb = centerCrumb;
                        spawned1.SetActive(true);
                        centerCrumb.GetComponent<Collider_Generator>().initialColliderChecks.Add(spawned1);
                    }
                    line[i].originalSpawn = spawned.transform.position;

                    currentLength = 0;
                    StartCoroutine(Spawn_Crumb(blankCrumb, initialCrumb.transform.position));

                }
            }
        }

        //
        if (isPole == true && centerCrumb != null)
        {
            Vector3 direction = transform.GetChild(1).transform.position - centerCrumb.transform.position;
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
            transform.GetChild(1).transform.rotation = Quaternion.Euler(0f, 0f, angle+90);
        }
    }

    IEnumerator Spawn_Crumb(GameObject spawnedObj, Vector3 spawnLocation)
    {
        yield return new WaitForSeconds(.1f);
        if (initialize == false)
        {
            initialize = true;
            spawned = Instantiate(spawnedObj, spawnLocation, spawnedObj.transform.rotation);
            spawned.transform.parent = transform.parent.GetChild(2);
            spawned.SetActive(true);
            spawned1 = Instantiate(corner.gameObject, spawnLocation, spawnedObj.transform.rotation);
            spawned1.GetComponent<Structure_Skeleton>().centerCrumb = centerCrumb;
            spawned1.SetActive(true);
            centerCrumb.GetComponent<Collider_Generator>().initialColliderChecks.Add(spawned1);
        }
    }

    IEnumerator Done_Generating()
    {
        yield return new WaitForSeconds(1);
        if (canCont == true)
        {
            canCont = false;
        }
        else
        {
            Debug.Log("Ended Generation");
            Destroy(transform.GetComponent<Structure_Skeleton>());
        }
        StartCoroutine(Done_Generating());
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isPole == true && other.CompareTag("Structure_Crumb") && isStationary == false)
        {
            isStationary = true;
            foreach (Transform child in gameObject.transform)
            {
                child.gameObject.SetActive(true);
            }
            transform.position = other.transform.position;
            transform.rotation = other.transform.rotation;
        }
    }
}
