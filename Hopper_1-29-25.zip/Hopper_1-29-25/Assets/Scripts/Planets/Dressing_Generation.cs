using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dressing_Generation : MonoBehaviour
{
    public bool canDestroyCrumbs;
    public bool doNotSpawnIfCrumbsInWay;
    public float identifier;

    private void Start()
    {
        identifier = Random.value;
        StartCoroutine(Double_Check_Spawns());
    }
    IEnumerator Double_Check_Spawns()
    {
        yield return new WaitForSeconds(.1f);
        transform.Translate(Vector3.up * 0.01f); //Move the object slightly up

    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (doNotSpawnIfCrumbsInWay == true)
        {

            if (other.gameObject.CompareTag("Crumb") || (other.gameObject.CompareTag("NoOverlap") && identifier <= other.gameObject.GetComponent<Dressing_Generation>().identifier))
            {
                Destroy(gameObject);
            }
        }
        if (canDestroyCrumbs == true)
        {
            if (other.gameObject.CompareTag("Crumb"))
            {
                Destroy(other.gameObject);
            }
        }
    }
}
