using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cave_Generation : MonoBehaviour
{
    public float length;
    public float width;
    public int direction;
    private GameObject spawned;
    public bool initialized;
    public float chaosValue;

    private void Start()
    {
        width = Random.Range(.5f, 2f);
        if (initialized == false)
        {
            direction = Random.Range(0, 6);
            initialized = true;
        }
        else
        {
            float randVal = Random.value;
            if (direction == 0 && randVal > 1 - chaosValue / 100)
            {
                if (Random.value > .5f)
                {
                    direction = 1;
                }
                else
                {
                    direction = 5;
                }
            }
            else if (direction == 5 && randVal > 1 - chaosValue / 100)
            {
                if (Random.value > .5f)
                {
                    direction = 0;
                }
                else
                {
                    direction = 4;
                }
            }
            else if (direction != 5 && direction != 0 && randVal > 1 - chaosValue / 100)
            {
                if (Random.value > .5f)
                {
                    direction -= 1;
                }
                else
                {
                    direction += 1;
                }
            }
        }
        if (length > 0)
        {
            length -= 1;
            spawned = Instantiate(gameObject, transform.GetChild(direction).transform.position, transform.rotation);
            spawned.transform.parent = transform.parent;
        }
    }

    private void Update()
    {
        // Define the angles for the 8 directions
        float[] angles = { 0f, 45f, 90f, 135f, 180f, 225f, 270f, 315f };

        // Loop through each angle
        foreach (float angle in angles)
        {
            // Convert the angle to radians
            float radians = angle * Mathf.Deg2Rad;

            // Calculate the direction vector based on the angle
            Vector2 direction = new Vector2(Mathf.Cos(radians), Mathf.Sin(radians));

            // Cast a ray in the calculated direction
            RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, width);

            if (hit.collider != null)
            {
                // Check if the hit object has the tag "hill"
                if (hit.collider.CompareTag("Crumb"))
                {
                    Destroy(hit.collider.gameObject);
                }
            }

            RaycastHit2D hit1 = Physics2D.Raycast(transform.position, direction, width+1f);

            if (hit1.collider != null)
            {
                // Check if the hit object has the tag "hill"
                if (hit1.collider.CompareTag("Crumb") && !hit1.collider.name.Contains("Triangle Smoothing"))
                {
                    hit1.transform.GetComponent<Planet_Generation>().isSurface = false;
                    transform.parent.transform.parent.GetComponent<Crumb_Smoothing>().caveCrumbsList.Add(hit1.transform.gameObject);
                }
            }
        }
    }
}
