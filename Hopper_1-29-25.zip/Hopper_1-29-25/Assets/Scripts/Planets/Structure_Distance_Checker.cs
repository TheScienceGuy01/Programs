using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Structure_Distance_Checker : MonoBehaviour
{

    /*====================================================================================================
     * Date: 7/7/24
     * Author: Israel Irizarry
     * Purpose: Checks the distance between structure spawns to make sure that they are the proper distance apart.
     * 
     * Updates:
     *  
     * 
     * ====================================================================================================
    */

    //List of structures to avoid.
    public List<Vector2> structurePos = new List<Vector2>();

    //Checks if the newly spawned object can continue.
    public bool canCont;
    public int distance1;

    public bool Checking(Vector2 objPos)
    {
        /*====================================================================================================
         * Purpose: Check if a newly spawned structure object can be placed given a distance.
         * ====================================================================================================
         */


        canCont = true;

        //If there is an object in the way it returns a false value.
        foreach (Vector2 pos in structurePos)
        {
            if (Vector2.Distance(objPos, pos) < distance1)
            {
                canCont = false;
            }
        }

        //If there are no objects in the structurePos list, then add the first item.
        if (structurePos.Count == 0)
        {
            structurePos.Add(objPos);
        }

        //Returns value.
        if (canCont == false)
        {
            return false;
        }
        else
        {
            structurePos.Add(objPos);
            return true;
        }
    }

}
