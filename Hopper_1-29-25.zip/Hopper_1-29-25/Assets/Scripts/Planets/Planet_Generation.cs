using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

[System.Serializable]
public class OreData1
{
    public Color ore;
    public int size;
    public GameObject shape;
    public float percentageChanged;
    public float spawnRate;
}
[System.Serializable]

public class StructureData1
{
    public GameObject structure;
    public float spawnRate;
}
[System.Serializable]
public class CrumbTemplates
{
    public int crumbType;
    public Color crumbColor;
    public List<OreData1> oreSpawns = new List<OreData1>();
    public List<StructureData1> structureSpawns = new List<StructureData1>();
    public List<RowData> Dressing = new List<RowData>();
}
public class Planet_Generation : MonoBehaviour
{
    public int planetRadius;
    public bool isRoot;
    public bool isParent;
    private GameObject spawned;
    public GameObject rootCrumb;
    public int ringRadius;
    public int ringCount;
    public int circleRadius;
    public bool isStem;
    public GameObject crumb;
    public Sprite[] crumbSprites;
    public float[] layerPercentages;
    public float[] layers;
    public float[] crumbChaosDegree;
    public bool isSurface;
    public bool isDestroyed;
    public int surfaceNoise;
    public float crumbDistance;
    public float[] noiseValue;
    public float randValue;
    public float hillSpawnRate;
    public GameObject hillSeed;
    public float currentDistance;
    public GameObject pointer;
    public float surfaceCastDistance;
    public bool upHill;
    public int hillUpperCount;
    public int hillLowerCount;
    public float[] hillTypeRarity;
    public float crustThickness;
    public GameObject crumbSmoothingTriangle;
    public bool isBroken;
    public int[] hitList;
    public float caveSpawnRate;
    public GameObject caveSeed;
    public List<GameObject> adjacentCrumbs = new List<GameObject>();
    public float planetBorderx2;
    public GameObject planet_Templates;
    public float planetBorder;
    public int template;
    public bool isReset;

    public List<CrumbTemplates> crumbTemplate = new List<CrumbTemplates>();
    void Start() {
        if (!transform.CompareTag("Structure_Crumb"))
        {
            //Main Generation
            if (isRoot == true)
            {
                Planet_Generation parentGen = transform.parent.GetComponent<Planet_Generation>();
                planetRadius = transform.parent.GetComponent<Planet_Generation>().planetRadius * 2;
                //GetComponent<Crumb_Info>().crumbLayer = 0;
                isSurface = false;
                //Debug.Log(GetComponent<SpriteRenderer>().sprite.bounds.size.y); 16/17

                //Spawns the initializing stem crumbs.
                foreach (Transform child in transform)
                {
                    spawned = Instantiate(crumb.gameObject, child.position, child.rotation);
                    spawned.GetComponent<Planet_Generation>().ringRadius = 0;
                    spawned.GetComponent<Planet_Generation>().planetRadius = planetRadius;
                    spawned.GetComponent<Planet_Generation>().isStem = true;
                    spawned.transform.parent = transform.parent;
                    spawned.name = "Stem_Crumb";
                    transform.parent.GetComponent<Crumb_Smoothing>().crumbList.Add(spawned);
                    transform.parent.GetComponent<Crumb_Smoothing>().crumbCount++;
                }
            }
            else
            {
                //crumbSmoothingTriangle = transform.parent.GetComponent<Planet_Generation>().crumbSmoothingTriangle;
                if (isParent == false)
                {
                    crumbSmoothingTriangle = transform.parent.GetComponent<Planet_Generation>().crumbSmoothingTriangle;

                    //-------------------------------------------------------
                    //
                    //Crumb Spawning
                    //
                    //-------------------------------------------------------

                    //Creates the stems and initializes the ring crumbs.
                    ringRadius += 1;
                    if (isStem == true)
                    {
                        ringCount = ringRadius - 1;
                        if (ringCount > 0)
                        {
                            spawned = Instantiate(gameObject, transform.GetChild(1).transform.position, transform.rotation);
                            spawned.GetComponent<Planet_Generation>().isStem = false;
                            spawned.transform.parent = transform.parent;
                            spawned.GetComponent<Planet_Generation>().isSurface = isSurface;
                            spawned.name = "Crumb";
                            transform.parent.GetComponent<Crumb_Smoothing>().crumbList.Add(spawned);
                            transform.parent.GetComponent<Crumb_Smoothing>().crumbCount++;
                        }
                    }
                    if (ringRadius < planetRadius && isStem)
                    {
                        spawned = Instantiate(gameObject, transform.GetChild(0).transform.position, transform.rotation);
                        spawned.transform.parent = transform.parent;
                        spawned.GetComponent<Planet_Generation>().ringCount = ringCount;
                        spawned.GetComponent<Planet_Generation>().isSurface = isSurface;
                        transform.parent.GetComponent<Crumb_Smoothing>().crumbList.Add(spawned);
                        transform.parent.GetComponent<Crumb_Smoothing>().crumbCount++;
                    }

                    //Completes the rings after the initial crumb.
                    ringCount -= 1;
                    if (ringCount > 0 && isStem == false)
                    {
                        spawned = Instantiate(gameObject, transform.GetChild(1).transform.position, transform.rotation);
                        spawned.transform.parent = transform.parent;
                        spawned.GetComponent<Planet_Generation>().isSurface = isSurface;
                        spawned.name = "Crumb";
                        transform.parent.GetComponent<Crumb_Smoothing>().crumbList.Add(spawned);
                        transform.parent.GetComponent<Crumb_Smoothing>().crumbCount++;

                    }

                    //All crumbs execute this---------------------------------------------------------------------------------------------

                    //Distance Checking.
                    crumbDistance = Vector3.Distance(transform.position, transform.parent.transform.position);
                    planetBorder = ((transform.parent.GetComponent<Planet_Generation>().planetRadius) * Mathf.Sqrt(3)) / 2.2f;
                    Planet_Generation parentGen = transform.parent.GetComponent<Planet_Generation>();
                    planetBorderx2 = planetBorder * 1.1f;
                    if (planetBorderx2 * (parentGen.layerPercentages[0] / 100) > crumbDistance)
                    {
                        GetComponent<Crumb_Info>().crumbLayer = 0;
                        isSurface = false;

                        float layerDistance = planetBorderx2 * (parentGen.layerPercentages[0] / 100);
                        if (crumbDistance / layerDistance > parentGen.noiseValue[0])
                        {
                            randValue = Random.Range(0, 100f) / 100f;
                            float chaos = 1 - crumbDistance / layerDistance;
                            if (randValue > chaos)
                            {
                                GetComponent<Crumb_Info>().crumbLayer = 1;
                                isSurface = false;
                            }
                        }

                    }
                    if (planetBorderx2 * (parentGen.layerPercentages[1] / 100) > crumbDistance && planetBorderx2 * (parentGen.layerPercentages[0] / 100) < crumbDistance)
                    {

                        GetComponent<Crumb_Info>().crumbLayer = 1;

                        isSurface = false;

                        float layerDistance = planetBorderx2 * (parentGen.layerPercentages[1] / 100);
                        if ((crumbDistance) / layerDistance > parentGen.noiseValue[1])
                        {
                            randValue = Random.Range(0, 100f) / 100f;
                            float chaos = 1 - crumbDistance / layerDistance;
                            if (randValue > chaos)
                            {
                                GetComponent<Crumb_Info>().crumbLayer = 2;
                                isSurface = false;

                            }
                        }
                    }
                    if (planetBorderx2 * (parentGen.layerPercentages[1] / 100) < crumbDistance)
                    {
                        GetComponent<Crumb_Info>().crumbLayer = 2;

                        isSurface = false;
                    }

                    if (crumbDistance > planetBorder)
                    {
                        if ((crumbDistance + 1 > planetBorder && crumbDistance - 1 < planetBorder))
                        {
                            isSurface = true;
                        }
                        if (crumbDistance - 1 > planetBorder)
                        {
                            spawned = Instantiate(transform.parent.GetComponent<Planet_Generation>().pointer, transform.position, transform.rotation);
                            spawned.transform.parent = transform;
                            pointer = spawned;
                            transform.parent.GetComponent<Crumb_Smoothing>().crumbList.Add(spawned);
                            transform.parent.GetComponent<Crumb_Smoothing>().crumbCount++;
                            // Assume 'arrow' is your arrow GameObject and 'target' is the object it should look at.
                            Vector3 direction = transform.parent.position - spawned.transform.position;
                            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
                            spawned.transform.rotation = Quaternion.Euler(0f, 0f, angle + 90); // Subtract 90 because the arrow is facing up
                                                                                               // Cast a ray upwards from the arrow's position
                            RaycastHit2D hit = Physics2D.Raycast(transform.position, transform.up, 100);

                            // Check if the ray hits something
                            if (hit.collider != null)
                            {
                                // Check if the hit object has the tag "hill"
                                if (hit.collider.CompareTag("HillCrumb"))
                                {
                                    upHill = true;
                                }
                            }
                            spawned.transform.rotation = Quaternion.Euler(0f, 0f, angle + 90 + 180);
                            // Calculate direction from this object to the planet
                            Vector2 directionToPlanet = transform.parent.position - transform.position;

                            // Normalize the direction to make it unit length
                            directionToPlanet.Normalize();
                            RaycastHit2D hit2 = Physics2D.Raycast(transform.position, directionToPlanet, parentGen.crustThickness);
                            RaycastHit2D hit3 = Physics2D.Raycast(transform.position, -directionToPlanet, parentGen.crustThickness);

                            // Check if the ray hits something
                            if (hit2.collider != null && hit2.collider.CompareTag("HillCrumb"))
                            {
                                isSurface = true;
                            }

                            Destroy(pointer.gameObject);
                            if (upHill == false)
                            {
                                if (isSurface && hit3.collider == null)
                                {
                                    GetComponent<Crumb_Info>().isSurface = true;
                                    transform.parent.GetComponent<Crumb_Smoothing>().crumbSurfaceList.Add(gameObject);
                                }
                                else
                                {
                                    isSurface = false;
                                    isDestroyed = true;
                                    Destroy(gameObject);

                                }
                            }
                            else
                            {
                                isSurface = false;
                            }
                            upHill = false;
                        }

                    }

                    //Spawns Caves
                    if (Random.value > 1 - transform.parent.GetComponent<Planet_Generation>().caveSpawnRate / 100 && isDestroyed == false)
                    {
                        spawned = Instantiate(transform.parent.GetComponent<Planet_Generation>().caveSeed, transform.position, transform.rotation);
                        spawned.transform.parent = transform.parent.GetChild(2);
                        spawned.GetComponent<Cave_Generation>().length = Random.Range(30, 45);
                        spawned.GetComponent<Cave_Generation>().chaosValue = Random.Range(10, 100);
                        spawned.GetComponent<Cave_Generation>().enabled = true;
                    }

                    //Initializing crumb type
                    switch (GetComponent<Crumb_Info>().crumbLayer)
                    {
                        case 0:
                            GetComponent<Crumb_Info>().crumbTemplate[0] = transform.parent.GetComponent<Planet_Generation>().crumbTemplate[0];
                            break;
                        case 1:
                            GetComponent<Crumb_Info>().crumbTemplate[0] = transform.parent.GetComponent<Planet_Generation>().crumbTemplate[1];
                            break;
                        case 2:
                            GetComponent<Crumb_Info>().crumbTemplate[0] = transform.parent.GetComponent<Planet_Generation>().crumbTemplate[2];
                            break;
                    }

                    if (GetComponent<Crumb_Info>().isSurface == true)
                    {
                        GetComponent<Crumb_Info>().crumbTemplate[0] = transform.parent.GetComponent<Planet_Generation>().crumbTemplate[3];
                    }
                }
                else
                {
                    crumbTemplate = planet_Templates.GetComponent<Planet_Templates>().planetTemplates[template].crumbTemplates;

                    for (int i = 0; i < GetComponent<Planet_Generation>().crumbTemplate.Count; i++)
                    {
                        if (GetComponent<Planet_Generation>().crumbTemplate[i] != null && GetComponent<Planet_Generation>().crumbTemplate[i].Dressing.Count != 0)
                        {
                            foreach (RowData dress in GetComponent<Planet_Generation>().crumbTemplate[i].Dressing)
                            {
                                GetComponent<Planet_Dressing>().rows.Add(dress);
                            }
                        }
                    }

                    //------------------------------------------
                    //
                    //Hill Spawns
                    //
                    //------------------------------------------

                    if (isSurface == false && hillUpperCount != 0)
                    {
                        layerPercentages[0] = Random.Range(0f, 70f);

                        noiseValue[0] = Random.Range(0f, 1f);
                        noiseValue[1] = Random.Range(.5f, 1f);
                        for (int i = 0; i < layerPercentages.Length; i++)
                        {
                            layers[i] = Mathf.Round(planetRadius * (layerPercentages[i] / 100));

                        }

                        //Hill Generation
                        for (int i = 0; i < Random.Range(hillLowerCount, hillUpperCount); i++)
                        {
                            float randHillSpawn = Random.value;
                            if (randHillSpawn < hillTypeRarity[0] / 100)
                            {
                                hillSeed = transform.GetChild(1).transform.gameObject;
                                spawned = Instantiate(hillSeed, transform.position, transform.rotation);
                                spawned.transform.parent = transform;
                                spawned.GetComponent<Hill_Generation>().hillType = 0;
                                spawned.GetComponent<Hill_Generation>().enabled = true;
                            }
                            if (randHillSpawn <= hillTypeRarity[1] / 100 && randHillSpawn >= hillTypeRarity[0] / 100)
                            {
                                hillSeed = transform.GetChild(1).transform.gameObject;
                                spawned = Instantiate(hillSeed, transform.position, transform.rotation);
                                spawned.transform.parent = transform;
                                spawned.GetComponent<Hill_Generation>().hillType = 1;
                                spawned.GetComponent<Hill_Generation>().enabled = true;
                            }
                            if (randHillSpawn > hillTypeRarity[1] / 100)
                            {
                                hillSeed = transform.GetChild(1).transform.gameObject;
                                spawned = Instantiate(hillSeed, transform.position, transform.rotation);
                                spawned.transform.parent = transform;
                                spawned.GetComponent<Hill_Generation>().hillType = 2;
                                spawned.GetComponent<Hill_Generation>().enabled = true;
                            }
                        }
                    }
                }
            }
        }
    }

    private void Update()
    {

        //Crumb Smoothing
        if (isBroken)
        {
            adjacentCrumbs.Clear();
            for (int i = 0; i < hitList.Length; i++)
            {
                hitList[i] = 0;
            }
            foreach (Transform child in transform)
            {
                if (child.name == "Triangle Smoothing(Clone)")
                {
                    Destroy(child.gameObject);
                }
            }
            foreach (Transform child in transform)
            {
                if (child.name != "Sensor1" && child.name != "Triangle Smoothing(Clone)" && !child.gameObject.name.Contains("Blank"))
                {
                    RaycastHit2D hit = Physics2D.Raycast(child.transform.position, child.transform.up, .1f, LayerMask.GetMask("CrumbLayer"));
                    Vector3 endPoint = child.transform.position + child.transform.up * .1f;

                    // If the ray hits something, adjust the end point
                    if (hit.collider != null)
                    {
                        endPoint = hit.point;
                    }
                    Debug.DrawLine(child.transform.position, endPoint, Color.red);

                    // Check if the ray hits something
                    if (hit.collider != null)
                    {
                        bool cont = true;
                        if (hit.collider.name.Contains("Blank"))
                        {

                            if (hit.collider.gameObject.GetComponent<Structure_Gen>().isBackgroundBlank == true)
                            {
                                cont = false;
                            }
                        }
                        if (cont == true)
                        {
                            switch (child.name)
                            {
                                case "Sensor":
                                    hitList[0] = 1;
                                    adjacentCrumbs.Add(hit.collider.gameObject);
                                    break;
                                case "Sensor_0":
                                    hitList[1] = 1;
                                    adjacentCrumbs.Add(hit.collider.gameObject);
                                    break;
                                case "Sensor_3":
                                    hitList[2] = 1;
                                    adjacentCrumbs.Add(hit.collider.gameObject);
                                    break;
                                case "Sensor_5":
                                    hitList[3] = 1;
                                    adjacentCrumbs.Add(hit.collider.gameObject);
                                    break;
                                case "Sensor_2":
                                    hitList[4] = 1;
                                    adjacentCrumbs.Add(hit.collider.gameObject);
                                    break;
                                case "Sensor_1":
                                    hitList[5] = 1;
                                    adjacentCrumbs.Add(hit.collider.gameObject);
                                    break;
                            }
                        }
                        //child.GetComponent<SpriteRenderer>().color = Color.blue;
                    }
                }
            }
            isBroken = false;
            if (hitList[0] == 1)
            {
                if (hitList[1] == 0)
                {
                    //transform.GetChild(2).GetComponent<SpriteRenderer>().color = Color.yellow;
                    SmoothingChangePos(transform.GetChild(2));
                }
                if (hitList[5] == 0)
                {
                    //transform.GetChild(6).GetComponent<SpriteRenderer>().color = Color.yellow;
                    transform.GetChild(6).localEulerAngles = new Vector3(0, 0, 120);
                    SmoothingChangePos(transform.GetChild(6));
                }

            }
            if (hitList[1] == 1)
            {
                if (hitList[0] == 0)
                {
                    //transform.GetChild(0).GetComponent<SpriteRenderer>().color = Color.yellow;
                    transform.GetChild(0).localEulerAngles = new Vector3(0, 0, 60);
                    SmoothingChangePos(transform.GetChild(0));
                }
                if (hitList[2] == 0)
                {
                    //transform.GetChild(3).GetComponent<SpriteRenderer>().color = Color.yellow;
                    SmoothingChangePos(transform.GetChild(3));
                }
            }
            if (hitList[2] == 1)
            {
                if (hitList[1] == 0)
                {
                    //transform.GetChild(2).GetComponent<SpriteRenderer>().color = Color.yellow;
                    transform.GetChild(2).localEulerAngles = new Vector3(0, 0, 0);
                    SmoothingChangePos(transform.GetChild(2));
                }
                if (hitList[3] == 0)
                {
                    //transform.GetChild(4).GetComponent<SpriteRenderer>().color = Color.yellow;
                    SmoothingChangePos(transform.GetChild(4));
                }
            }
            if (hitList[3] == 1)
            {
                if (hitList[2] == 0)
                {
                    //transform.GetChild(3).GetComponent<SpriteRenderer>().color = Color.yellow;
                    transform.GetChild(3).localEulerAngles = new Vector3(0, 0, -60);
                    SmoothingChangePos(transform.GetChild(3));
                }
                if (hitList[4] == 0)
                {
                    //transform.GetChild(5).GetComponent<SpriteRenderer>().color = Color.yellow;
                    SmoothingChangePos(transform.GetChild(5));
                }
            }
            if (hitList[4] == 1)
            {
                if (hitList[3] == 0)
                {
                    //transform.GetChild(4).GetComponent<SpriteRenderer>().color = Color.yellow;
                    transform.GetChild(4).localEulerAngles = new Vector3(0, 0, 240);
                    SmoothingChangePos(transform.GetChild(4));
                }
                if (hitList[5] == 0)
                {
                    //transform.GetChild(6).GetComponent<SpriteRenderer>().color = Color.yellow;
                    SmoothingChangePos(transform.GetChild(6));
                }
            }
            if (hitList[5] == 1)
            {
                if (hitList[4] == 0)
                {
                    //transform.GetChild(5).GetComponent<SpriteRenderer>().color = Color.yellow;
                    transform.GetChild(5).localEulerAngles = new Vector3(0, 0, 180);
                    SmoothingChangePos(transform.GetChild(5));
                }
                if (hitList[0] == 0)
                {
                    //transform.GetChild(0).GetComponent<SpriteRenderer>().color = Color.yellow;
                    SmoothingChangePos(transform.GetChild(0));
                }
            }
        }
    }

    void SmoothingChangePos(Transform child)
    {
        Vector3 localPos = child.transform.localPosition;
        localPos.y = -.24f;
        spawned = Instantiate(crumbSmoothingTriangle, child.transform.position, child.transform.rotation);
        spawned.transform.parent = transform;

        if (isReset == true)
        {
            PolygonCollider2D[] colliders = spawned.GetComponents<PolygonCollider2D>();

            foreach (PolygonCollider2D collider in colliders)
            {
                collider.enabled = true;
            }
        }

        Crumb_Smoothing crumbSmoothing = GetComponentInParent<Crumb_Smoothing>();
        if (crumbSmoothing != null)
        {
            crumbSmoothing.crumbSmoothingList.Add(spawned);
        }
        else
        {
            Debug.Log("well well well");
        }
    }
}
