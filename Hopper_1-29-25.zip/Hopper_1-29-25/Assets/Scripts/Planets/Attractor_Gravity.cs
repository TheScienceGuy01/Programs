using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attractor_Gravity : MonoBehaviour
{
    public float range;
    public float gravityStrength;
    public List<GameObject> affectedGameobjects = new List<GameObject>();
    private bool startInitialization;
    public float rotationSpeed;

    void Start()
    {
        startInitialization = true;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        foreach (GameObject gravObj in affectedGameobjects)
        {
            Vector2 direction = (Vector2)transform.position - gravObj.GetComponent<Rigidbody2D>().position;  // Direction from object to planet
            direction.Normalize();  // Normalize the direction vector

            // Apply constant gravitational force
            Vector2 gravity = direction * gravityStrength;
            gravObj.GetComponent<Rigidbody2D>().AddForce(gravity, ForceMode2D.Force);

            // Rotate the object to face the planet
            float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg + 90;  // Calculate angle
            Quaternion targetRotation = Quaternion.Euler(0, 0, angle);  // Desired rotation
            gravObj.transform.rotation = Quaternion.RotateTowards(gravObj.transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.GetComponent<Player_Manager>() != null)
        {
            if (other.gameObject.GetComponent<Player_Manager>().isAffectedByGravity == true)
            {
                if (startInitialization == true)
                {
                    startInitialization = false;
                    transform.parent.GetComponent<Collider_Generator>().initialColliderChecks.Clear();
                    transform.parent.GetComponent<Collider_Generator>().initialColliderChecks.Add(other.gameObject);
                }

                affectedGameobjects.Add(other.gameObject);
            }
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.GetComponent<Player_Manager>() != null)
        {
            if (other.gameObject.GetComponent<Player_Manager>().isAffectedByGravity == true)
            {
                affectedGameobjects.Remove(other.gameObject);
            }
        }
    }
}
