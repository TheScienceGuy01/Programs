using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hill_Generation : MonoBehaviour
{
    public GameObject spawned;
    public GameObject hillCrumb;
    public float surfaceDistance;
    public GameObject closestChild;
    public float randHeight;
    public int hillHeight;
    public GameObject initialCrumb;
    public float[] hillUpperRange;
    public float[] hillLowerRange;
    public int hillType;
    public float planetSize;
    public float increaseRate;
    public float decreaseRate;
    public void Start()
    {
        surfaceDistance = ((transform.parent.GetComponent<Planet_Generation>().planetRadius) * Mathf.Sqrt(3)) / 2.2f;
        transform.GetChild(0).transform.position = new Vector2(transform.position.x, surfaceDistance);
        transform.eulerAngles = new Vector3(0f, 0f, Random.Range(0f, 360f));

        hillCrumb = transform.parent.GetChild(0).gameObject;
        spawned = Instantiate(hillCrumb.gameObject, transform.GetChild(0).transform.position, Quaternion.identity);
        Destroy(spawned.GetComponent<Planet_Generation>());
        spawned.GetComponent<SpriteRenderer>().enabled = false;
        spawned.transform.parent = transform.parent;
        spawned.tag = "HillCrumb";
        hillCrumb = spawned;

        initialCrumb = hillCrumb;
        planetSize = transform.parent.GetComponent<Planet_Generation>().planetRadius;

        int upGrace = 0;
        if (hillType == 0)
        {
            hillHeight = Random.Range(Mathf.RoundToInt(.067f * planetSize), Mathf.RoundToInt(.23f*planetSize));
        }
        else if (hillType == 1)
        {
            hillHeight = Random.Range(Mathf.RoundToInt(.23f * planetSize), Mathf.RoundToInt(.44f * planetSize));
        }
        else if (hillType == 2)
        {
            hillHeight = Random.Range(Mathf.RoundToInt(.4f * planetSize), Mathf.RoundToInt(.89f * planetSize));
        }
        while (Vector3.Distance(spawned.transform.position, transform.parent.transform.position) <= Vector3.Distance(initialCrumb.transform.position, transform.parent.transform.position) + hillHeight)
        {
            Vector3 diff = transform.GetChild(0).transform.GetChild(2).transform.position - transform.position;
            float angle = Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(0f, 0f, angle - 90);

            Vector2 spritePos = transform.GetChild(0).localPosition;
            if (upGrace >= 0)
            {
                randHeight = Random.Range(0, Mathf.Abs(hillUpperRange[1]));
                upGrace -= 1;
            }
            else
            {
                if (hillType == 0)
                {
                    hillUpperRange[0] = Random.Range(-1f, 0f);
                    hillUpperRange[1] = hillUpperRange[0] * -1 + Random.Range(0f, .5f);
                    randHeight = Random.Range(hillUpperRange[0], hillUpperRange[1]);

                }
                else if (hillType == 1)
                {
                    hillUpperRange[0] = Random.Range(-2f, 0f);
                    hillUpperRange[1] = hillUpperRange[0] * -1 + Random.Range(.3f, .8f);
                    randHeight = Random.Range(hillUpperRange[0], hillUpperRange[1]);
                }
                else if (hillType == 2)
                {
                    hillUpperRange[0] = -2f;
                    hillUpperRange[1] = 4f;
                    randHeight = Random.Range(hillUpperRange[0], hillUpperRange[1]);
                }
            }

            spritePos.y += randHeight;
            transform.GetChild(0).transform.localPosition = spritePos;

            float closestChildDist = 10000;
            for (int j = 0; j < transform.GetChild(0).transform.childCount; j++)
            {
                if (Vector3.Distance(spawned.transform.GetChild(j).transform.position, transform.GetChild(0).position) <= closestChildDist)
                {
                    closestChildDist = Vector3.Distance(spawned.transform.GetChild(j).transform.position, transform.GetChild(0).position);
                    closestChild = spawned.transform.GetChild(j).gameObject;
                }
            }
            spawned = Instantiate(hillCrumb.gameObject, closestChild.transform.position, Quaternion.identity);
            spawned.transform.parent = transform.parent;
            spawned.tag = "HillCrumb";


        }
        while (Vector3.Distance(spawned.transform.position, transform.parent.transform.position) >= Vector3.Distance(initialCrumb.transform.position, transform.parent.transform.position))
        {
            Vector3 diff = transform.GetChild(0).transform.GetChild(2).transform.position - transform.position;
            float angle = Mathf.Atan2(diff.y, diff.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(0f, 0f, angle - 90);

            Vector2 spritePos = transform.GetChild(0).localPosition;
            if (hillType == 0)
            {
                hillLowerRange[0] = Random.Range(-1f, 0f);
                hillLowerRange[1] = hillLowerRange[0] * -1 - Random.Range(0f, .5f);
                randHeight = Random.Range(hillLowerRange[0], hillLowerRange[1]);
            }
            else if (hillType == 1)
            {
                hillLowerRange[0] = Random.Range(-2f, 0f);
                hillLowerRange[1] = hillLowerRange[0] * -1 - Random.Range(.3f, .8f);
                randHeight = Random.Range(hillLowerRange[0], hillLowerRange[1]);
            }
            else if (hillType == 2)
            {
                hillLowerRange[0] = -4f;
                hillLowerRange[1] = 2f;
                randHeight = Random.Range(hillLowerRange[0], hillLowerRange[1]);
            }

            spritePos.y += randHeight;
            transform.GetChild(0).transform.localPosition = spritePos;

            float closestChildDist = 10000;
            for (int j = 0; j < transform.GetChild(0).transform.childCount; j++)
            {
                if (Vector3.Distance(spawned.transform.GetChild(j).transform.position, transform.GetChild(0).position) <= closestChildDist)
                {
                    closestChildDist = Vector3.Distance(spawned.transform.GetChild(j).transform.position, transform.GetChild(0).position);
                    closestChild = spawned.transform.GetChild(j).gameObject;
                }
            }
            spawned = Instantiate(hillCrumb.gameObject, closestChild.transform.position, Quaternion.identity);
            spawned.transform.parent = transform.parent;
            spawned.tag = "HillCrumb";
            spawned.AddComponent<PolygonCollider2D>();

        }
    }
}