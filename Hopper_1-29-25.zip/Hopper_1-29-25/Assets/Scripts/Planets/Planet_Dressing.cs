using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* 
 * ========================================================================================================
 * Date updated: 5/13/2024
 * Author: Israel Irizarry
 * 
 * Assisted by: ChatGPT
 * 
 * Purpose: To easily add new surface and cave structures to planets.
 * 
 * 
 * ========================================================================================================
 */

[System.Serializable]
public class RowData
{
    //Initializaes all possible data for dressing generation.
    public GameObject prefab;
    public bool hasVariations;
    public GameObject[] variationPrefabs;
    public float[] variationSpawnRate;
    public float spawnRate;
    public int location;
    public bool isFacingUp;
    public bool isUpDown;
    public bool isCollidible;
    public bool isGroup;
    public GameObject groupSpawner;
}
public class Planet_Dressing : MonoBehaviour
{

    //Publically shows rows and gets all position spawn positions.
    public List<RowData> rows = new List<RowData>();
    private List<GameObject> surfacePositions = new List<GameObject>();
    private List<GameObject> caveSmoothing = new List<GameObject>();
    private GameObject spawned;

    private void Start()
    {
        //Starts non-group generation.
        Gen();
    }

    IEnumerator Group_Spawns(GameObject groupObject, RowData row)
    {
        /* 
         * =======================================
         * This function allows for group spawn generation (such as group tree spawns).
         * 
         * =======================================
         */

        yield return new WaitForSeconds(.1f);

        //Gets a list of all possible positions from Group_Spawns collider.
        List<GameObject> positions = groupObject.transform.GetChild(0).GetComponent<Group_Spawns>().positioningCrumbs;
        
        //Sky stuff
        if (row.location == 1)
        {
            foreach (GameObject positionCrumb in positions)
            {
                if (positionCrumb.GetComponent<Planet_Generation>().isSurface && positionCrumb != null)
                {
                    if (row.hasVariations == true)
                    {
                        float randVariation = Random.value;
                        for (int i = 0; i < row.variationSpawnRate.Length; i++)
                        {
                            if (randVariation < row.variationSpawnRate[0] / 100)
                            {
                                Positioning1(row.variationPrefabs[0], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                            }
                            if (i != 0 && i != row.variationSpawnRate.Length - 1)
                            {
                                if (randVariation > row.variationSpawnRate[i - 1] / 100 && randVariation < row.variationSpawnRate[i] / 100)
                                {
                                    Positioning1(row.variationPrefabs[i], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                }
                            }
                            if (randVariation > row.variationSpawnRate[row.variationSpawnRate.Length - 1] / 100)
                            {
                                Positioning1(row.variationPrefabs[row.variationSpawnRate.Length - 1], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                            }
                        }
                    }
                    else
                    {
                        Positioning1(row.prefab, positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                    }
                }
            }
        }
        //Surface Stuff
        if (row.location == 2)
        {
            foreach (GameObject positionCrumb in positions)
            {
                if (positionCrumb.GetComponent<Planet_Generation>().isSurface && positionCrumb != null)
                {
                    if (row.hasVariations == true)
                    {
                        float randVariation = Random.value;
                        for (int i = 0; i < row.variationSpawnRate.Length; i++)
                        {
                            if (randVariation < row.variationSpawnRate[0] / 100)
                            {
                                Positioning1(row.variationPrefabs[0], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                            }
                            if (i != 0 && i != row.variationSpawnRate.Length - 1)
                            {
                                if (randVariation > row.variationSpawnRate[i - 1] / 100 && randVariation < row.variationSpawnRate[i] / 100)
                                {
                                    Positioning1(row.variationPrefabs[i], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                }
                            }
                            if (randVariation > row.variationSpawnRate[row.variationSpawnRate.Length - 1] / 100)
                            {
                                Positioning1(row.variationPrefabs[row.variationSpawnRate.Length - 1], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                            }
                        }
                    }
                    else
                    {
                        Positioning1(row.prefab, positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                    }
                }
            }
        }

        //This is for surface ores / underground spawns.
        if (row.location == 3)
        {
            foreach (GameObject positionCrumb in positions)
            {
                if (!positionCrumb.GetComponent<Planet_Generation>().isSurface && positionCrumb != null)
                {
                    if (row.hasVariations == true)
                    {
                        float randVariation = Random.value;
                        for (int i = 0; i < row.variationSpawnRate.Length; i++)
                        {
                            if (randVariation < row.variationSpawnRate[0] / 100)
                            {
                                Positioning1(row.variationPrefabs[0], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                            }
                            if (i != 0 && i != row.variationSpawnRate.Length - 1)
                            {
                                if (randVariation > row.variationSpawnRate[i - 1] / 100 && randVariation < row.variationSpawnRate[i] / 100)
                                {
                                    Positioning1(row.variationPrefabs[i], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                }
                            }
                            if (randVariation > row.variationSpawnRate[row.variationSpawnRate.Length - 1] / 100)
                            {
                                Positioning1(row.variationPrefabs[row.variationSpawnRate.Length - 1], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                            }
                        }
                    }
                    else
                    {
                        Positioning1(row.prefab, positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                    }
                }
            }
        }

        //Destroys group collider.
        Destroy(groupObject.transform.gameObject);
    }

    void Gen()
    {
        /*
         * =======================================
         * Performs single prefab dressing generation.
         * Uses row data to find possible positions.
         * =======================================
         */

        //Gets the surface crumbs and their smoothing pieces.
        Crumb_Smoothing crumbSmoothing = transform.GetComponent<Crumb_Smoothing>();

        surfacePositions.AddRange(crumbSmoothing.crumbSurfaceList);

        //Gets cave spawn positions through color. ***This needs to be changed when sprites are introduced***.
        foreach (GameObject smoothingCrumb in crumbSmoothing.crumbSmoothingList)
        {
            if (smoothingCrumb != null && smoothingCrumb.transform.GetChild(0).GetComponent<SpriteRenderer>().color == Color.cyan)
            {
                caveSmoothing.Add(smoothingCrumb);
            }
        }

        //Gives the positioning functions the data needed to spawn the prefab.
        foreach (RowData row in rows)
        {
            //Sky stuff
            if (row.location == 1)
            {
                foreach (GameObject positionCrumb in surfacePositions)
                {
                    if (Random.value > 1-row.spawnRate/100 && positionCrumb != null)
                    {
                        if (row.hasVariations == true)
                        {
                            float randVariation = Random.value;
                            Debug.Log(randVariation);
                            for (int i = 0; i < row.variationSpawnRate.Length; i++)
                            {
                                if (randVariation < row.variationSpawnRate[0]/100)
                                {
                                    Positioning(row.variationPrefabs[0], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                }
                                if (i != 0 && i != row.variationSpawnRate.Length-1)
                                {
                                    if (randVariation > row.variationSpawnRate[i-1]/100 && randVariation < row.variationSpawnRate[i]/100)
                                    {
                                        Positioning(row.variationPrefabs[i], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                    }
                                }
                                if (randVariation > row.variationSpawnRate[row.variationSpawnRate.Length - 1]/100)
                                {
                                    Positioning(row.variationPrefabs[row.variationSpawnRate.Length - 1], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                }
                            }
                        }
                        else
                        {
                            Positioning(row.prefab, positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                        }
                    }
                }
            }

            //Surface stuff
            if (row.location == 2)
            {
                foreach (GameObject positionCrumb in surfacePositions)
                {
                    if (Random.value > 1 - row.spawnRate / 100 && positionCrumb != null)
                    {
                        if (row.hasVariations == true)
                        {
                            float randVariation = Random.value;
                            for (int i = 0; i < row.variationSpawnRate.Length; i++)
                            {
                                if (randVariation < row.variationSpawnRate[0] / 100)
                                {
                                    Positioning(row.variationPrefabs[0], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                }
                                if (i != 0 && i != row.variationSpawnRate.Length - 1)
                                {
                                    if (randVariation > row.variationSpawnRate[i - 1] / 100 && randVariation < row.variationSpawnRate[i] / 100)
                                    {
                                        Positioning(row.variationPrefabs[i], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                    }
                                }
                                if (randVariation > row.variationSpawnRate[row.variationSpawnRate.Length - 1] / 100)
                                {
                                    Positioning(row.variationPrefabs[row.variationSpawnRate.Length - 1], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                }
                            }
                        }
                        else
                        {
                            Positioning(row.prefab, positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                        }
                    }
                }
            }

            //Underground stuff
            if (row.location == 3)
            {
                foreach (GameObject positionCrumb in caveSmoothing)
                {
                    if (Random.value > 1 - row.spawnRate / 100 && positionCrumb != null)
                    {
                        if (row.hasVariations == true)
                        {
                            float randVariation = Random.value;
                            for (int i = 0; i < row.variationSpawnRate.Length; i++)
                            {
                                if (randVariation < row.variationSpawnRate[0] / 100)
                                {
                                    Positioning(row.variationPrefabs[0], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                }
                                if (i != 0 && i != row.variationSpawnRate.Length - 1)
                                {
                                    if (randVariation > row.variationSpawnRate[i - 1] / 100 && randVariation < row.variationSpawnRate[i] / 100)
                                    {
                                        Positioning(row.variationPrefabs[i], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                    }
                                }
                                if (randVariation > row.variationSpawnRate[row.variationSpawnRate.Length - 1] / 100)
                                {
                                    Positioning(row.variationPrefabs[row.variationSpawnRate.Length - 1], positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                                }
                            }
                        }
                        else
                        {
                            Positioning(row.prefab, positionCrumb, row.isFacingUp, row.isUpDown, row.isCollidible, row.isGroup, row.location, row);
                        }
                    }
                }
            }
        }

        //Initiates planet/object colliders.
        transform.GetComponent<Collider_Generator>().enabled = true;
    }

    public void Positioning(GameObject prefabObject, GameObject positioningObject, bool isUp, bool isupdown, bool isCollidible, bool isGroup, int location, RowData rowData)
    {
        /*
         * ======================================= 
         * Takes the data given by Gen and checks
         * more data to see how it should spawn.
         * =======================================
         */

        //Gets group generation initially working.
        if (isGroup == false)
        {
            spawned = Instantiate(prefabObject, positioningObject.transform.position, positioningObject.transform.rotation);
            spawned.gameObject.SetActive(true);
        }
        else
        {
            spawned = Instantiate(rowData.groupSpawner, positioningObject.transform.position, positioningObject.transform.rotation);
            StartCoroutine(Group_Spawns(spawned, rowData));
        }
        spawned.transform.parent = transform.GetChild(5);

        //Acknowledges collidable object.
        if (isCollidible == true)
        {
            transform.GetComponent<Collider_Generator>().tempColliderChecks.Add(spawned);
        }

        //Only for objects set to face up.
        if (isUp == true)
        {
            Vector3 direction = spawned.transform.position - transform.position;
            direction.z = 0; // Ensure the sprite stays in the 2D plane

            // Rotate the sprite to face the planet
            spawned.transform.up = direction.normalized;
        }

        //Only for objects set to face up or down.
        if (isupdown)
        {
            Vector3 direction = spawned.transform.position - transform.position;
            direction.z = 0; // Ensure the sprite stays in the 2D plane

            // Rotate the sprite to face the planet
            if (Random.value > .5)
            {
                spawned.transform.up = -direction.normalized;
            }
            else
            {
                spawned.transform.up = direction.normalized;
            }
        }

        //If not up or down or just up then the crumb rotation is chosen.
    }

    public void Positioning1(GameObject prefabObject, GameObject positioningObject, bool isUp, bool isupdown, bool isCollidible, bool isGroup, int location, RowData rowData)
    {
        spawned = Instantiate(prefabObject, positioningObject.transform.position, positioningObject.transform.rotation);
        spawned.gameObject.SetActive(true);
        spawned.transform.parent = transform.GetChild(5);

        if (isCollidible == true)
        {
            transform.GetComponent<Collider_Generator>().tempColliderChecks.Add(spawned);
        }

        if (isUp == true)
        {
            Vector3 direction = spawned.transform.position - transform.position;
            direction.z = 0; // Ensure the sprite stays in the 2D plane

            // Rotate the sprite to face the planet
            spawned.transform.up = direction.normalized;
        }
        if (isupdown)
        {
            Vector3 direction = spawned.transform.position - transform.position;
            direction.z = 0; // Ensure the sprite stays in the 2D plane

            // Rotate the sprite to face the planet
            if (Random.value > .5)
            {
                spawned.transform.up = -direction.normalized;
            }
            else
            {
                spawned.transform.up = direction.normalized;
            }
        }
    }
}
