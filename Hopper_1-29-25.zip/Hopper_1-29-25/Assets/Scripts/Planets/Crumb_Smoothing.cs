using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crumb_Smoothing : MonoBehaviour
{
    public float raycastDistance = 10f;
    public int[] angles;
    public int crumbCount;
    public bool isStopped;
    public List<GameObject> crumbList = new List<GameObject>();
    public List<GameObject> caveCrumbsList = new List<GameObject>();
    public List<GameObject> crumbSmoothingList = new List<GameObject>();
    public List<GameObject> crumbSurfaceList = new List<GameObject>();
    public GameObject backgroundCrumb;
    public float backgroundCrumbShade;
    private GameObject spawned;
    public List<GameObject> oreSpawns = new List<GameObject>();

    private void Start()
    {
        StartCoroutine(Stop_Check());
    }

    IEnumerator Stop_Check()
    {
        int tempCheck;
        while (isStopped == false)
        {
            tempCheck = crumbCount;
            yield return new WaitForSeconds(0.5f);
            if (tempCheck == crumbCount)
            {
                isStopped = true;
                StartCoroutine(Smoothing());
            }
        }
    }

    IEnumerator Smoothing()
    {
        foreach (GameObject ore in oreSpawns)
        {
            ore.SetActive(true);
        }
        foreach (GameObject crumb in crumbList)
        {
            if (crumb != null)
            {
                crumb.AddComponent<PolygonCollider2D>();
                spawned = Instantiate(backgroundCrumb, crumb.transform.position, crumb.transform.rotation);
                spawned.GetComponent<SpriteRenderer>().color = new Color(crumb.GetComponent<SpriteRenderer>().color.r * backgroundCrumbShade, crumb.GetComponent<SpriteRenderer>().color.g * backgroundCrumbShade, crumb.GetComponent<SpriteRenderer>().color.b * backgroundCrumbShade, 255);
                spawned.transform.parent = transform.GetChild(6).transform;
            }
        }
        yield return new WaitForSeconds(.5f);
        foreach (GameObject crumb in crumbList)
        {
            if (crumb != null)
            {
                crumb.GetComponent<Planet_Generation>().isBroken = true;
            }
        }
    
        yield return new WaitForSeconds(0.5f);
        foreach (GameObject smoothing in crumbSmoothingList)
        {
            if (smoothing != null && smoothing.transform.parent.GetComponent<Planet_Generation>().isSurface != true)
            {
                foreach (Transform child in smoothing.transform)
                {
                    child.GetComponent<SpriteRenderer>().color = Color.cyan;
                }
            }

            if (smoothing != null && smoothing.transform.parent.GetComponent<Planet_Generation>().isSurface == true)
            {
                crumbSurfaceList.Add(smoothing);
            }
        }

        GameObject[] hillObjects = GameObject.FindGameObjectsWithTag("HillCrumb");
        foreach (GameObject crumb in hillObjects)
        {
            Destroy(crumb.gameObject);
        }
        Destroy(transform.GetChild(2).gameObject);

        transform.GetComponent<Planet_Dressing>().enabled = true;
    }
}
