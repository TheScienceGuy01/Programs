using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collider_Generator : MonoBehaviour
{
    public GameObject colliderBox;
    private float planetBorder;
    private float spriteheight;
    private float spriteWidth;
    public GameObject heightGameobject;
    private List<GameObject> colliderBoxes = new List<GameObject>();
    public List<GameObject> totalColliderBoxes = new List<GameObject>();
    public List<int> colliderInteractions = new List<int>();
    private GameObject spawned;
    public bool isCollider;
    public List<GameObject> initialColliderChecks = new List<GameObject>();
    public List<GameObject> tempColliderChecks = new List<GameObject>();
    public float colliderDistance;
    public bool isActive;
    private bool isColliderSafe;
    private bool isVisualSafe;
    private Dictionary<GameObject, bool> objectXStatus = new Dictionary<GameObject, bool>();
    public GameObject player;
    public GameObject colliderSource;

    void Start()
    {
        if (isCollider == false)
        {
            Planet_Generation planetParent = transform.GetComponent<Planet_Generation>();

            planetBorder = (((planetParent.planetRadius) * Mathf.Sqrt(3)) / 2.2f) * 2.5f;
            spriteheight = colliderBox.GetComponent<SpriteRenderer>().bounds.size.y;
            spriteWidth = colliderBox.GetComponent<SpriteRenderer>().bounds.size.x;
            spawned = Instantiate(colliderBox, heightGameobject.transform.position, transform.rotation);
            spawned.transform.parent = transform.GetChild(5);
            colliderBoxes.Add(spawned);

            while (Vector3.Distance(heightGameobject.transform.position, transform.position) < planetBorder)
            {
                heightGameobject.transform.position = new Vector3(transform.position.x, heightGameobject.transform.position.y + spriteheight, 0);
                spawned = Instantiate(colliderBox, heightGameobject.transform.position, transform.rotation);
                spawned.transform.parent = transform.GetChild(5);
                colliderBoxes.Add(spawned);
            }
            heightGameobject.transform.position = transform.position;
            while (Vector3.Distance(heightGameobject.transform.position, transform.position) < planetBorder)
            {
                heightGameobject.transform.position = new Vector3(transform.position.x, heightGameobject.transform.position.y - spriteheight, 0);
                spawned = Instantiate(colliderBox, heightGameobject.transform.position, transform.rotation);
                spawned.transform.parent = transform.GetChild(5);
                colliderBoxes.Add(spawned);
            }
            foreach (GameObject colliders in colliderBoxes)
            {
                heightGameobject.transform.position = colliders.transform.position;
                while (Vector3.Distance(heightGameobject.transform.position, transform.position) < planetBorder)
                {
                    heightGameobject.transform.position = new Vector2(heightGameobject.transform.position.x - spriteWidth, heightGameobject.transform.position.y);
                    spawned = Instantiate(colliderBox, heightGameobject.transform.position, transform.rotation);
                    spawned.transform.parent = transform.GetChild(5);
                }
                heightGameobject.transform.position = colliders.transform.position;
                while (Vector3.Distance(heightGameobject.transform.position, transform.position) < planetBorder)
                {
                    heightGameobject.transform.position = new Vector2(heightGameobject.transform.position.x + spriteWidth, heightGameobject.transform.position.y);
                    spawned = Instantiate(colliderBox, heightGameobject.transform.position, transform.rotation);
                    spawned.transform.parent = transform.GetChild(5);
                }
            }
        }
        else
        {
            StartCoroutine(Collider_Trimming());
        }
    }

    IEnumerator Collider_Trimming()
    {
        yield return new WaitForSeconds(.1f);
        if (transform.childCount == 0)
        {
            Destroy(gameObject);
        }
        else
        {
            transform.parent.transform.parent.GetComponent<Collider_Generator>().totalColliderBoxes.Add(gameObject);
            transform.parent.transform.parent.GetComponent<Collider_Generator>().colliderInteractions.Add(0);
            transform.parent.transform.parent.GetComponent<Collider_Generator>().objectXStatus.Add(gameObject, false);
            Destroy(transform.GetComponent<Rigidbody2D>());
            Destroy(transform.GetComponent<BoxCollider2D>());
            Destroy(transform.GetComponent<Collider_Generator>());
            // Initialize the status of all objectXs as false
        }

        foreach (GameObject objectX in totalColliderBoxes)
        {
            foreach (Transform crumb in objectX.transform)
            {
                Destroy(crumb.GetComponent<PolygonCollider2D>());
            }
        }
        transform.parent.transform.parent.GetComponent<Collider_Generator>().tempColliderChecks.Clear();
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (isCollider == true && other.gameObject.CompareTag("Crumb") && !other.gameObject.name.Contains("Triangle Smoothing"))
        {
            other.transform.parent = transform;
            Destroy(other.gameObject.GetComponent<PolygonCollider2D>());
        }
    }

    private void Update()
    {
        if (isCollider == false)
        {
            foreach (GameObject objectX in totalColliderBoxes)
            {
                isVisualSafe = false;
                isColliderSafe = false;

                foreach (GameObject player in tempColliderChecks)
                {
                    if (player != null)
                    {
                        float distance = Vector2.Distance(player.transform.position, objectX.transform.position);

                        if (distance <= colliderDistance)
                        {
                            isColliderSafe = true;

                            break; // No need to check further if one player is already in range
                        }
                    }
                }

                foreach (GameObject player in initialColliderChecks)
                {
                    if (player != null)
                    {
                        float distance = Vector2.Distance(player.transform.position, objectX.transform.position);

                        if (distance <= colliderDistance)
                        {
                            isColliderSafe = true;

                            break; // No need to check further if one player is already in range
                        }
                    }
                }

                // If the status changes, update the active state of objectX
                if (isColliderSafe != objectXStatus[objectX])
                {
                    objectXStatus[objectX] = isColliderSafe;
                    //objectX.GetComponent<SpriteRenderer>().enabled = (isSafe);
                    if (isColliderSafe == true)
                    {
                        foreach (Transform crumb in objectX.transform)
                        {
                            PolygonCollider2D sourceCollider = colliderSource.GetComponent<PolygonCollider2D>();
                            PolygonCollider2D targetCollider = crumb.gameObject.AddComponent<PolygonCollider2D>();
                            targetCollider.points = sourceCollider.points;

                            PolygonCollider2D targetCollider1 = crumb.gameObject.AddComponent<PolygonCollider2D>();
                            targetCollider1.points = sourceCollider.points;
                            targetCollider1.isTrigger = true;

                            
                            foreach (Transform child in crumb.transform)
                            {
                                if (child.name.Contains("Triangle Smoothing"))
                                {
                                    PolygonCollider2D[] colliders2 = child.GetComponents<PolygonCollider2D>();

                                    // Loop through each collider and disable it
                                    foreach (PolygonCollider2D collider in colliders2)
                                    {
                                        if (collider != null) // Check if collider is not null
                                        {
                                            collider.enabled = true;
                                        }
                                    }
                                }
                            }
                            
                        }
                    }
                    else
                    {
                        foreach (Transform crumb in objectX.transform)
                        {
                            // Find all Collider components on the GameObject
                            PolygonCollider2D[] colliders = crumb.GetComponents<PolygonCollider2D>();

                            // Loop through each collider and destroy it
                            foreach (PolygonCollider2D collider in colliders)
                            {
                                Destroy(collider);
                            }
                            
                            foreach (Transform child in crumb.transform)
                            {
                                if (child.name.Contains("Triangle Smoothing"))
                                {
                                    PolygonCollider2D[] colliders1 = child.GetComponents<PolygonCollider2D>();

                                    // Loop through each collider and disable it
                                    foreach (PolygonCollider2D collider in colliders1)
                                    {
                                        collider.enabled = false;
                                    }
                                }
                            }
                            
                        }
                    }
                }
            }
        }
    }
}
