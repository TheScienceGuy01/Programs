using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]

public class Templates
{
    public List<CrumbTemplates> crumbTemplates = new List<CrumbTemplates>();
}
public class Planet_Templates : MonoBehaviour
{
    public List<Templates> planetTemplates = new List<Templates>();
}
