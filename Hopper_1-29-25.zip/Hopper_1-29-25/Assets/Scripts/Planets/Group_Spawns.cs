using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Group_Spawns : MonoBehaviour
{
    public List<GameObject> positioningCrumbs = new List<GameObject>();
    public bool isOre;
    public Color ore;
    public float spawnRate;
    public float percentageRate;

    IEnumerator Destroy_Spawner()
    {
        yield return new WaitForSeconds(.1f);
        Destroy(transform.parent.gameObject);
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Crumb") && !positioningCrumbs.Contains(other.gameObject) && isOre == false) 
        {
            positioningCrumbs.Add(other.gameObject);
        }
        if (isOre == true && other.gameObject.CompareTag("Crumb"))
        {
            if (Random.value < percentageRate/100f)
            {
                other.gameObject.GetComponent<SpriteRenderer>().color = ore;
            }
        }
    }
}
