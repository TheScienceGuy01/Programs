using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crumb_Info : MonoBehaviour
{
    public List<CrumbTemplates> crumbTemplate = new List<CrumbTemplates>();
    public int crumbLayer;
    public bool isSurface;
    private GameObject spawned;
    public GameObject oreSpawner;
    public bool isStopped;
    public short brokenPhase;
    private void Start()
    {
        
        GetComponent<SpriteRenderer>().color = crumbTemplate[0].crumbColor;
        
        if (crumbTemplate[0].oreSpawns.Count != 0)
        {
            for (int i = 0; i < crumbTemplate[0].oreSpawns.Count; i++)
            {
                if (Random.value > 1 - crumbTemplate[0].oreSpawns[i].spawnRate / 100)
                {
                    spawned = Instantiate(crumbTemplate[0].oreSpawns[i].shape, transform.position, transform.rotation);
                    StartCoroutine(Enable_Ore());
                    spawned.GetComponent<Group_Spawns>().ore = crumbTemplate[0].oreSpawns[i].ore;
                    spawned.GetComponent<Group_Spawns>().spawnRate = crumbTemplate[0].oreSpawns[i].spawnRate;
                    spawned.GetComponent<Group_Spawns>().percentageRate = crumbTemplate[0].oreSpawns[i].percentageChanged;
                    spawned.transform.localScale = new Vector2(crumbTemplate[0].oreSpawns[i].size, crumbTemplate[0].oreSpawns[i].size);
                    transform.parent.GetComponent<Crumb_Smoothing>().oreSpawns.Add(spawned);
                    //Working on ore spawns. Having the shape object spawn and have the crumbs change to ores.
                }
            }

        }
    }

    IEnumerator Enable_Ore() 
    {
        yield return new WaitForSeconds(.1f);
        yield return new WaitForEndOfFrame();
        spawned.gameObject.SetActive(true);
    }

    public void Broken_Phase()
    {
        brokenPhase += 1;

        switch (brokenPhase)
        {
            case 1:

                break;
        }
    }
}
