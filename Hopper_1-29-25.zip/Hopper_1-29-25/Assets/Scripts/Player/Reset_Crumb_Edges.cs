using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Reset_Crumb_Edges : MonoBehaviour
{
    public List<GameObject> crumbs = new List<GameObject>();

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Crumb"))
        {

            crumbs.Add(other.gameObject);
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Crumb"))
        {
            crumbs.Remove(other.gameObject);
        }
    }

    public void Reset_Edges()
    {
        Debug.Log("Resetting Edges");
        foreach (GameObject obj in crumbs)
        {
            if (obj.GetComponent<Planet_Generation>() != null)
            {
                obj.GetComponent<Planet_Generation>().isReset = true;
                obj.GetComponent<Planet_Generation>().isBroken = true;
            }
        }
    }
}
