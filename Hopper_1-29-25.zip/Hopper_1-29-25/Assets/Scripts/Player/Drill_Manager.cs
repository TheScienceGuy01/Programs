using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Drill_Manager : MonoBehaviour
{
    public Camera cam;
    public List<GameObject> crumbs = new List<GameObject>();

    void Update()
    {
        // Get the mouse position in screen space
        Vector3 mousePosition = Input.mousePosition;

        // Convert screen space to world space
        mousePosition = cam.ScreenToWorldPoint(mousePosition);

        // Update the sprite's position
        // Set the Z coordinate to 0 because we're in 2D
        transform.position = new Vector3(mousePosition.x, mousePosition.y, 0);

        if (Input.GetMouseButton(0))
        {
            foreach (var obj in new List<GameObject>(crumbs))
            {
                if (obj != null)
                {
                    Destroy(obj);
                    Debug.Log("destroyed");
                    if (!obj.name.Contains("Triangle"))
                    {
                        transform.GetChild(0).GetComponent<Reset_Crumb_Edges>().Reset_Edges();
                    }
                }
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Crumb"))
        {
            crumbs.Add(other.gameObject);
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Crumb"))
        {
            crumbs.Remove(other.gameObject);
        }
    }
}

